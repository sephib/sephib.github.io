Title: Flex 2.2.0
Date: 2018-06-24 08:00
Modified: 2018-06-24 08:00
Category: News
Tags: pelican, python, theme
Slug: flex-pelican-theme-update-2-2
Cover: images/flex-screenshot.png

[Flex theme](https://github.com/alexandrevicenzi/Flex) 2.2.0 comes with bug fixes and improvements.

There are new Pygments templates and also a few code highlight fixes. There's also new social icons.

Version 2.2.0 also comes with new translations. You can see available translations [here](https://github.com/alexandrevicenzi/Flex/wiki/Translations).

Hope you enjoy this version.
