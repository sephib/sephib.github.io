Title: Some Article 7
Date: 2016-04-01 12:00
Modified: 2016-04-01 12:00
Tags: article, pelican
Slug: some-article-7

This is an article with category dev.