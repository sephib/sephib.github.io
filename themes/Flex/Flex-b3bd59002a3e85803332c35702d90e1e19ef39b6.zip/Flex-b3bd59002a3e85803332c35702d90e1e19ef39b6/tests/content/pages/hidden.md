Title: Hidden
Date: 2016-01-01 12:00
Modified: 2016-01-01 12:00
Status: hidden

This is a hidden page.

It will have `noindex, nofollow` as the value of the `robots` `<meta>` tag.
