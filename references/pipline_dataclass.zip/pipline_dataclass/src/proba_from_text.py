import warnings

warnings.simplefilter(action="ignore", category=Warning)

import mlflow.sklearn
import mlflow.keras
import pandas as pd
import numpy as np
import datetime
import time
from gensim.models import FastText as FT
import matplotlib.pyplot as plt
import json
import ruamel.yaml as yaml
from keras.utils import to_categorical
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.initializers import Zeros
from keras.layers import (
    Dense,
    Input,
    Conv1D,
    Conv2D,
    Embedding,
    Flatten,
    Activation,
    Reshape,
    dot,
    multiply,
    add,
    Bidirectional,
    LSTM,
    GRU,
    MaxPooling1D,
    MaxPooling2D,
)
from keras.callbacks import CSVLogger
from keras.layers.core import Dropout
from keras.models import Model, load_model
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn import model_selection

from numpy import savetxt
from pathlib import Path
import sys
import logging

# path_home = Path(sys.path[-1]).home()
# cur_path = '/home/e015976541/projects/drugs_trafficking/src'
# sys.path.append(str(cur_path))
# from src import drugs_util
# from src import drugs_text
# from src import drugs_metadata_create_models as md
import drugs_util
import drugs_text
import drugs_metadata_create_models as md

from sklearn.decomposition import PCA
from imblearn.over_sampling import SMOTE, ADASYN


path_home = Path(sys.path[-1]).home()
fcutils_path = path_home / "projects/fcutils"
sys.path.append(str(fcutils_path))
from fcutils import fc_logging

log_cols = [
    "model_config",
    "model_params",
    "history_acc",
    "history_val_acc",
    "f1score",
    "auc",
    "conf_mat",
    "tn",
    "fp",
    "fn",
    "tp",
    "remark",
    "date",
]

global perf_log_df_cnn

MAX_SEQUENCE_LENGTH = 200
EMBEDDING_DIM = 30
PCA_DIM = 30
TOKENIZER_NUM_WORDS = 30000

warnings.simplefilter(action="ignore", category=Warning)


def append_df_score(
    model_config,
    model_params,
    history_acc,
    history_val_acc,
    f1score,
    auc,
    conf_mat_,
    remark="",
):
    global perf_log_df_cnn

    perf_log_df_cnn = perf_log_df_cnn.append(
        {
            "model_params": model_params,
            "model_config": model_config,
            "history_acc": history_acc,
            "history_val_acc": history_val_acc,
            "f1score": f1score,
            "auc": auc,
            "conf_mat": conf_mat_,
            "tn": conf_mat_.tn,
            "fp": conf_mat_.fp,
            "fn": conf_mat_.fn,
            "tp": conf_mat_.tp,
            "remark": remark,
            "date": datetime.datetime.now(),
        },
        ignore_index=True,
    )


def get_embed_gensim(cleantext, size=30, window=3):

    ftmodel = FT(size=size, window=window, min_count=1)
    ftmodel.build_vocab(sentences=cleantext)
    ftmodel.train(
        sentences=cleantext,
        epochs=ftmodel.epochs,
        total_examples=ftmodel.corpus_count,
        total_words=ftmodel.corpus_total_words,
    )
    return ftmodel


def get_padded_sequence_from_text(tokenizer, clean_texts, max_len=MAX_SEQUENCE_LENGTH):
    # one hot key: each word gets a number between 0.. MAX_NB_WORDS
    seq = tokenizer.texts_to_sequences(clean_texts)
    p_sequences = pad_sequences(seq, maxlen=max_len)
    return p_sequences


def get_train_test_sets(text_col, label_col, seed=-1):
    msk = drugs_util.get_split_mask(len(text_col), seed=seed)
    x_train = text_col[~msk]
    y_train = label_col[~msk].astype("int").values

    x_test = text_col[msk]
    y_test = label_col[msk].astype("int").values

    y_train_cat = to_categorical(y_train, 2)
    y_test_cat = to_categorical(y_test, 2)
    return x_train, x_test, y_train, y_test, y_train_cat, y_test_cat, msk


# split the dataset to train and test
# clean the train and test sets -
def get_clean_train_test_sets(text_col, label_col, index_col, test_size=0.2, seed=None):
    rs = seed
    if not rs:
        np.random.RandomState(int(time.clock()))
    (
        x_train,
        x_test,
        y_train,
        y_test,
        index_train,
        index_test,
    ) = model_selection.train_test_split(
        text_col, label_col, index_col, test_size=test_size, random_state=rs
    )
    y_train_cat = to_categorical(y_train, 2)
    y_test_cat = to_categorical(y_test, 2)
    clean_texts_train = drugs_text.clean_yediot(x_train)
    clean_texts_test = drugs_text.clean_yediot(x_test)
    clean_text = drugs_text.clean_yediot(text_col)
    return (
        clean_texts_train,
        clean_texts_test,
        y_train,
        y_test,
        y_train_cat,
        y_test_cat,
        index_train,
        index_test,
        clean_text,
    )


def ngrams(clean_texts):
    clean_sentences = []
    for c in clean_texts:
        s = " ".join(w for w in c)
        # for x in ['י', 'ו', 'א','','ה']:
        for x in [" "]:
            s = s.replace(x, "")
        clean_sentences.append(s)

    # CountVectorizer  is one way to devide to ngrams
    vectorizer = CountVectorizer(
        ngram_range=(4, 4), analyzer="char", binary=False
    )  # , max_features=100)
    ngram_mtrx = vectorizer.fit_transform(clean_sentences)
    voc = vectorizer.vocabulary_

    num_features = len(vectorizer.get_feature_names())
    print(num_features)

    counts = []
    for j in range(num_features):
        try:
            if j % 500 == 0:
                print(f"summing vec {j}")

            # count_dict[j] = ngram_mtrx[:, j].sum()
            counts.append(np.sum(ngram_mtrx[:, j]))
        except:
            print(j)
            continue

    n = 200
    df_cnt = pd.DataFrame(columns=["word_count", "frq_token_cnt", "non_frq_toeken_cnt"])
    for i in range(len(clean_sentences)):
        frq_token_cnt = 0
        non_frq_token_cnt = 0
        vec = ngram_mtrx[i]
        for j in vec.nonzero():
            if counts[vec[j]] >= n:
                frq_token_cnt += 1
            else:
                non_frq_token_cnt += 1

        df_cnt = df_cnt.append(
            {
                "word_count": len(clean_texts[i]),
                "frq_token_cnt": frq_token_cnt,
                "non_frq_toeken_cnt": non_frq_token_cnt,
            }
        )

        # np.sort(-np.array(counts)

    # for j in range(num_features):
    #     if counts[j] > 200:
    #         for k, v in voc.items():
    #             if v == j:
    #                 print(k, v)


def find_diff_2_vectors(vec1, vec2):
    cnt = 0
    for i in range(len(vec1)):
        if vec1[i] != vec2[i]:
            print(f"index of different members:{i}")
            print(f"members vec1:{vec1[i]}")
            print(f"members vec2:{vec2[i]}")
            cnt = cnt + 1
    return cnt


def prepare_embedding_layer(
    x_train, tokenizer, cnn_params, trainable=False, pca_dim=-1
):
    # get a pre_trained model (FastText) - takes a long time
    # logger.debug("Loading pre-trained model. It takes 2-5 minutes to load...")
    embedding_model = FT.load_fasttext_format(cnn_params)
    # logger.debug("Finished loading pre-trained model")

    # Preparing the Embedding layer

    tokenizer.fit_on_texts(x_train)
    word_index = tokenizer.word_index

    embedding_matrix = np.zeros(
        (len(word_index) + 1, embedding_model.vector_size)
    )  # adding 1 to account for 0th index (for masking)

    for word, i in word_index.items():
        embedding_matrix[i] = embedding_model[word]

    weights = embedding_matrix
    output_dim = embedding_model.vector_size
    pca = None

    if pca_dim > 0:
        print("PCA on embedding layer")
        pca = PCA(n_components=pca_dim)
        pca.fit(embedding_matrix)
        weights = pca.transform(embedding_matrix)
        output_dim = pca_dim

    # weights = weights.round(decimals=4)
    embedding_layer = Embedding(
        input_dim=len(word_index) + 1,
        # embeddings_initializer=Zeros(),
        output_dim=output_dim,
        weights=[weights],
        input_length=MAX_SEQUENCE_LENGTH,
        trainable=False,
    )

    return embedding_layer, tokenizer, embedding_matrix


# this embedding was horrible - don't use
def get_embedding_max_vec(x_set, embedding_model):
    # set the input matrix as the max of all vectors of all words in a sentence
    # reduce a sentence to a single vector with the max values
    doc_mat = np.zeros((len(x_set), embedding_model.vector_size))
    for doc_pos, d in enumerate(x_set):
        if len(d) > 0:
            word_vector = np.zeros((len(d), embedding_model.vector_size))
            for word_pos, w in enumerate(d):
                word_vector[word_pos] = embedding_model[w]
            doc_mat[doc_pos] = np.max(word_vector)
    return doc_mat


def show_results(p, y_test, model, history=None):
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")


########## LSTM ############
def lstm(
    text_embedding_layer,
    p_train_seq,
    y_train_cat,
    p_test_seq,
    y_test,
    class_weight,
    batch_size=32,
    epochs=5,
    validation_split=0.1,
):
    model = Sequential()
    model.add(text_embedding_layer)
    # model.add(Bidirectional(LSTM(30)))
    model.add(Bidirectional(LSTM(units=30, recurrent_dropout=0.0)))
    # model.add(Dropout(0.2))
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    model.summary()

    history = model.fit(
        p_train_seq,
        y_train_cat,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=validation_split,
        class_weight=class_weight,
    )

    p = model.predict(p_test_seq)
    return model, p


########## GRU ############
def gru(
    text_embedding_layer,
    p_train_seq,
    y_train_cat,
    p_test_seq,
    y_test,
    class_weight,
    batch_size=32,
    epochs=5,
    validation_split=0.1,
):

    model = Sequential()
    model.add(text_embedding_layer)
    # # units = memory cells
    model.add(GRU(units=30, go_backwards=False))
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    model.summary()

    history = model.fit(
        p_train_seq,
        y_train_cat,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=validation_split,
        class_weight=class_weight,
    )

    p = model.predict(p_test_seq)
    # model_compare['GRU'] = p[:, 1]
    # show_results((p[:, 1] > 0.35).astype(int), y_test, model, history)

    return model, p


def seq_to_FT(padded_seqs, tokenizer_ft_dict, tokenizer):
    result = []
    for doc in padded_seqs:
        # each doc is a sequence of 150 (MAX_SEQUENCE_LENGTH) words. Each word is converted to
        # its ft representation (vec of dim 300)
        doc_ft_matrix = np.zeros((MAX_SEQUENCE_LENGTH, tokenizer_ft_dict.shape[1]))
        i = 0
        for word_ind in doc:
            if word_ind > 0:
                doc_ft_matrix[i] = tokenizer_ft_dict[word_ind]
            i = i + 1
        # for conv1D
        doc_ft_matrix = doc_ft_matrix.reshape(150 * 300, 1)
        print(doc_ft_matrix.shape)
        result.append(doc_ft_matrix)
    return np.array(result)


def create_seq_cnn(input, maxpool=False):
    # this is the original cnn which works very good
    model = Sequential()
    model.add(input)
    model.add(
        Conv1D(filters=16, kernel_size=2, activation="relu")
    )  # , input_shape=input_shape))
    model.add(Conv1D(filters=32, kernel_size=3, activation="relu"))  # new
    model.add(Conv1D(filters=64, kernel_size=8, activation="relu"))  # new
    model.add(Conv1D(filters=128, kernel_size=10, activation="relu"))  # new
    model.add(Dropout(0.3))
    model.add(Flatten())
    model.add(Dense(64, activation="relu"))
    model.add(Dense(32, activation="relu"))
    model.add(Dense(16, activation="relu"))
    # output layer
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    model.summary()

    return model


def create_seq_cnn_fixed_kernel_size(input):
    # this is the original cnn which works very good
    kernel_size = 10
    model = Sequential()
    model.add(input)
    model.add(
        Conv1D(filters=16, kernel_size=kernel_size, activation="relu")
    )  # , input_shape=input_shape))
    model.add(Conv1D(filters=32, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Conv1D(filters=64, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Conv1D(filters=128, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Dropout(0.3))
    # todo gila - check if we need twice 0.3
    model.add(Dropout(0.3))
    model.add(Flatten())
    model.add(Dense(64, activation="relu"))
    model.add(Dense(32, activation="relu"))
    model.add(Dense(16, activation="relu"))
    # output layer
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    model.summary()

    return model


#################################
# Gila Cohen Rona
# Given a classified file we train a cnn model to classify drug intel docs as important(erki)/ not important(lo erki)
# The classified dataset is unbalanced - we will handle the imbalance using classweight
# We create an embedding layer from the train set - such that each word in a doc is translated to its
# FastText vector
# We assume a fixed size MAX_SEQUENCE_LENGTH for all docs, docs larger than MAX_SEQUENCE_LENGTH are trimmed to this size.
# Short docs are zero-padded


def main(man_yml_file, gen_yml_file, mode=None, log_level=logging.INFO):

    # print(f'Reading from yaml files:')
    # print (man_yml_file)
    # print(gen_yml_file)

    # man_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_manual.yml'
    # gen_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_generated.yml'
    # __file__ = 'xx'

    man_yml = yaml.safe_load(open(man_yml_file))
    gen_yml = yaml.safe_load(open(gen_yml_file))

    cnn_params = man_yml["proba_from_text"]
    input_files = man_yml["input_folders"]["training"]
    dirs = man_yml["base_dirs"]
    base = dirs["base1"]
    trained_models_dir = dirs["trained_model_dir"]

    cnn_params = man_yml["proba_from_text"]
    input_files = man_yml["input_folders"]["training"]
    dirs = man_yml["base_dirs"]
    base = dirs["base1"]
    trained_models_dir = dirs["trained_model_dir"]
    # trained_models_dir = dirs['trained_model_dir']['base']
    trained_models_dir_cnn = trained_models_dir + "/" + "cnn"
    # trained_models_dir_cnn = trained_models_dir+ '/' + dirs['trained_model_dir']['cnn']

    logs_dir = dirs["log_dir"]
    ts = drugs_util.get_timestamp()

    _file_name = Path(__file__).name
    logfile_name = f"{_file_name}_{ts}.log"
    logger = fc_logging.set_logger(
        name=__name__,
        log_level=log_level,
        log_path=str(logs_dir),
        logfile_name=logfile_name,
    )

    logger.info(f"Log file is written to: {logs_dir}/{logfile_name}")

    logger.debug(f"Now running {_file_name} with yaml files:")
    logger.debug(man_yml_file)
    logger.debug(gen_yml_file)

    labeled_file = Path(base + input_files["expert_decision_file"])
    doc_text_folder = Path(base + input_files["doc_metadata"])

    logger.info(f"Training model using labeled file: {labeled_file}")

    df_embedding = drugs_util.get_label_file(labeled_file)
    label = "label"

    df_doc_texts = drugs_util.read_csv_files_in_folder(folder=doc_text_folder, sep="|")

    df_embedding = df_embedding.merge(
        df_doc_texts[["docDisplayId", "docText"]],
        right_on="docDisplayId",
        left_on="docDisplayId",
    )
    print(len(df_embedding))
    doc_text = "docText"

    test_size = 1 - cnn_params["train_set_size"]

    # QA - the following docs are erki
    # qa_list = ['18-2180-419', '14-0292-795', '17-0246-196', '16-0042-866', '16-0175-804', '16-0185-724', '16-0201-307',
    #            '16-0204-924', '17-0197-793', '17-0212-553', '15-0071-716',
    #            '17-0187-959', '17-0193-698']
    #
    # qa_msk = df_embedding['docDisplayId'].isin(qa_list)
    #
    # df_test1 = df_embedding[qa_msk]
    # len(df_test1)
    #
    # df_embedding = df_embedding[~qa_msk]
    # len(df_embedding)
    # end QA

    (
        x_train,
        x_test,
        y_train,
        y_test,
        y_train_cat,
        y_test_cat,
        index_train,
        index_test,
        clean_text,
    ) = get_clean_train_test_sets(
        df_embedding[doc_text],
        df_embedding[label],
        df_embedding.index,
        test_size=test_size,
    )

    tokenizer = Tokenizer(num_words=TOKENIZER_NUM_WORDS)
    # dont use pca, it lost too much information
    text_embedding_layer, tokenizer, embedding_matrix = prepare_embedding_layer(
        x_train,
        tokenizer,
        # embedding_model,
        cnn_params,
        trainable=False,
        pca_dim=-1,
    )

    logger.info(f"Num of unique tokens from train set: {len(tokenizer.word_index)}")
    # tk = Tokenizer(num_words=TOKENIZER_NUM_WORDS*2)
    #
    # text_clean = df_embedding[doc_text]
    # for x in ["'", '"']:
    #     text_clean = text_clean.replace(x, "")
    # for x in ['\xd5d', '\n', "!", '.', '#', '$', '%', '&', '(', ')', '*', '+', ',', '-', '/', ':', ';', '<', '=', '>',
    #           '?', '@', '[', '^', ']', '_', '`', '{', '|', '}', '~', '\t']:
    #     text_clean = text_clean.replace(x, " ")
    # #text_clean = text_clean.to_list()
    # text_list = []
    # for l in text_clean:
    #     text_list.append(l.split())
    # text_list[0]
    # text_clean = [w for w in text_clean]
    # tk.fit_on_texts(texts=text_list)
    #
    # d = tk.word_counts
    # len(d)
    # for w in sorted(d, key=d.get, reverse=True):
    #     #if (d[w] < 300 and d[w]>100):
    #     if (d[w] > 300):
    #         print(w, d[w])

    # dont use - horrible results
    # x_train_mat = get_embedding_max_vec(x_train, embedding_model)
    # x_train_mat = get_embedding_max_vec(x_test, embedding_model)

    y_train_cat = to_categorical(y_train, 2)
    x_train_padded_seq = get_padded_sequence_from_text(
        tokenizer, x_train, MAX_SEQUENCE_LENGTH
    )
    x_test_padded_seq = get_padded_sequence_from_text(
        tokenizer, x_test, MAX_SEQUENCE_LENGTH
    )
    class_weight = drugs_util.get_class_weight(y_train)

    logger.info(
        f"Class weight of training data is: class_0: {class_weight[0]}, class_1: {class_weight[1]}"
    )

    # do not use adasyn to balance the dataset
    # x_over, y_over = ADASYN().fit_resample(p_train_seq, y_train)
    # GRU and LSTM are both in high correlation - they are good, but cnn is much faster
    # gru_model, gru_test_p = gru(text_embedding_layer, p_train_seq, y_train_cat,
    #             p_test_seq, y_test,
    #             class_weight,
    #             batch_size=32, epochs=5, validation_split=0.1)
    # # model_compare['GRU'] = p[:, 1]
    # show_results((gru_test_p[:, 1] > 0.35).astype(int), y_test, gru_model, history=None)
    #
    #
    #
    # df_embedding[df_embedding['docDisplayId'].isin(docs)]['docText']
    # p_debug_seq = get_padded_sequence_from_text(tokenizer,
    #                                            df_embedding[df_embedding['docDisplayId'].isin(docs)]['docText'],
    #                                            MAX_SEQUENCE_LENGTH)
    #
    # gru_model.predict(p_debug_seq)[:, 1]
    min_max_equal = True
    while min_max_equal:
        # cnn_model = create_seq_cnn(text_embedding_layer, maxpool=False)
        # history = cnn_model.fit(x_train_padded_seq, y_train_cat,
        #                     batch_size=32, epochs=5,
        #                     validation_split=0.1,
        #                     class_weight=class_weight)

        # create the cnn model and use the train set to trian it
        cnn_model = create_seq_cnn_fixed_kernel_size(text_embedding_layer)
        history = cnn_model.fit(
            x_train_padded_seq,
            y_train_cat,
            batch_size=32,
            epochs=5,
            validation_split=0.1,
            class_weight=class_weight,
        )

        # get prediction for the test set
        prediction_test = cnn_model.predict(x_test_padded_seq)
        p_1 = prediction_test[:, 1]
        if np.max(p_1) - np.min(p_1) >= 0.3:
            min_max_equal = False

    if mode == "DEBUG":
        print(f"min score of test_set: {np.min(p_1)}")
        print(f"max score of test_set: {np.max(p_1)}")
        show_results(
            (prediction_test[:, 1] > 0.2).astype(int), y_test, cnn_model, history
        )
        _ = plt.hist(p_1[y_test == 0], color="r", bins=50, density=True)
        _ = plt.hist(p_1[y_test == 1], color="g", bins=50, alpha=0.8, density=True)

    # todo remove qa
    # df_test1['proba'] = p_1
    # df_test1[['proba', 'docText']].head(10)

    # get the prediction for the train set and set the proba column
    prediction_train = cnn_model.predict(x_train_padded_seq)

    df_embedding.loc[index_train, "proba"] = prediction_train[:, 1]
    df_embedding.loc[index_test, "proba"] = prediction_test[:, 1]

    # todo qa remove
    # x_qa = drugs_text.clean_yediot(df_test1[doc_text])
    # x_qa_padded_seq = get_padded_sequence_from_text(tokenizer, x_qa, MAX_SEQUENCE_LENGTH)
    # print(len(x_qa))
    # prediction_qa = cnn_model.predict(x_qa_padded_seq)
    # df_embedding_qa = df_embedding[qa_msk]
    # df_embedding_qa['proba_new'] = prediction_qa[:, 1]
    # prediction_qa = cnn_model.predict(x_qa_padded_seq)
    # df_embedding_qa['proba_fixed'] = prediction_qa[:, 1]
    # df_embedding_qa[['proba_fixed', 'proba_new','docText']]

    # save the model for later usage (drugs_metadata_create_models is using the proba from cnn as one more feature)
    # the embedding layer is saved implicitly

    cnn_model_file_name = Path(trained_models_dir_cnn + "/cnn_model_" + ts + ".h5")
    cnn_model.save(cnn_model_file_name)

    # save the tokenizer for later usage (we use the same tokenizer in prod to produce the same embedding)
    tokenizer_json = tokenizer.to_json()
    tokenzier_file_name = Path(trained_models_dir_cnn + "/tokenizer_" + ts + ".json")
    with open(tokenzier_file_name, "w", encoding="utf-8") as tokenizer_file:
        tokenizer_file.write(json.dumps(tokenizer_json, ensure_ascii=False))

    prod_config_params = gen_yml["prod"]["input_files"]
    prod_config_params["cnn_model_file"] = cnn_model_file_name.name
    prod_config_params["tokenizer_file"] = tokenzier_file_name.name

    logger.info(f"Exported tokenizer to file: {tokenzier_file_name}")
    logger.info(f"Exported cnn probabilities to file:{cnn_model_file_name}")

    df_embedding_1 = df_embedding.drop(columns=["docText", "label"])

    # todo qa remove!!!
    # df_embedding_1.loc[qa_msk, 'proba'] = None
    # df_embedding_1[qa_msk].head()
    # # todo end qa remove!!!

    df_with_proba_file_name = Path(
        base + "/raw/training/models_results/df_with_proba_from_cnn_" + ts + ".csv"
    )
    df_embedding_1.to_csv(df_with_proba_file_name, header=True, index=False, sep="|")
    logger.info(f"Exported df with cnn probabilties to: {df_with_proba_file_name}")

    gen_yml["drugs_metadata_create_models"][
        "cnn_proba_file"
    ] = df_with_proba_file_name.name

    new_gen_yml_file = gen_yml_file
    with open(new_gen_yml_file, "w") as new_yml_file:
        yaml.dump(gen_yml, new_yml_file)

    # perf_log_df_cnn.to_csv(perf_log_name,
    #                        sep = '|',
    #                        columns=log_cols,
    #                        index=False,
    #                        header=False)
    #
    # print(perf_log_df_cnn.head())

    # dont use pca, it lost too much information
    text_embedding_layer, tokenizer, embedding_matrix = prepare_embedding_layer(
        x_train,
        tokenizer,
        cnn_params=cnn_params["FT_pretrained_model"],
        trainable=False,
        pca_dim=-1,
    )

    logger.info(f"Num of unique tokens from train set: {len(tokenizer.word_index)}")

    y_train_cat = to_categorical(y_train, 2)
    x_train_padded_seq = get_padded_sequence_from_text(
        tokenizer, x_train, MAX_SEQUENCE_LENGTH
    )
    x_test_padded_seq = get_padded_sequence_from_text(
        tokenizer, x_test, MAX_SEQUENCE_LENGTH
    )
    class_weight = drugs_util.get_class_weight(y_train)

    logger.info(
        f"Class weight of training data is: class_0: {class_weight[0]}, class_1: {class_weight[1]}"
    )

    mlflow.end_run()
    run_start_time = time.time()
    with mlflow.start_run() as run:
        min_max_equal = True
        while min_max_equal:
            # create the cnn model and use the train set to trian it
            cnn_model = create_seq_cnn_fixed_kernel_size(text_embedding_layer)
            mlflow.keras.autolog()

            history = cnn_model.fit(
                x_train_padded_seq,
                y_train_cat,
                batch_size=32,
                epochs=5,
                validation_split=0.1,
                class_weight=class_weight,
                verbose=2,
            )

            # get prediction for the test set
            prediction_test = cnn_model.predict(x_test_padded_seq)
            p_1 = prediction_test[:, 1]
            # TODO understand threshold
            THRESHOLD_LIMIT = 0.3
            if np.max(p_1) - np.min(p_1) >= 0.3:
                min_max_equal = False
            mlflow.log_param("THRESHOLD_LIMIT", THRESHOLD_LIMIT)

        if mode == "DEBUG":
            print(f"min score of test_set: {np.min(p_1)}")
            print(f"max score of test_set: {np.max(p_1)}")
            show_results(
                (prediction_test[:, 1] > 0.2).astype(int), y_test, cnn_model, history
            )
            _ = plt.hist(p_1[y_test == 0], color="r", bins=50, density=True)
            _ = plt.hist(p_1[y_test == 1], color="g", bins=50, alpha=0.8, density=True)

        # get the prediction for the train set and set the proba column
        prediction_train = cnn_model.predict(x_train_padded_seq)

        df_embedding.loc[index_train, "proba"] = prediction_train[:, 1]
        df_embedding.loc[index_test, "proba"] = prediction_test[:, 1]

        # TODO See qa remove in test_proba_from_text.py

        # save the model for later usage (drugs_metadata_create_models is using the proba from cnn as one more feature)
        # the embedding layer is saved implicitly

        # The model is already saved by MLflow
        cnn_model_file_name = Path(trained_models_dir + "/cnn_model_" + ts + ".h5")
        # cnn_model.save(cnn_model_file_name)

        # save the tokenizer for later usage (we use the same tokenizer in prod to produce the same embedding)
        tokenizer_json = tokenizer.to_json()
        tokenzier_file_name = Path(trained_models_dir + "/tokenizer_" + ts + ".json")
        with open(tokenzier_file_name, "w", encoding="utf-8") as tokenizer_file:
            tokenizer_file.write(json.dumps(tokenizer_json, ensure_ascii=False))
        mlflow.log_artifact(tokenzier_file_name)

        prod_config_params = gen_yml["prod"]["input_files"]
        prod_config_params["cnn_model_file"] = cnn_model_file_name.name
        prod_config_params["tokenizer_file"] = tokenzier_file_name.name

        logger.info(f"Exported tokenizer to file: {tokenzier_file_name}")
        logger.info(f"Exported cnn probabilities to file:{cnn_model_file_name}")

        df_embedding_1 = df_embedding.drop(columns=["docText", "label"])

        # todo qa remove!!!
        # df_embedding_1.loc[qa_msk, 'proba'] = None
        # df_embedding_1[qa_msk].head()
        # # todo end qa remove!!!

        df_with_proba_file_name = Path(
            base + "/raw/training/df_with_proba_from_cnn_" + ts + ".csv"
        )
        df_embedding_1.to_csv(
            df_with_proba_file_name, header=True, index=False, sep="|"
        )
        mlflow.log_artifact(df_with_proba_file_name)
        logger.info(f"Exported df with cnn probabilties to: {df_with_proba_file_name}")

        gen_yml["drugs_metadata_create_models"][
            "cnn_proba_file"
        ] = df_with_proba_file_name.name

        new_gen_yml_file = gen_yml_file
        with open(new_gen_yml_file, "w") as new_yml_file:
            yaml.dump(gen_yml, new_yml_file)
        mlflow.log_artifact(new_gen_yml_file)

    return run.info.experiment_id, run.info.run_uuid


if __name__ == "__main__":
    experiment_id, run_uuid = main(
        "src/configs/drugs_params_manual.yml",
        "src/configs/drugs_params_generated.yml",
        mode="DEBUG",
        log_level=logging.DEBUG,
    )
