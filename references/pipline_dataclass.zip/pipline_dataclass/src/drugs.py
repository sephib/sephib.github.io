import pandas as pd
import numpy as np

from keras.models import Model
from gensim.models import FastText as FT
from keras.layers import Input, Dense, Embedding, Dropout, Concatenate, Reshape, concatenate
from sklearn.preprocessing import LabelEncoder
from matplotlib.pyplot import hist
import matplotlib.pyplot as plt

from gensim.parsing.preprocessing import preprocess_string, remove_stopwords, stem_text, strip_punctuation, strip_tags, \
    strip_numeric, strip_short
from gensim.models.phrases import Phrases
from gensim.parsing.preprocessing import STOPWORDS
from gensim.utils import tokenize
#import networkx as nx

import re

# play with it to see what gives better results
MAX_CATEGORY_EMBEDDING_DIM = 10

from gensim.models import KeyedVectors



# from sklearn.metrics import roc_curve

# from sklearn.metrics import confusion_matrix
# maybe create a graph of tz in docs such that for ANY 2 tzs in the SAME yedia there is an edge between them - the graph is for all yediot.
# After that convert by node2vec - each tz is a vector
# or compute centrality, ect and add as features
# do it important


from scipy.spatial.distance import correlation
# from scipy.stats import chi2_contingency
# from sklearn.feature_selection import f_regression,mutual_info_regression, mutual_info_classif,VarianceThreshold

from node2vec import Node2Vec
from keras.utils import to_categorical

# from scipy.stats import kstest as ks
# features[features[ordinal_columns].corrwith(features.label).abs().sort_values().index].corrwith(features.label)

# from sklearn.feature_selection import VarianceThreshold,chi2,SelectKBest
# from sklearn.feature_extraction import FeatureHasher



# what we do is creating a list of categorial features, numerical features, text features, graph features
# (for eg: source-target is a graph if there has been a click from source to target)
# do hist or plot on numerical to see if they are at the same level (no too small or too big) - if so, nomalize by taking
# log.
# for categorial, throw away as many values as possible - if the frequency of a value in category is less than 0.5
# make a new general value in the category and convert it to 'general'
# the neural network is taking the categoial features and does embedding:
# it tries to make a column from each value in category, so if there
# are too many values, there will be thousands of features (like happened in hackaton) and the neural network would be
# very very slow.
# text: for a sentence (eg article title) use word2vec to convert each word to vector, after removing punct,
# numeric, tokenizing, etc. Then take the mean vector for all the vectors of the words in the sentence. this vector
# represents the sentence. Now you can run some clustering algorithm (k-mean for eg) to cluster the vectors, lets say to 10
# categories
# node2vec to do the same for graphs
# after word to vec the vecore col belongs to text cols
categorical, text, numerical, label = column_list()

# convert the label to categorical for the nn 0->01 1-> 10
label_cat = to_categorical(label, 2)




# create a mean vector for the vectors of the words composing a sentence
# this method is appropriate for short texts like a title or something like this,
# which has a message: a title about sports, politics, etc. The mean vector is
# some type of clustring
# for longer texts will follow
def short_text_embedding(df, col, new_vec_col, new_vec_mean_col):
    df[new_vec_col] = df[col].apply(prepare_text)
    df['vecs_arr'] = df[new_vec_col].apply(lambda x: np.array(x))
    df[new_vec_mean_col] = df['vecs_arr'].apply(lambda x: np.mean(x, axis=0))
    return df


def main():

    df = pd.read_excel(r'~/projects/drugs_trafficking/data/samimClassified.xlsx', encoding='Windows-1252')
    col_names = {'מיכל': 'Michal', 'אסתר': 'Ester/Moran', 'הפרש': 'Hefresh', 'החלטה קרן': 'keren_decision'}
    df.rename(columns=col_names, inplace=True)

    msk = split_df(df)

    # create a graph as explained below but sine it is a bit complicated to move to node2vec, for first stage create centrality, betweeness, add them
    # as numerical cols to the df and treat as nemerical oridinal columns

    G = graph(df)
    df = create_graph_measures(df, G)

    categorical_train_data, categorical_test_data, \
        embedding_categorical, input_categorical, le_list = categorical_embedding(df, categorical, MAX_CATEGORY_EMBEDDING_DIM, msk)

    numerical_train_data, numerical_test_data, numerical_mean, numerical_std = numerical_feature_scaling(df, numerical, msk)

    X_text_test, X_text_train, text_embedding_layer = text_embedding(df)


    # graph_nodes, graph_vecs = to_graph(df)
    # create_model is a method to create a generic model - and compile it
    model = create_model()
    history = model.fit([numerical_train_data] + categorical_train_data, label_cat[~msk],
                        validation_data=([numerical_test_data] + categorical_test_data, label_cat[msk]), batch_size=32,
                        epochs=5)
    history = model.fit(categorical_train_data, label_cat[~msk], validation_data=(categorical_test_data, label_cat[msk]),
                        batch_size=32, epochs=5)

    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.legend(['train', 'test'])
    plt.title('demo ')
    plt.ylabel('accuracy ')
    plt.xlabel('epoch ')


def word():
    from sklearn.metrics.pairwise import cosine_similarity
    dict_vals = [word2vec1[key] for key in word2vec1.keys()]
    dict_keys = [key for key, val in word2vec1.items()]
    x = cosine_similarity(word2vec1['ROMY'].reshape(1, -1), np.array(dict_vals))
    s = (-x).argsort()[:10][0]
    for i in s[:20]:


# print(dict_keys[i])



def column_list():
    categorical = ['user_id', 'browser_platform', 'os_family', 'os_name', 'country_code', 'region', 'non_work_hours',
                   'target_id',
                   'syndicator_id',
                   'campaign_id',
                   'campaign_language', 'content_category', 'ad_type',
                   'placement_id', 'publisher_id', 'source_id', 'source_item_type', 'dayofweek']

    text = ['title', 'target_item_alchemy_taxonomies']

    numerical = ['empiric_recs_log', 'empiric_clicks_log', 'quality_level', 'user_recs_log', 'user_clicks_log',
                 'user_target_recs', 'hour', 'empiric_prb', 'user_prb']

    label = 'is_click'

    # todo add the nodetovec from graph
    return categorical, text, numerical, label


#  ONLY FOR columns which are CATEGORICAL
#  NUM = MAX EMBEDDING DIMENSION FOR EACH FEATURE

def split_df(df, test_frac=0.2):
    msk = np.random.rand(len(df)) < test_frac
    # df_test = df[msk]
    # df_train = df[~msk]
    return msk

def categorical_embedding(df, columns, embedding_dim, msk):
    import re

    train_data = []
    test_data = []

    le_list = {}
    input_layers = []
    embeddings_list = []
    for column in columns:
        le = LabelEncoder()

        # note 1 that here we assume we know all the world of the features, so we fit the whole df. in real world, many times we don't know all possible values for category, maybe change the code
        # note 2 - if there are many calsses in the catgory clean up so that the final result contains the most frequent values - להעיף אץ הנדירים
        # note 3 - do all cleanings of feature before going into keras.Input and keras.Embedding layers - exploratory part of the data
        le.fit(df[column].to_list())
        train_data.append(le.transform(df[column][~msk].tolist()).reshape(-1, 1))
        test_data.append(le.transform(df[column][msk].tolist()).reshape(-1, 1))
        le_list[column] = le

        # keras.Input - this is a nn layer
        # define the Inputs for the feature embbeding box. shape: the sliding windows size it looks at. for categorical it is 1.
        # if the feature is a tuple (ngrams) of 3 values, then it is 3.
        # For text since there is a meaning in the seqence, it should be larger than 1.

        #IMPORTANT: Input is a keras structure/layer - NOT data yet
        cat_input = Input(shape=(1,), dtype='int32', name=re.sub(r'\W+', '', column))
        # the output of the prev line is appended into a structure and this structure is the input for the nn - the output of each Input line is a vector with all values in this categorical feature, and all of these vectors are appnded
        # and fed into the nn
        # structure for example: [city vec, zip vec, colr vec...]
        input_layers.append(cat_input)
        # embedding_size is the size of column vector
        # embedding_dim is the max dim we want - if there are too many values in the category
        # for amlach optimal max_embedding_dim was 1!!!! maybe the data is not relevant, or too small datasets. PLAY with this parameter
        embedding_size = int(min(np.ceil(len(le.classes_) / 2),
                                 embedding_dim))  # todo heurisicts from Fast.ai course (changed to max=10 from originally 50)

        # This is the Embedding layer of the catgorical features - we are embedding the cat_input.
        # find what input_length is
        # the Embeddings are also appended.
        # IMPORTANT: Embedding is a keras structure/layer - NOT data yet. The input for Embedding is Input
        cat_embedding = Embedding(input_dim=len(le.classes_), output_dim=embedding_size, input_length=1)(cat_input)
        cat_embedding = Reshape(target_shape=(embedding_size,))(cat_embedding)

        embeddings_list.append(cat_embedding)

        #embedding_layers = Concatenate('input_categorical')(embeddings_list)

    # train_data and train_test are the real DATA for the nn
    # so at the end of this method we have data and first+second structure/layer of nn (the embedding leyer)
    return train_data, test_data, input_layers, embeddings_list, le_list


def create_model(df):

    X_categorical_train_data, X_categorical_test_data, cat_input_layer, cat_embedding_list, le_list = categorical_embedding(df, categorical,
                                                                              MAX_CATEGORY_EMBEDDING_DIM, msk)

    X_numerical_train_data, X_numerical_test_data, numerical_mean, numerical_std = numerical_feature_scaling(df, numerical,
                                                                                                         msk)

    X_text_train, X_text_test, text_embedding_layer = text_embedding(df)

    # play with it - try different combinations of feature types as Input to model and try it

    input_ordinal_numerical = Input(shape=(X_numerical_train_data.shape[1],), name='input_ordinal_numerical')

    # This is the graph input
    # input_graph = Input(shape=(X_graph_train[0].shape[0],), name='input_graph')

    # Dense is a simple layer - linear sum of inputs, at the end of it there is activation which is not linear

    # hidden_graph = Dense(2, activation='relu',name='hidden_graph')(input_graph)
    # hidden_graph = Dense(2, activation='relu',name='hidden_graph')(input_graph)

    # concat all categorical embeddings
    embedding_all_categorical = Concatenate(name='input_categorical')(cat_embedding_list)

    input_text = Input(shape=(MAX_SEQUENCE_LENGTH,), name='input_text')  # , dtype='int32')
    embedded_text = text_embedding_layer(input_text)

    # Conv1D is a filter - Keras
    text_cnn = Conv1D(16, 2, activation='relu', name='text_cnn')(embedded_text)
    # text_cnn = MaxPooling1D(2)(text_cnn)
    # text_cnn = Conv1D(8, 2, activation='relu')(text_cnn)
    # x = MaxPooling1D(5)(x)
    # x = Conv1D(128, 5, activation='relu')(x)
    text_pool = GlobalMaxPooling1D(name='text_pool')(text_cnn)
    joined_input = Concatenate()([input_ordinal] + [input_graph] + [text_pool])

    joined_input = Concatenate()([input_ordinal] + [input_text])

    joined_input = Concatenate()([input_ordinal] + [input_graph])

    #keras.Dense is a simple layer - does linear sum on matrix and then activation (non linear)
    out = Dense(2, activation='softmax')(joined_input)
    model = Model(inputs=[input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])
    model = Model(inputs=[input_ordinal] + [input_graph], outputs=[out])  # ,auxiliary_output])
    model = Model(inputs=[input_ordinal] + [input_graph] + [input_text], outputs=[out])  # ,auxiliary_output])
    model.compile(loss='binary_crossentropy', metrics=['accuracy'], optimizer='adam')

    model.fit([X_ordinal_train] + [X_graph_train], y_train_cat, batch_size=32, epochs=5)
    model.fit([X_ordinal_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
    model.fit([X_ordinal_train] + [X_graph_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
    pred_soft = np.diff(model.predict([X_ordinal_test] + [X_text_test]))
    pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test]))
    pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test] + [X_text_test]))



    roc_auc_score(y_test, pred_soft)

    plt.figure(4)
    plt.hist(pred_soft[y_test == 0], color='r', bins=50, density=True)
    plt.hist(pred_soft[y_test == 1], color='g', bins=50, alpha=0.8, density=True)

    return model


def to_graph(df):
    msk_g = (df['is_click'] == 1)
    edge_df = df[['source_id', 'target_id']][msk_g]
    G = nx.from_pandas_edgelist(edge_df, source='source_id', target='target_id')
    node2vec = Node2Vec(G, dimensions=4, walk_length=8, num_walks=4, workers=1, p=1, q=1)
    graph_model = node2vec.fit(window=4, min_count=1)
    graph_nodes = list(graph_model.wv.vocab)
    graph_vecs = graph_model[graph_nodes]
    return graph_nodes, graph_vecs


# cleaning the numerical-ORDINAL columns (zip code is numerical-categorical)
# nomalize to be between 0 and 1
# find exceptional values and decide what to do with them - boxcox can help, it decides if to take log or some other function - the purpose: make the data to be gaussian distribution
# do binning
# find correlation between cols (in categorical as well) and discard correlated columns
def numerical_feature_scaling(df, numerical, msk):  # todo, scaling='StandardScaler'):

    # use sklearn.preprocessing.KBinsDiscretizer to do the binning
    # or QuantileTransformer - also for binning?
    # boxcox is overkill maybe and not enough in case we have 2 peaks
    # manually do:
    # normalize to 0-1
    # check of log is making it gaussian (check with skewness if it is better afte log)
    # binning if needed
    # again normilize to 0-1 (this is what nn needs) - note that this also works if we did binning
    # Important: If using boxcox or any other automatic transformation algoritm - save the transformation - it should be applied to the future test sets!

    df = df[numerical]
    df_mean = df.mean()
    df_std = df.std()
    df = (df - df.mean()) / df.std()

    #   df = df.fillna(0)# todo decide what to do with NaN


    from sklearn.preprocessing import RobustScaler, MinMaxScaler, StandardScaler, QuantileTransformer

    # if(scale is None):
    # scale = QuantileTransformer(output_distribution='normal')  # MinMaxScaler(), todo PowerTransformer(method='box-cox')

    # before taking log:
    # dfmin = df.min()
    # dfmax = df.max()
    # df = (df - dfmin) / (dfmax - dfmin) + 0.01

    # df_test = (df_test - dfmin) / (dfmax - dfmin) + 0.01
    # def myboxcox(x):
    #     x = boxcox(x)
    #     return x[0]
    #
    # from scipy.stats import boxcox
    #
    #
    # df = df.apply(myboxcox, axis=0)
    #
    # df = (df - df.mean()) / df.std()
    # return df[~msk].values, df[msk].values
    #
    #  return np_scaled, scale

    # This method return only DATA for nn
    # df_mean, df_std is for suture use if we want to normilize new data
    return df[~msk].values, df[msk].values, df_mean, df_std

# the results are numerical and should be added to the numerical columns after normalizing between 0 and 1 - no need to log, bin etc
# check the graph of centerality and see if to bin
def create_graph_measures(df, G):

eg = nx.eigenvector_centrality(G, max_iter=200)
eg_df = pd.DataFrame(btw.items(), columns=['source_id', 'eigen_centrality'])
df = df.merge(eg_df, right_on='source_id', left_on='source_id')

deg = G.degree()
deg_df = pd.DataFrame(deg, columns=['source_id', 'degree'])
df = df.merge(deg_df, right_on='source_id', left_on='source_id')

btw = nx.betweenness_centrality(G)
btw_df = pd.DataFrame(btw.items(), columns=['source_id', 'betweeness'])
df = df.merge(btw_df, right_on='source_id', left_on='source_id')

return df


# From weapon trafficking

# text embedding
##################################################

# choose using create_heb_dict_from_doc or load_heb_dict_from_wikipedia - see which one gives better results

def create_heb_dict_from_yediot(texts):
    # Read the excel calssified file into features
    # docText is the text column
    # possible to create (offline) verbs, nouns, prop names using YAP and then do the training

    #texts = features['docText'].values
    # texts = features['VB'].values
    #texts = features['NN'].values
    # texts = features['NNP'].values
    #now create the arrays of dim = 100 , note that of samim docs, there are few words, so choose dim = ~50
    #play with it - try to find close words in the dict to choose better dim

    model_FT = FT(size=100,min_count=1) #min_count = treat words which appear 1+ times
    model_FT.build_vocab(texts)
    model_FT.train(texts,total_examples=model_FT.corpus_count, epochs=model_FT.epochs)
    words_FT = list(model_FT.wv.vocab)
    vecs_FT = model_FT.wv.__getitem__(words_FT)
    return model_FT, words_FT, vecs_FT

# load pretrained model - from wikipedia
def load_heb_dict_from_wikipedia():
    heb_model = KeyedVectors.load_word2vec_format('/rData/Hebrew_NLP/wiki.he.vec')


# add bigrams (couples of words like "mispar rishuy")

# cleaning text and creating bigrams
#clean the code here
def clean_heb_text(text):
    f = open('/rData/Hebrew_NLP/Hebrew_stop_words.txt')
    stpwrds = f.read().split()
    import re
    text_clean = text

    # CUSTOM_FILTERS = [strip_punctuation, strip_numeric]
    # tokens = preprocess_string(str1, CUSTOM_FILTERS)

    for x in ["'", '"']:
        text_clean = text_clean.replace(x, "")
    for x in ['\xd5d', '\n', "!", '.', '#', '$', '%', '&', '(', ')', '*', '+', ',', '-', '/', ':', ';', '<', '=', '>',
              '?', '@', '[', '^', ']', '_', '`', '{', '|', '}', '~', '\t']:
        text_clean = text_clean.replace(x, " ")

    text_clean = re.sub('[0-9]+', 'מספר', text_clean)
    text_clean = text_clean.split()
    text_clean = [w for w in text_clean if not w in stpwrds]
    #print (text_clean)

    #tokens = list(tokenize(text_clean))
    #tokens = [x for x in  if x.lower() not in STOPWORDS]
    #text_clean = " ".join(text_clean)
    print (text_clean)
    bigram_mdl = Phrases(text_clean, min_count=1, threshold=2)

    tokens = [t for t in text_clean if len(t) > 2]
    bigrams = bigram_mdl[tokens]
    words = list(bigrams)
    print(f'words:******{words}')

    words = [re.sub('_', '-', word) for word in words]
    #vecs = [word2vec1[word] if word in word2vec1.keys() else np.zeros(shape=(1, 20)) for word in words]
    #return words
    return text_clean


def clean_yediot(df):
    text_list = df['docText'].tolist()

    # texts = []
    # text_list = []
    # for i in df.index:
    #     text_list.append(df.loc[i, 'docText'])
    #texts = df['docText'].values
    # clean text using one of the methods

    clean_texts = []
    for t in text_list:  # .values:#for i in negative_train_text.index:
        t_clean = clean_heb_text(t)
        clean_texts.append(t_clean)
    return texts

def tokenize_texts(df):

    MAX_NB_WORDS = 30000
    # the mean count of words of yedia, if we take the max count, many sentences will be padded with zeros.
    MAX_SEQUENCE_LENGTH = 150

    from keras.preprocessing.text import Tokenizer
    from keras.preprocessing.sequence import pad_sequences



    # tokenizer is the input to the keras.Input layer for text
    # look at documentation of keras.token - only frequent words are in if the max_nb_words is too small
    # note that when create the tokenizer with 30000 words, nassati an nassnu are each one word. YAP can fix this, this is called
    # lematization or steming (in english it is simpler - plays, playing, played are all converted to play before
    # tokenizing, amybe look for some ther hebrew stemmer)
    # also - מעבודה לעבודה is also different words, and YAP knows to seperate "from/to" from the words. Important to try it

    tokenizer = Tokenizer(num_words=MAX_NB_WORDS)

    texts = clean_yediot(df)


    # one hot key: each word gets a number between 0.. MAX_NB_WORDS
    tokenizer.fit_on_texts(texts)

    # convert the sentece to sequence of hot keys
    sequences = tokenizer.texts_to_sequences(texts)

    word_index = tokenizer.word_index
    print('Found %s unique tokens.' % len(word_index))

    # we decides that the mean count word in sentence is MAX_SEQUENCE_LENGTH (150), it pads the shorter sentences with zeros so that the result is a vector of dim 1*n for each sentence. Matrix of m*n for all text
    sequences = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)

    sequences = np.array(sequences)
    X_text_train = sequences[~msk]  # features['docText'][~msk].values
    X_text_test = sequences[msk]  # features['docText'][msk].values

    return X_text_train, X_text_test, word_index

def main1():
    #Gila 4 July 19
    df = pd.read_excel(r'~/projects/drugs_trafficking/data/samimClassified.xlsx', encoding='Windows-1252')
    col_names = {'מיכל': 'Michal', 'אסתר': 'Ester/Moran', 'הפרש': 'Hefresh', 'החלטה קרן': 'keren_decision'}
    df.rename(columns=col_names, inplace=True)

    texts = clean_yediot(df)
    # create dict either from the yediot or from wikipedia
    model_FT, words_FT, vecs_FT = create_heb_dict_from_yediot(texts)

def create_text_embedding_model(texts):
    # either:
    #model = load_heb_dict_from_wikipedia()
    # or

    model_FT, words_FT, vecs_FT = create_heb_dict_from_yediot(texts)
    return model or model_FT

def text_embedding(df):

    from keras.layers import Dense, Input, GlobalMaxPooling1D, Flatten, Activation, Reshape, dot, multiply, add, \
        average, GlobalAveragePooling1D
    from keras.layers import Conv1D, MaxPooling1D, Embedding, concatenate, UpSampling1D
    from keras.models import Model
    from sklearn.metrics import f1_score
    from sklearn.metrics import roc_auc_score, confusion_matrix, precision_score, recall_score
    import matplotlib.pyplot as plt

    # Preparing the text Embedding layer

    X_text_train, X_text_test, word_index = tokenize_texts()
    heb_model = create_text_embedding_model()

    EMBEDDING_DIM = heb_model.vector_size

    # Preparing the Embedding layer FT

    embedding_matrix = np.zeros((len(word_index) + 1, EMBEDDING_DIM))  # adding 1 to account for 0th index (for masking)
    for word, i in word_index.items():
        if word in heb_model:
            embedding_vector = heb_model[word]
        else:
            # words not found in embedding index will have random value
            embedding_vector = np.random.uniform(-0.25, 0.25, EMBEDDING_DIM)
        embedding_matrix[i] = embedding_vector

    # load the word_vector matrix to the Embedding layer
    # the model was trained in model creating, her we put it in the embedding layer, and van further train (trainable=True)
    # or not (trainable = False) - play with it to see what gives better results
    text_embedding_layer = Embedding(len(word_index) + 1,
                            EMBEDDING_DIM,
                            weights=[embedding_matrix],
                            input_length=MAX_SEQUENCE_LENGTH,
                            trainable=False)

    # Retrun real data and embedding layer for text for nn
    return X_text_train, X_text_test, text_embedding_layer


#####################
###############
#**************************************************

# ONLY FOR NUMERIC

#

def data_statistics(features, ordinal_columns):
    column_select = pd.DataFrame(
        columns=['col', 'null_proportion', 'type', 'corr', 'pvalue', 'mutual_information', 'nunique', 'corr_dis',
                 'eer'])
    for column in ordinal_columns:
        type = 'numeric' if column in ordinal_columns else 'category'

        feature_code = features[column][~pd.isna(features[column])]

        null_proportion = 1 - (len(feature_code) / len(features[column]))

        y_column = features[label][~pd.isna(features[column])]

        feature_code = feature_code.astype('category').cat.codes if type == 'category' else feature_code
        corr = feature_code.corr(y_column) if type == 'numeric' else 0

        df_crosstab = pd.crosstab(index=features[column], columns=y_column)
        pvalue = chi2_contingency(df_crosstab)[1] if (null_proportion != 1) else 1

        # variance = VarianceThreshold().fit(feature_code.values)

        eer1, _ = eer(feature_code, y_column)
        corr_dis = correlation(feature_code, y_column)

        mi = mutual_info_classif(feature_code.values.reshape(-1, 1), y_column.values)
        column_select.loc[len(column_select)] = (
        [column, null_proportion, type, corr, pvalue, mi, feature_code.nunique(), corr_dis, eer1])

    column_select = column_select.sort_values(by=['corr'])
    return column_select


cat_columns, ordinal_columns, label = columns_list()

# Read data
features, iediot, iediot_taz, G = read_data()

Taz_list = features['TZ'].drop_duplicates()


# for column in ordinal_columns:

# df = features[ordinal_columns]


# FeatureHasher(n_features=)


# threshold = 0.9
# cross_corr = np.empty((len(ordinal_columns),len(ordinal_columns),))
# cross_corr[:] = np.nan
# for i in range(len(ordinal_columns)):
#     for j in range(i+1,len(ordinal_columns)):
#         msk = (~pd.isna(features[ordinal_columns[i]]))&(~pd.isna(features[ordinal_columns[j]]))
#         cross_corr[i,j] =np.abs(features[ordinal_columns[i]][msk].corr(features[ordinal_columns[j]][msk]))
# cross_corr = pd.DataFrame(cross_corr)
# to_drop = [column for column in cross_corr.columns if any(cross_corr[column]>threshold)]

# cross_corr.drop(cross_corr.columns[to_drop],axis=1)

# no_corr_value = [ordinal_columns[column] for column in range(len(ordinal_columns)) if column not in to_drop ]

# no_corr_value_index = [column for column in range(len(ordinal_columns)) if column not in to_drop ]


# from scipy.stats import boxcox
# X_ordinal, _ = feature_scaling(features, ordinal_columns)

# column = 1
# for column in range(X_ordinal.shape[1]):
#     X_ordinal[:, column] = boxcox(X_ordinal[:,column]+0.05)[0]#np.finfo('float').eps)[0]


# hist(X_ordinal_box[:,0],bins = 50)

# split train/test partitions


# normalize features to 0-1 range
# X_ordinal_train, scale = feature_scaling(df_train, ordinal_columns)
# X_ordinal_test,_ = feature_scaling(df_test, ordinal_columns,scale=scale)
# del scale
# no_corr_value


##########################
#####   GRAPH + TEXT  #####
##########################


def clean_text(text):
    # f = open('/rData/Hebrew_NLP/Hebrew_stop_words.txt')
    # stpwrds = f.read().split()
    import re
    text_clean = text
    for x in ["'", '"']:
        text_clean = text_clean.replace(x, "")
    for x in ['\xd5d', '\n', "!", '.', '#', '$', '%', '&', '(', ')', '*', '+', ',', '-', '/', ':', ';', '<', '=', '>',
              '?', '@', '[', '^', ']', '_', '`', '{', '|', '}', '~', '\t']:
        text_clean = text_clean.replace(x, " ")
    text_clean = re.sub('[0-9]+', 'מספר', text)
    text_clean = text_clean.split()
    # text_clean = [w for w in text_clean if not w in stpwrds]
    return text_clean


# test = iediot['docText'].apply(clean_text)


#########################
####### node2vec ########
#########################

# from node2vec import Node2Vec
# import networkx as nx
#
# #node2vec = Node2Vec(G, dimensions=4, walk_length=8, num_walks=4, workers=1, p=1,q=1)
# #graph_model = node2vec.fit(window=4, min_count=1)
#
#
# node2vec = Node2Vec(G, dimensions=6, walk_length=6, num_walks=8, workers=1, p=1,q=1)
# graph_model = node2vec.fit(window=4, min_count=1)
# walks = node2vec.walks
# graph_tz = list(graph_model.wv.vocab)
# graph_vecs = graph_model[graph_tz]


graph_vecs = np.load('/home/u015734825/projects/weapontrafficking/src/text_graph_py/graph_vecs.npy')
graph_tz = np.load('/home/u015734825/projects/weapontrafficking/src/text_graph_py/graph_tz.npy')

df_vecs = pd.DataFrame(graph_vecs, graph_tz, columns=['n2v_0', 'n2v_1', 'n2v_2', 'n2v_3'])

features = pd.merge(features, df_vecs, how='left', left_on='TZ', right_index=True)
features = features.fillna(0)

gr = list(graph_tz)
grv = graph_vecs

# features.drop(columns=['vecs'],inplace = True)

features['index_vecs'] = features['Taz'].apply(lambda x: gr.index(x) if x in gr else -1)
features['vecs'] = features['index_vecs'].apply(lambda x: grv[x] if x != -1 else np.zeros(grv.shape[1]))
features.drop(columns=['index_vecs'], inplace=True)

features_text = pd.merge(iediot_taz[['docId', 'Taz']], iediot[['Docid', 'docText', 'VB', 'NN', 'NNP']], how='left',
                         left_on='docId', right_on='Docid')

# each taz one row
features_text = features_text.groupby(by='Taz')['docText'].apply(lambda x: clean_text(' '.join(x)))
features = pd.merge(features, features_text, how='left', left_on='TZ', right_index=True)

# taz-to-text (one row for each taz in the iedia)
features_text['docText'] = features_text['docText'].apply(clean_text)
features = pd.merge(features, features_text[['docText', 'VB', 'NN', 'NNP', 'Taz']], how='left', left_on='TZ',
                    right_on='Taz')

# mask for taz lines
msk = split_df(features, test_frac=0.5)

# mask for duplicated text-taz lines
msk = features.TZ.isin(Taz_list[split_df(Taz_list, test_frac=0.5)])

TAZ_test = features[msk][['TZ']]
# features = features_copy

import itertools

# X_text_train = features_all['docText'][~msk].values
# X_text_test = X_ordinal[msk].values
#
# X_graph_train = df_features['vecs'][~msk].values
# X_graph_test = df_features['vecs'][msk].values


connection = pd.merge(iediot_taz[['docId', 'Taz']], iediot_taz[['docId', 'Taz']], how='outer', on='docId')
connection.columns = ['docId', 'Taz', 'target']
connection = connection[connection.Taz != connection.target]
connection_text = pd.merge(connection, iediot[['docText', 'Docid']], how='left', right_on='Docid', left_on='docId')

# connection_text = pd.merge(connection_text,features[['n2v_0', 'n2v_1', 'n2v_2', 'n2v_3','TZ']],how='left',left_on='Taz', right_on='TZ')
# connection_text = connection_text.drop('TZ',axis = 1).drop_duplicates()
# connection_text = connection_text.rename({'n2v_0':'n0', 'n2v_1':'n1',  'n2v_2':'n2',  'n2v_3':'n3'},axis = 1)

connection_text = pd.merge(connection_text, features[cat_columns + ordinal_columns + [label] + ['TZ']], how='left',
                           left_on='Taz', right_on='TZ')
connection_text = connection_text.drop('TZ', axis=1).drop_duplicates()
connection_text = pd.merge(connection_text, features[['n2v_0', 'n2v_1', 'n2v_2', 'n2v_3', 'TZ']], how='left',
                           left_on='target', right_on='TZ')
connection_text = connection_text.drop('TZ', axis=1).drop_duplicates()

connection_text['docText'] = connection_text['docText'].apply(clean_text)

features_temp = features.copy()

features = connection_text.copy()

# add partner node2vec

ordinal_columns = ordinal_columns + ['n2v_0_y', 'n2v_1_y', 'n2v_2_y', 'n2v_3_y', 'n2v_0_x', 'n2v_1_x', 'n2v_2_x',
                                     'n2v_3_x']

X_ordinal = feature_scaling(features[ordinal_columns])

column_select = data_statistics(features, ordinal_columns)
ordinal_hi_corr = column_select['col'][column_select['corr'].abs() > 0.05].index
ordinal_hi_corr = ordinal_hi_corr + [136, 137, 138, 139]
# selected high correlation features without graph features
# ordinal_hi_corr =[ 120, 122, 121, 104,  19,  18, 119,  20, 100,  44,  93,55,  78, 126,  36,  13,  26,  89,  92, 123,  54,  16,  25,  24,6,  15,  14,  23,  63, 125, 111],

#
# column_select = features[ordinal_columns].corrwith(features[label])#data_statisti-cs(features,ordinal_columns)
# ordinal_hi_corr = [column_select.abs()>0.05].index


y_train = features[label][~msk].astype('int').values
y_test = features[label][msk].astype('int').values

y_test_cat = to_categorical(y_test, 2)
y_train_cat = to_categorical(y_train, 2)

X_ordinal_train = X_ordinal[~msk].values
X_ordinal_test = X_ordinal[msk].values

X_ordinal_train = X_ordinal_train[:, ordinal_hi_corr]
X_ordinal_test = X_ordinal_test[:, ordinal_hi_corr]

X_categorical_train, X_categorical_test, embedding_categorical, input_categorical = feature_embedding(features[~msk],
                                                                                                      features[msk],
                                                                                                      cat_columns, 1)

#####
# GRAPH
#####
X_graph_train = np.stack(features['vecs'][~msk].values, axis=0)
X_graph_test = np.stack(features['vecs'][msk].values, axis=0)

#######
# build word2vec from iediot
#########
# texts = []
# import re
# for t in iediot['docText']:#.values:#for i in negative_train_text.index:
#     t = remove_punct(t)
#     t = re.sub('[0-9]+', 'מספר', t)
#     t = t.split()
#     texts.append(t)


# text_yap = []
# for a, b in zip(NNP,VB):
#     yap = a + b
#     text_yap.append(yap)

# train embedding
#############
# text_all = texts
from gensim.models import FastText as FT

# texts = np.load('/home/u015734825/projects/weapontrafficking/src/text_graph_py/VB.npy')

# choose one
texts = features['docText'].values
# texts = features['VB'].values
texts = features['NN'].values
# texts = features['NNP'].values

model_FT = FT(size=100, min_count=1)
model_FT.build_vocab(texts)
model_FT.train(texts, total_examples=model_FT.corpus_count, epochs=model_FT.epochs)
words_FT = list(model_FT.wv.vocab)
vecs_FT = model_FT.wv.__getitem__(words_FT)

# load pretrained model
from gensim.models import KeyedVectors
from gensim.test.utils import datapath

eng_model = FT.load_fasttext_format('C:\Users\OSUser\Downloads\cc.en.300.bin')

#####
# build TEXT features
#####
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from sklearn.metrics import roc_auc_score

MAX_NB_WORDS = 30000
MAX_SEQUENCE_LENGTH = 150

tokenizer = Tokenizer(num_words=MAX_NB_WORDS)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
word_index = tokenizer.word_index
print('Found %s unique tokens.' % len(word_index))
sequences = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)

sequences = np.array(sequences)
X_text_train = sequences[~msk]  # features['docText'][~msk].values
X_text_test = sequences[msk]  # features['docText'][msk].values

# Preparing the Embedding layer
EMBEDDING_DIM = heb_model.vector_size
embedding_matrix = np.zeros((len(word_index) + 1, EMBEDDING_DIM))  # adding 1 to account for 0th index (for masking)
for word, i in word_index.items():
    if word in heb_model:
        embedding_vector = heb_model[word]
    else:
        # words not found in embedding index will be  For words that occur will have (approximately) same variance as pre-trained ones
        embedding_vector = np.random.uniform(-0.25, 0.25, EMBEDDING_DIM)
    embedding_matrix[i] = embedding_vector

# Preparing the Embedding layer FT
EMBEDDING_DIM = model_FT.vector_size
embedding_matrix = np.zeros((len(word_index) + 1, EMBEDDING_DIM))  # adding 1 to account for 0th index (for masking)
for word, i in word_index.items():
    if word in model_FT:
        embedding_vector = model_FT[word]
    else:
        # words not found in embedding index will be  For words that occur will have (approximately) same variance as pre-trained ones
        embedding_vector = np.random.uniform(-0.25, 0.25, EMBEDDING_DIM)
    embedding_matrix[i] = embedding_vector

# Load to embedding layer
from keras.layers import Dense, Input, GlobalMaxPooling1D, Flatten, Activation, Reshape, dot, multiply, add, average, \
    GlobalAveragePooling1D
from keras.layers import Conv1D, MaxPooling1D, Embedding, concatenate, UpSampling1D
from keras.models import Model
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, confusion_matrix, precision_score, recall_score
import matplotlib.pyplot as plt

embedding_layer = Embedding(len(word_index) + 1,
                            EMBEDDING_DIM,
                            weights=[embedding_matrix],
                            input_length=MAX_SEQUENCE_LENGTH,
                            trainable=False)

#####################
###############
input_ordinal = Input(shape=(X_ordinal_train.shape[1],), name='input_ordinal')
joined_input = Concatenate()([input_ordinal] + [input_graph] + [text_pool])
model = Model(inputs=[input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])

input_graph = Input(shape=(X_graph_train[0].shape[0],), name='input_graph')
# hidden_graph = Dense(2, activation='relu',name='hidden_graph')(input_graph)
# hidden_graph = Dense(2, activation='relu',name='hidden_graph')(input_graph)
embedding_all_categorical = Concatenate(name='input_categorical')(embedding_categorical)
input_text = Input(shape=(MAX_SEQUENCE_LENGTH,), name='input_text')  # , dtype='int32')
embedded_text = embedding_layer(input_text)
text_cnn = Conv1D(16, 2, activation='relu', name='text_cnn')(embedded_text)
# text_cnn = MaxPooling1D(2)(text_cnn)
# text_cnn = Conv1D(8, 2, activation='relu')(text_cnn)
# x = MaxPooling1D(5)(x)
# x = Conv1D(128, 5, activation='relu')(x)
text_pool = GlobalMaxPooling1D(name='text_pool')(text_cnn)
joined_input = Concatenate()([input_ordinal] + [input_graph] + [text_pool])
joined_input = Concatenate()([input_ordinal] + [input_graph] + [text_pool])

joined_input = Concatenate()([input_ordinal] + [input_text])

joined_input = Concatenate()([input_ordinal] + [input_graph])

out = Dense(2, activation='softmax')(joined_input)
model = Model(inputs=[input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])
model = Model(inputs=[input_ordinal] + [input_graph], outputs=[out])  # ,auxiliary_output])
model = Model(inputs=[input_ordinal] + [input_graph] + [input_text], outputs=[out])  # ,auxiliary_output])
model.compile(loss='binary_crossentropy', metrics=['accuracy'], optimizer='adam')

model.fit([X_ordinal_train] + [X_graph_train], y_train_cat, batch_size=32, epochs=5)
model.fit([X_ordinal_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
model.fit([X_ordinal_train] + [X_graph_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
pred_soft = np.diff(model.predict([X_ordinal_test] + [X_text_test]))
pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test]))
pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test] + [X_text_test]))

roc_auc_score(y_test, pred_soft)

plt.figure(4)
plt.hist(pred_soft[y_test == 0], color='r', bins=50, density=True)
plt.hist(pred_soft[y_test == 1], color='g', bins=50, alpha=0.8, density=True)

th = np.arange(-0.9, 0.9, 0.05)
f1_scores = [f1_score(y_test, pred_soft > t) for t in th]
recall_scores = [recall_score(y_test, pred_soft > t) for t in th]
precison_scores = [precision_score(y_test, pred_soft > t) for t in th]
plt.plot(th, f1_scores)
plt.figure(5)
plt.plot(th, recall_scores, th, precison_scores)
cm = confusion_matrix(y_test, pred_soft > th[np.argmax(f1_scores)])

# -------------


TAZ_test1 = TAZ_test.reset_index(drop=True)

test = pd.DataFrame([pred_soft[:, 0], y_test, TAZ_test1.TZ]).T

f1 = []
th = np.arange(-0.75, 0.75, 0.05)
for t in th:
    print(t)
    test_group = test.groupby([2]).agg({0: lambda x: int(((x > t).mean()) > 0.5), 1: max})
    f1.append(f1_score(test_group[1].values, test_group[0]))
plt.figure(6)
plt.plot(th, f1)

test_group = test.groupby([2]).agg({0: lambda x: len(x), 1: max})

test_group = test.groupby([2]).agg({0: lambda x: x.max(), 1: max})

roc_auc_score(test_group[1].values, test_group[0])

plt.figure(4)
plt.hist(test_group[0][test_group[1] == 0], color='r', bins=50, density=True)
plt.hist(test_group[0][test_group[1] == 1], color='g', bins=50, alpha=0.8, density=True)

th = np.arange(-0.9, 0.9, 0.05)
f1_scores = [f1_score(test_group[1].values, test_group[0] > t) for t in th]
recall_scores = [recall_score(test_group[1].values, test_group[0] > t) for t in th]
precison_scores = [precision_score(test_group[1].values, test_group[0] > t) for t in th]
plt.plot(th, f1_scores)
plt.figure(5)
plt.plot(th, recall_scores, th, precison_scores)
cm = confusion_matrix(test_group[1].values, test_group[0] > th[np.argmax(f1_scores)])
cm0 = confusion_matrix(test_group[1].values, test_group[0] > -0.25)
################
#####################
#   NN - Auxiliary output
###################


X_ordinal_train_all = X_ordinal_train
X_ordinal_test_all = X_ordinal_test

X_ordinal_train = X_ordinal_train_all
X_ordinal_test = X_ordinal_test_all

ordinal_hi_corr = column_select['col'][column_select['corr'].abs() > 0.05].index

X_ordinal_train = X_ordinal_train_all[:, ordinal_hi_corr]
X_ordinal_test = X_ordinal_test_all[:, ordinal_hi_corr]

input_ordinal = Input(shape=(X_ordinal_train.shape[1],), name='input_ordinal')
hidden_ordinal = Dense(8, activation='relu', name='hidden_ordinal')(input_ordinal)

embedding_all_categorical = Concatenate(name='input_categorical')(embedding_categorical)
hidden_categorical = Dense(6, activation='relu', name='hidden_categorical')(embedding_all_categorical)

input_graph = Input(shape=(X_graph_train[0].shape[0],), name='input_graph')
hidden_graph = Dense(2, activation='relu', name='hidden_graph')(input_graph)
hidden_graph_1 = Dense(2, activation='relu', name='hidden_graph_1')(hidden_graph)

input_text = Input(shape=(MAX_SEQUENCE_LENGTH,), name='input_text')  # , dtype='int32')
embedded_text = embedding_layer(input_text)
text_cnn = Conv1D(16, 2, activation='relu', name='text_cnn')(embedded_text)
# text_cnn = MaxPooling1D(2)(text_cnn)
# text_cnn = Conv1D(8, 2, activation='relu')(text_cnn)
# x = MaxPooling1D(5)(x)
# x = Conv1D(128, 5, activation='relu')(x)
text_pool = GlobalMaxPooling1D(name='text_pool')(text_cnn)
############
auxiliary_output = Dense(2, activation='softmax')(embedding_all_categorical)
auxiliary_output = Dense(2, activation='softmax')(input_ordinal)
auxiliary_output = Dense(2, activation='softmax')(text_pool)
# Add auxiliary input (categorical)
auxiliary_input = input_categorical
###########


# joined_input = Concatenate()(embedding_categorical+[input_ordinal])

joined_input = Concatenate()([embedding_all_categorical] + [input_ordinal] + [text_pool])
joined_input = Concatenate()([embedding_all_categorical] + [input_ordinal] + [input_graph] + [text_pool])

joined_input = Concatenate()([input_graph] + [text_pool])

joined_input = Concatenate()([input_ordinal] + [text_pool])
joined_input = Concatenate()([input_ordinal] + [hidden_graph] + [text_pool])

joined_input = Concatenate()([embedding_all_categorical] + [input_ordinal] + [input_graph])
joined_input = Dense(10, activation='relu')(joined_input)

merged_input = Concatenate()([joined_input] + [text_pool])

joined_input = Concatenate()([embedding_all_categorical] + [input_ordinal] + [text_pool])
joined_input = Concatenate()([input_ordinal] + [input_graph])

joined_input = Concatenate()([embedding_all_categorical] + [input_ordinal])

joined_input = Concatenate()([hidden_categorical, input_ordinal])

joined_input = Concatenate()([hidden_categorical] + [input_ordinal])
joined_input = Concatenate()([hidden_categorical] + [hidden_ordinal])

# hid_categorical = Dense(8,activation='relu')(Concatenate()(embedding_categorical))
# hid_categorical = Dropout(.3)(hid_categorical)
merge_layer = Dense(10)(joined_input)
merge_layer = Dense(10)(input_ordinal)

# merge_layer = Dropout(.3)(hidden_categorical)
# hid_layer = Dense(8, activation='relu')(merge_layer)
# hid_layer = Dropout(.2)(hid_layer)

out = Dense(1, activation='sigmoid')(merge_layer)
out = Dense(1, activation='sigmoid')(joined_input)
out = Dense(2, activation='softmax')(input_ordinal)
out = Dense(2, activation='softmax')(joined_input)
out = Dense(2, activation='softmax')(input_graph)
out = Dense(2, activation='softmax')(hidden_graph)
out = Dense(2, activation='softmax')(text_pool)
out = Dense(2, activation='softmax')(embedding_all_categorical)
out = Dense(2, activation='softmax')(input_ordinal)

model = Model(inputs=input_categorical + [input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])
model = Model(inputs=[input_ordinal] + [input_graph], outputs=[out])  # ,auxiliary_output])

model = Model(inputs=[input_ordinal] + [input_graph] + [input_text], outputs=[out])  # ,auxiliary_output])
model = Model(inputs=[input_graph] + [input_text], outputs=[out])  # ,auxiliary_output])

model = Model(inputs=input_categorical + [input_ordinal] + [input_graph] + [input_text],
              outputs=[out])  # ,auxiliary_output])

model = Model(inputs=[input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])

model = Model(inputs=input_categorical + [input_ordinal], outputs=[out])  # ,auxiliary_output])
model = Model(inputs=input_ordinal, outputs=out)
model = Model(inputs=input_graph, outputs=out)
model = Model(inputs=input_categorical, outputs=out)
model = Model(inputs=[input_text], outputs=out)

model.compile(loss='mean_squared_error', metrics=['accuracy'], optimizer='adam')
model.compile(loss='binary_crossentropy', metrics=['accuracy'], optimizer='adam')

model.summary()

model.fit(X_categorical_train + [X_ordinal_train] + [X_graph_train] + [X_text_train], y_train_cat, batch_size=32,
          epochs=5)
model.fit([X_ordinal_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)

model.fit([X_graph_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
model.fit([X_text_train], y_train_cat, batch_size=32, epochs=5)
model.fit([X_graph_train], y_train_cat, batch_size=32, epochs=5)
model.fit([X_ordinal_train], y_train_cat, batch_size=32, epochs=5)

model.fit(X_categorical_train + [X_ordinal_train], y_train_cat, batch_size=32,
          epochs=5)  # , class_weight={1:.1 , 0:.9})#,validation_data=(X_categorical_test+[X_ordinal_test],y_test))
model.fit(X_categorical_train + [X_ordinal_train], [y_train_cat, y_train_cat], batch_size=32,
          epochs=5)  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))
model.fit(X_ordinal_train, y_train_cat, batch_size=32,
          epochs=10)  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))
model.fit([X_text_train], y_train_cat, batch_size=32,
          epochs=5)  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))
model.fit(X_categorical_train, y_train_cat, batch_size=32,
          epochs=5)  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))

model.fit(X_categorical_train + [X_ordinal_train], y_train, batch_size=32, epochs=5,
          class_weight={1: .1, 0: .9})  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))

from sklearn.metrics import roc_auc_score

pred_soft = np.diff(model.predict(X_categorical_test + [X_ordinal_test]))
pred_soft = np.diff(model.predict(X_categorical_test + [X_ordinal_test] + [X_graph_test] + [X_text_test]))
pred_soft = np.diff(model.predict([X_ordinal_test] + [X_text_test]))

pred_soft = np.diff(model.predict(X_categorical_test + [X_ordinal_test] + [X_graph_test]))

pred_soft = np.diff(model.predict([X_graph_test] + [X_text_test]))
pred_soft = np.diff(model.predict([X_text_test]))
pred_soft = np.diff(model.predict([X_graph_test]))

pred_soft = np.diff(model.predict(X_categorical_test))

pred_soft = np.diff(model.predict(X_categorical_test + [X_ordinal_test]))
pred_soft = np.diff(model.predict(X_ordinal_test))
roc_auc_score(y_test, pred_soft)
pred_hard = pred_soft > -0.9

import matplotlib.pyplot as plt

plt.hist(pred_soft[y_test == 0], color='r', bins=50)
plt.hist(pred_soft[y_test == 1], color='g', bins=50, alpha=0.8)

import csv

with open('/home/u015734825/projects/weapontrafficking/src/text_graph_py/imp.csv', 'w') as f:
    writer = csv.writer(f)
    writer.writerows(pred_soft[y_test == 0])

with open('/home/u015734825/projects/weapontrafficking/src/text_graph_py/tar.csv', 'w') as f:
    writer = csv.writer(f)
    writer.writerows(pred_soft[y_test == 1])

th = 0
a = pred_soft[y_test == 0][pred_soft[y_test == 0] > th]
b = pred_soft[y_test == 1][pred_soft[y_test == 1] > th]
plt.hist(a, color='r', bins=50)
plt.hist(b, color='g', bins=50, alpha=0.8)

pred_hard = np.argmax(model.predict(X_categorical_test + [X_ordinal_test]), axis=1)
pred_hard = np.argmax(model.predict(X_ordinal_test), axis=1)
pred_hard = np.argmax(model.predict([X_ordinal_test] + [X_graph_test] + [X_text_test]), axis=1)
confusion_matrix(y_test, pred_hard)
f1_score(y_test, pred_hard)

fpr, tpr, threshold = roc_curve(y_test, pred_soft, pos_label=1)
fnr = 1 - tpr
eer = fpr[np.argmin((np.absolute((fnr - fpr))))]
eer_threshold = threshold[np.argmin((np.absolute((fnr - fpr))))]
print(eer, eer_threshold)
###################################################

input_ordinal = Input(shape=(X_ordinal_train.shape[1],), name='input_ordinal')
embedding_ordinal = Dense(4, activation='relu')(input_ordinal)
# embedding_ordinal = Dense(4, activation='relu')(embedding_ordinal)
auxiliary_output = Dense(1, activation='sigmoid')(embedding_ordinal)

# Add auxiliary input (categorical)
auxiliary_input = input_categorical
auxiliary_layer = Dense(4, activation='relu')(Concatenate()(embedding_categorical))
# auxiliary_layer = Dense(4,activation='relu')(auxiliary_layer)

# Merge aux output with aux input and stack dense layer on top
main_input = concatenate([auxiliary_layer, embedding_ordinal])
out = Dense(1, activation='sigmoid')(main_input)

model = Model(inputs=auxiliary_input + [input_ordinal], outputs=out)
model.compile(loss='mean_squared_error', metrics=['accuracy'], optimizer='adam')  # ,loss_weights=[1.,0.2])
model.fit(X_categorical_train + [X_ordinal_train], [y_train], batch_size=20, epochs=5)
# m odel.fit(X_categorical_train, [y_train], batch_size=32, epochs=5)
# model.fit([X_ordinal_train], [y_train], batch_size=32, epochs=5)#, class_weight={1:.1 , 0:.9})#,validation_data=(X_categorical_test+[X_ordinal_test],y_test)
pred_soft = model.predict(X_categorical_test + [X_ordinal_test])
eer(pred_soft, y_test)
eer(pred_soft[1])

# pred_soft = model.predict(X_ordinal_test)
# pred_soft = model.predict(X_categorical_test)


####################


input_ordinal = Input(shape=(X_ordinal_train.shape[1],))
embedding_ordinal = Dense(8, activation='relu')(input_ordinal)
auxiliary_output = Dense(1, activation='sigmoid')(embedding_ordinal)

# hid_categorical = Dense(8,activation='relu')(Concatenate()(embedding_categorical))
# hid_categorical = Dropout(.3)(hid_categorical)
merge_layer = Dense(4)(Concatenate()(embedding_categorical + [embedding_ordinal]))
merge_layer = Dropout(.3)(merge_layer)
# hid_layer = Dense(8, activation='relu')(merge_layer)
# hid_layer = Dropout(.2)(hid_layer)

out = Dense(1, activation='sigmoid')(merge_layer)
model = Model(inputs=input_categorical + [input_ordinal], outputs=out)
model.compile(loss='binary_crossentropy', metrics=['accuracy'], optimizer='adam')

model.fit(X_categorical_train + [X_ordinal_train], y_train, batch_size=32,
          epochs=5)  # ,validation_data=(X_categorical_test+[X_ordinal_test],y_test))

pred_soft = model.predict(X_categorical_test + [X_ordinal_test])

fpr, tpr, threshold = roc_curve(y_test, pred_soft, pos_label=1)
fnr = 1 - tpr
eer = fpr[np.argmin((np.absolute((fnr - fpr))))]
eer_threshold = threshold[np.argmin((np.absolute((fnr - fpr))))]
print(eer, eer_threshold)

from keras import Sequential

model = Sequential()
model.add(Dense(8, input_dim=X_ordinal_train_all.shape[1], activation='relu'))
model.add(Dense(4, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
model.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])
model.fit(X_ordinal_train_all, y_train, batch_size=32, epochs=5, validation_data=(X_ordinal_test_all, y_test))

# scores = model.evaluate(X_train,Y_train)

pred_soft = model.predict(X_ordinal_test_all)

model.summary()

fpr, tpr, threshold = roc_curve(y_test, pred_soft, pos_label=1)
fnr = 1 - tpr
eer = fpr[np.argmin((np.absolute((fnr - fpr))))]
eer_threshold = threshold[np.argmin((np.absolute((fnr - fpr))))]
print(eer, eer_threshold)

hist(pred_soft[y_test == 0], color='g', bins=50)  # , range=(0, 0.1))
hist(pred_soft[y_test == 1], color='r', bins=50)  # , range=(0, 0.1))

#
# predict = model.predict(X_categorical_test)
# np.corrcoef(predict.reshape(1,-1),y_test)
#
# predict = model.predict(X_categorical_train)
# np.corrcoef(predict.reshape(1,-1),y_train)


#
#
# # PCA
# from sklearn.decomposition import PCA
#
# pca = PCA(n_components=20)
# pca.fit(X)
# X = pca.transform(X)
# pca.explained_variance_ratio_
# pca.components_

from sklearn.model_selection import train_test_split

from sklearn import ensemble

import matplotlib as plt
import numpy as np

# X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix, f1_score

# model = Sequential()
# model.add(Dense(8, input_dim=X.shape[1],activation='relu'))
# model.add(Dense(4,activation='relu'))
# model.add(Dense(1,activation='sigmoid'))
# model.compile(optimizer='adam',loss='mean_squared_error',metrics=['accuracy'])
# model.fit(X_train,Y_train,batch_size=32,epochs=20)
# # scores = model.evaluate(X_train,Y_train)
# pred_soft = model.predict(X_test)

ordinal_hi_corr = column_select[column_select.abs() > 0.05].reset_index().index

clf = SVC(gamma='auto', kernel='rbf', class_weight={1: 10}, C=1)
clf = MLPClassifier(hidden_layer_sizes=(4, 2))
# clf = ensemble.GradientBoostingClassifier()
# clf = DecisionTreeClassifier()
# clf = ensemble.RandomForestClassifier()
# clf = GaussianNB()
clf.fit(X_ordinal_train[:, ordinal_hi_corr], y_train)
clf.fit(X_ordinal_train, y_train)

# [:,ordinal_hi_corr]
# for NN
pred_soft = np.argmax(clf.predict_proba(X_ordinal_test), axis=1)

pred_soft = clf.decision_function(X_ordinal_test[:, ordinal_hi_corr])
pred_soft = clf.decision_function(X_ordinal_test)
roc_auc_score(y_test, pred_soft)

print(eer(pred_soft, y_test))
pred = clf.score(X_ordinal_test, y_test)
clf.score(X_ordinal_test[:, ordinal_hi_corr], y_test)
pred = clf.predict(X_ordinal_test)

pred_hard = clf.predict(X_ordinal_test[:, ordinal_hi_corr])
pred_hard = clf.predict(X_ordinal_test)
confusion_matrix(y_test, pred_hard)
confusion_matrix(y_test, pred)
confusion_matrix(y_test, pred_soft)
roc_auc_score(y_test, pred_soft)

fpr, tpr, threshold = roc_curve(y_test, pred_soft, pos_label=1)
fnr = 1 - tpr
eer = fpr[np.argmin((np.absolute((fnr - fpr))))]
eer_threshold = threshold[np.argmin((np.absolute((fnr - fpr))))]
print(eer, eer_threshold)
f1_score(y_test, pred_hard)

hist(pred_soft[y_test == 0], color='g', bins=50)  # , range=(0, 0.1))
hist(pred_soft[y_test == 1], color='r', bins=50)  # , range=(0, 0.1))
hist(pred_soft, color='b', alpha=0.5, bins=10, range=(-3, 3))
#
# import  matplotlib.pyplot as plt
#
# f,axes = plt.subplots(6,6, figsize=(20,20), sharex=True)
# for i, feature in enumerate(features.columns[6:]):
#     sns.distplot(features[feature])





