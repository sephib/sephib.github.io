import pandas as pd
import numpy as np
import datetime
import random as rn
import collections
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from scipy.stats import pearsonr, spearmanr
import networkx as nx
from statsmodels.graphics.gofplots import (
    qqplot,
)  # use qqplot to see if data is normally distributed

from keras.models import Model
from gensim.models import FastText as FT
from keras.layers import (
    Input,
    Dense,
    Embedding,
    Dropout,
    Concatenate,
    Reshape,
    concatenate,
)
from sklearn.preprocessing import LabelEncoder
from matplotlib.pyplot import hist
import matplotlib.pyplot as plt


from gensim.parsing.preprocessing import (
    preprocess_string,
    remove_stopwords,
    stem_text,
    strip_punctuation,
    strip_tags,
    strip_numeric,
    strip_short,
)
from gensim.models.phrases import Phrases
from gensim.models import Word2Vec
from gensim.parsing.preprocessing import STOPWORDS
from gensim.utils import tokenize

# import networkx as nx
from keras.layers import Conv1D, MaxPooling1D, Embedding, concatenate, UpSampling1D
from keras.layers import (
    Dense,
    Input,
    GlobalMaxPooling1D,
    Flatten,
    Activation,
    Reshape,
    dot,
    multiply,
    add,
    average,
    GlobalAveragePooling1D,
)
from keras.utils import to_categorical

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

import sklearn.metrics as metric

# import tensorflow as tf
from keras import backend as K
from keras.models import Sequential
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_validate
from sklearn.metrics.scorer import make_scorer
from sklearn.utils import resample


from sklearn.ensemble import RandomForestClassifier
from keras.layers import (
    Dense,
    Input,
    GlobalMaxPooling1D,
    Flatten,
    Activation,
    Reshape,
    dot,
    multiply,
    add,
    average,
    GlobalAveragePooling1D,
)
from keras.layers import Conv1D, MaxPooling1D, Embedding, concatenate, UpSampling1D
from keras.models import Model
from sklearn.metrics import f1_score
from sklearn.metrics import (
    roc_auc_score,
    confusion_matrix,
    precision_score,
    recall_score,
)
from sklearn.feature_selection import VarianceThreshold

import pandas as pd
import numpy as np
import datetime
import collections
from itertools import compress

from gensim.models import FastText as FT
from gensim.models import doc2vec
import matplotlib.pyplot as plt


from keras.utils import to_categorical
from sklearn import model_selection
from sklearn.model_selection import GridSearchCV

from sklearn import svm as svm
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold
from sklearn.decomposition import PCA
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import SGDClassifier

from imblearn.over_sampling import SMOTE, ADASYN

from gensim.utils import simple_preprocess

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from gensim.models import KeyedVectors
from keras.utils import to_categorical
from sklearn.metrics import roc_curve


from pathlib import Path
import sys

path_home = Path(sys.path[-1]).home()
# cur_path = path_home/"drugs_trafficking/src"
cur_path = "/home/e015976541/projects/drugs_trafficking/src"
sys.path.append(str(cur_path))

import drugs_util
import drugs_text as t


MAX_SEQUENCE_LENGTH = 150
DEBUG = True


def show_results(p, y_test):
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")


# load pretrained model - from wikipedia
def load_heb_dict_from_wikipedia():
    heb_model = KeyedVectors.load_word2vec_format("/rData/Hebrew_NLP/wiki.he.vec")


def create_heb_dict_from_yediot(texts, model):
    # possible to create (offline) verbs, nouns, prop names using YAP and then do the training
    # texts = features['docText'].values
    # texts = features['VB'].values
    # texts = features['NN'].values
    # texts = features['NNP'].values

    # now create the arrays of dim = 100 , note that of samim docs, there are few words, so choose dim = ~50
    # play with it - try to find close words in the dict to choose better dim
    VEC_DIM = 50

    # FT is more syntax based

    if model == "FT":
        model = FT(
            size=VEC_DIM, min_count=1
        )  # min_count = treat words which appear 1+ times
        model.build_vocab(texts)
        model.train(texts, total_examples=model.corpus_count, epochs=model.epochs)

    # the vector space returned by word2vec is an euclidian space!!!
    # min_count = treat words which appear 1+ times
    if model == "word2vec":
        model = Word2Vec(texts, size=VEC_DIM, min_count=1)

    words = list(model.wv.vocab)
    vecs = model.wv.__getitem__(words)

    return model, words, vecs


# cleaning hebrew text and creating bigrams
# clean the code here
# gila todo bigrams does not work yet
def clean_heb_text(text):
    f = open("/rData/Hebrew_NLP/Hebrew_stop_words.txt")
    stpwrds = f.read().split()
    import re

    text_clean = text

    # CUSTOM_FILTERS = [strip_punctuation, strip_numeric]
    # tokens = preprocess_string(str1, CUSTOM_FILTERS)

    for x in ["'", '"']:
        text_clean = text_clean.replace(x, "")
    for x in [
        "\xd5d",
        "\n",
        "!",
        ".",
        "#",
        "$",
        "%",
        "&",
        "(",
        ")",
        "*",
        "+",
        ",",
        "-",
        "/",
        ":",
        ";",
        "<",
        "=",
        ">",
        "?",
        "@",
        "[",
        "^",
        "]",
        "_",
        "`",
        "{",
        "|",
        "}",
        "~",
        "\t",
    ]:
        text_clean = text_clean.replace(x, " ")

    text_clean = re.sub("[0-9]+", "מספר", text_clean)
    text_clean = text_clean.split()
    text_clean = [w for w in text_clean if not w in stpwrds]

    # tokens = list(tokenize(text_clean))
    # tokens = [x for x in  if x.lower() not in STOPWORDS]
    # text_clean = " ".join(text_clean)
    # todo - works again
    bigram_mdl = Phrases(text_clean, min_count=1, threshold=2)
    tokens = [t for t in text_clean if len(t) > 2]
    bigrams = bigram_mdl[tokens]
    words = list(bigrams)

    words = [re.sub("_", "-", word) for word in words]
    # vecs = [word2vec1[word] if word in word2vec1.keys() else np.zeros(shape=(1, 20)) for word in words]
    # return words
    return text_clean


def clean_yediot(text_list):
    clean_texts = [clean_heb_text(d) for d in text_list]
    return clean_texts


def tokenize_text_to_sequence(clean_texts):

    # maximus number of words to work with
    MAX_NB_WORDS = 26000

    # tokenizer is the input to the "keras.Input" layer for text
    # look at documentation of keras.token - only frequent words will be placed in the tokenizer if the max_nb_words is too small
    # note that when create the tokenizer with 30000 words, nassati an nassnu are each one word. YAP can fix this, this is called
    # lematization or steming (in english it is simpler - plays, playing, played are all converted to play before
    # tokenizing, maybe look for some ther hebrew stemmer)
    # also - מעבודה, לעבודה are  different words, and YAP knows to seperate "from/to" from the words. Important to try it

    tokenizer = Tokenizer(num_words=MAX_NB_WORDS)

    # one hot key: each word gets a number between 0.. MAX_NB_WORDS
    tokenizer.fit_on_texts(clean_texts)

    # convert the sentence to sequence of hot keys
    sequences = tokenizer.texts_to_sequences(clean_texts)

    print("Found %s unique tokens." % len(tokenizer.word_index))
    return sequences, tokenizer


# we have decided that the mean count word in sentence is MAX_SEQUENCE_LENGTH (150),
# it pads the shorter sentences with zeros so that the result is a vector of dim 1*MAX_SEQUENCE_LENGTH for each sentence.
# longer sentences will be trimmed to max_sequence_length
# returns: Matrix of m*MAX_SEQUENCE_LENGTH for all sentences and the word_index
# Use padding for CNN only - for simple nn you should use the sequences
def get_padded_sequence_from_text(clean_texts, max_sequence_length):
    sequences, word_index = tokenize_text_to_sequence(clean_texts)
    p_sequences = pad_sequences(sequences, maxlen=max_sequence_length)
    return p_sequences, word_index


# this method accepts the clean_texts and creates the text embedding for the embedding layer of the NN
def get_text_embedding(clean_texts, msk, w2vec_model):

    # the mean count of words of yedia, if we take the max count, many sentences will be padded with zeros.
    MAX_SEQUENCE_LENGTH = 150
    # Preparing the text Embedding layer

    p_sequences, word_index = get_padded_sequence_from_text(
        clean_texts, MAX_SEQUENCE_LENGTH
    )
    p_sequences = np.array(p_sequences)
    X_text_train = p_sequences[~msk]  # features['docText'][~msk].values
    X_text_test = p_sequences[msk]  # features['docText'][msk].values

    EMBEDDING_DIM = w2vec_model.vector_size

    # Preparing the Embedding layer
    embedding_matrix = np.zeros(
        (len(word_index) + 1, EMBEDDING_DIM)
    )  # adding 1 to account for 0th index (for masking)
    for word, i in word_index.items():
        if word in w2vec_model:
            embedding_vector = w2vec_model[word]
        else:
            # words not found in embedding index will have random value
            embedding_vector = np.random.uniform(-0.25, 0.25, EMBEDDING_DIM)

        embedding_matrix[i] = embedding_vector

        # random replacment of words - for testing
        # embedding_vector = np.random.uniform(-0.25, 0.25, EMBEDDING_DIM)
        # embedding_matrix[i] = embedding_vector

    # load the word_vector matrix to the Embedding layer
    # the model was trained in model creating, her we put it in the embedding layer, and van further train (trainable=True)
    # or not (trainable = False) - play with it to see what gives better results
    text_embedding_layer = Embedding(
        len(word_index) + 1,
        EMBEDDING_DIM,
        weights=[embedding_matrix],
        input_length=MAX_SEQUENCE_LENGTH,
        trainable=True,
    )

    # Retrun real data and embedding layer for text for cnn
    return X_text_train, X_text_test, text_embedding_layer


# given the words_model (word_2_vec or FT or whatever), convert each sentence (yedia) to its representing vector
# if the word is not in the words_model, convert to random uniform values
# returns the embedding matrix which contains a vector for each word in each sentence
def sentence_to_vecs(clean_texts, words_model):
    # embedding_matrix = np.zeros((len(clean_texts), MAX_SEQUENCE_LENGTH))
    embedding_matrix = []
    for i, s in enumerate(clean_texts):
        embedding_vector = []
        for word in s:
            if word in words_model:
                embedding_vector.append(words_model[word])
            else:
                embedding_vector.append(
                    np.random.uniform(-0.25, 0.25, MAX_SEQUENCE_LENGTH)
                )

        embedding_matrix.append(embedding_vector)
    return embedding_matrix


def doc2vec_corpus(corpus):
    i = 0
    for d in corpus:
        yield doc2vec.TaggedDocument(d, [i])
        i = i + 1


def get_doc_2_vec(clean_texts, embedding_dim=50, min_count=2, epochs=40):

    crps = list(doc2vec_corpus(clean_texts))
    # type(crps)
    # print(crps[:2])

    model = doc2vec.Doc2Vec(
        vector_size=embedding_dim, min_count=min_count, epochs=epochs
    )
    model.build_vocab(crps)

    # sanity checks
    voc = model.wv.vocab
    voc["בלדר"].count
    voc["עיסאם"].count

    model.train(crps, total_examples=len(crps), epochs=model.epochs)

    # v1 is a vector for the sentence
    v1 = model.infer_vector(
        ["סלולר", "בלדרים", "באמצעות", "מצריים", "גבול", "ייבוא", "קריסטל", "חשיש"]
    )

    # transform docs to vecs
    crps_vecs = []
    for d in crps:
        crps_vecs.append(model.infer_vector(d.words))

    # sanity check
    sims = model.docvecs.most_similar([crps_vecs[1]], topn=10)
    return crps_vecs


def get_matrix_from_text(texts, mode):
    sequences, tokenizer = tokenize_text_to_sequence(texts)
    data = tokenizer.sequences_to_matrix(np.array(sequences), mode=mode)  # MLP: >0.85
    return data


def grid_search(models, params, X, Y):
    best_models = []

    for i in range(0, len(params)):
        print(f"Running model: {models[i].__class__}\n")
        m = GridSearchCV(models[i], params[i], cv=3, verbose=1, n_jobs=100)
        print(f"Best params found were: {m.get_params()}\n")
        m.fit(X, Y)
        best_models.append(m.best_estimator_)
    return best_models


def get_train_test_sets(data, label_col):

    msk = np.random.rand(len(data)) >= 0.2
    x_train = list(compress(data, msk))
    x_test = list(compress(data, ~msk))

    y_train = label_col[msk].astype("int").values
    y_test = label_col[~msk].astype("int").values

    y_train_cat = to_categorical(y_train, 2)
    y_test_cat = to_categorical(y_test, 2)

    return x_train, y_train, x_test, y_test, y_train_cat, y_test_cat


def simple_keras_nn(add_layer, x_train):

    # simple nn which accepts the matrix of words
    input_text = Input(shape=(1,), name="input_text")  # , dtype='int32')

    model = Sequential()
    # second layer is the output
    # the Dense layer returns 2 outputs: 0, 1

    if add_layer:
        model.add(Dense(100, activation="relu", input_shape=(len(x_train[1]),)))
        model.add(Dense(50, activation="sigmoid"))
        model.add(Dense(2, activation="softmax"))
    else:
        model.add(Dense(2, activation="softmax", input_shape=(len(x_train[1]),)))

    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    return model


# *********************************************************************************
# *********************************************************************************
# *********************************************************************************
# *********************************************************************************

# In the main method create the matrix to be sent to the ML methods in different ways
# 1) tokenize_text_to_sequence using Keras Tokenizer
# 2) ngrams
# 3) sentence to vecs using he word model --> mean value of vectors ==> ML method
def main():

    df = drugs_util.get_label_file()
    print(f"len of records labled {len(df)}")

    label = "label"
    doc_text = "docText"
    clean_texts = t.clean_yediot(df[doc_text])

    # create dict either from the yediot or from wikipedia
    # word_model, words_list, words_vecs = create_heb_dict_from_yediot(clean_texts, 'word2vec')

    # prepare the word vectors for the MLs(SVC, MLP, Random forest...)
    # note: there is no need for padding in simple MLs (only in CNN)

    modes = ["tfidf", "binary", "count", "freq"]
    data = get_matrix_from_text(clean_texts, modes[0])

    x_train, y_train, x_test, y_test, y_train_cat, y_test_cat = get_train_test_sets(
        data, df[label]
    )
    # x_over, y_over = SMOTE().fit_resample(x_train, y_train)
    x_over, y_over = ADASYN().fit_resample(x_train, y_train)

    if DEBUG:
        print(len(x_train))
        print(len(x_test))
        print(len(x_over))
        print(len(y_over))

    x_train = x_over
    y_train = y_over

    classifiers = []
    params = []

    # mlp = MLPClassifier()
    sgd = SGDClassifier(n_jobs=100)
    # svc = svm.SVC()
    rf = RandomForestClassifier()

    keras_nn = simple_keras_nn(1, x_train)

    rf_params = {"n_estimators": [50, 100, 200], "max_depth": [10, 20, 30, 50]}
    sgd_params = {
        "loss": ["log"],
        "max_iter": [100, 150],
        "early_stopping": [True, False],
    }

    # sgd_params = {'loss': ['log', 'squared_loss', 'huber'], 'max_iter': [100, 150], 'penalty': ['l2', 'l1'],
    #               'early_stopping': [True, False]}

    svc_parms = {
        "kernel": ["linear", "rbf"],
        "C": [3, 5, 15, 20],
        # 'class_weight':[class_weight],
        "gamma": ["scale"],
    }

    mlp_params = {
        "max_iter": [100, 200, 300],
        "hidden_layer_sizes": [(50, 3), (100, 5)],
        "learning_rate": ["constant", "adaptive"],
    }

    keras_nn_params = {
        "batch_size": [8, 16, 20, 32],
        "epochs": [3, 5, 10, 20],
        "validation_split": [0.05, 0.1, 0.15, 0.2],
        "workers": [25],
    }

    classifiers.append(sgd)
    params.append(sgd_params)

    # classifiers.append(rf)
    # params.append(rf_params)
    #
    # classifiers.append(keras_nn)
    # params.append(keras_nn_params)

    best_models = grid_search(classifiers, params, x_train, y_train)

    # score_df = run_all(df, data, label, 5)
    # print ('data from tokenizer results:')
    # print(score_df.head())

    # pred_hard, proba, auc, f1score, conf_mat = simple_keras_nn(m, msk, sequences, y_train_cat, y_test_cat, class_weight, y_test)
    # print (f'auc, f1score, conf_mat for simple_keras_nn: {auc, f1score, conf_mat}')

    # transform the sentences (clean_text) to corresponding vecs from word_model
    # and then compute the mean of each COLUMN in vectors
    # todo gila - before doing the mean of the vec, multiply each word by its weight from the tfidf matrix
    # m1 = sentence_to_vecs(clean_texts, word_model)
    # vec_means = []
    # for i in range(len(m1)):
    #     vec_means.append(np.mean(m1[i], axis = 0))
    # vec_means = np.array(vec_means)
    #
    #
    # clf = SVC(class_weight=class_weight, kernel='linear')
    # X_text_train = vec_means[~msk]
    # X_text_test = vec_means[msk]
    # clf.fit(X_text_train, y_train)
    # p = clf.predict(X_text_test)
    # print(f'SVC.score for vec_means is : {clf.score(X_text_test, y_test)}')
    #
    # # use the mean matrix in MLP
    # mlp = MLPClassifier()
    # mlp.fit(X_text_train, y_train)
    # p = mlp.predict(X_text_test)
    # print(f'MLP score for vec_means is: {mlp.score(X_text_test, y_test)}')

    # print(f'sequences_to_matrix SVC score: {SVC1(m, msk, y_train, class_weight)}')

    # clf.fit(X_text_train, y_train)
    # p = clf.predict(X_text_test)
    # #print(f'csv.score for keras seq is : {clf.score(X_text_test, y_test)}')
    # score=np.mean(cv_res['test_score'])
    # print(f'csv.score for keras seq is : {score}')

    # find the less important words
    # todo gila - take clf from SVC1 function
    # dict = sequences[1]
    # wl = ''
    # weights = np.array(clf.coef_[0])
    # srt_w = np.argsort(weights)#[::-1]
    # for i in range(10):
    #     wl = wl + ' , ' + list(dict.keys())[srt_w[i]]
    # #print(wl)

    # this is a simple nn from sklearn - you can see how many layers it has, etc
    # in this example as it it written now, it accpets a matrix of size (9700 words X n), goes to a hidden layer and builds 100 combinations of the
    # words (100 is the defalut) and this is the input to the final layer
    # todo: add looping for better measuring

    # clean and use ngrams
    clean_sentences = []
    for c in clean_texts:
        s = " ".join(w for w in c)
        for x in ["י", "ו", "א", "ה"]:
            s = s.replace(x, "")
        clean_sentences.append(s)

    # CountVectorizer  is one way to devide to ngrams
    vectorizer = CountVectorizer(
        ngram_range=(3, 3), analyzer="char", binary=False
    )  # , max_features=100)
    ngram_m = vectorizer.fit_transform(clean_sentences)

    data = ngram_m.toarray()
    score_df = run_all(df, data, label, 5)
    print("data from CountVectorizer ngrams (char, 3) results:")
    print(score_df.head())

    # TfidfVectorizer is another way to devide to ngrams - gave better results
    tf = TfidfVectorizer(ngram_range=(3, 3), analyzer="char")  #
    ngram_m = tf.fit_transform(clean_sentences)

    data = ngram_m.toarray()

    crps_vecs = get_doc_2_vec(clean_texts)

    score_df = run_all(df, data, label, 5)
    print("data from TfidfVectorizer ngrams (char, 3) results:")
    print(score_df.head())

    # score, f1score, auc, conf_mat = SVC1(data, msk, y_train, class_weight, y_test)
    # print(f'SVC1 score, f1score, auc, conf_mat: {score}, {f1score},{auc}, {conf_mat}')

    # data = ngram_m.toarray()
    # n = 10
    # scores = [0] * n
    # f1scores = [0] * n
    # auc = [0] * n
    # # err = [0] * n
    # # err_threshold = [0] * n
    # for i in range(n):
    #     msk1 = get_split_mask(df)
    #     y_train_1 = df[label][~msk1].astype('int').values
    #     y_test_1 = df[label][msk1].astype('int').values
    #     # print(f'MLP.score for keras seq is: {MLP1(m, msk, y_train, y_test)}')
    #     scores[i], proba, f1scores[i], auc[i], conf_mat = MLP1(data, msk1, y_train_1, y_test_1)
    #
    # print(f'MLP score, f1score, auc, conf_mat: {np.mean(scores)}, {np.mean(f1scores)},{np.mean(auc)}, {conf_mat})')

    # score, proba, f1score, auc, conf_mat = MLP1(data, msk, y_train, y_test)
    # print(f'MLP score, f1score, auc, conf_mat: {score}, {f1score},{auc}, {conf_mat}')
    #
    # score, f1score, auc, p, proba, conf_mat = random_forest(data, msk, y_train, y_test, class_weight)
    # print(f'rand forest score, f1score, auc, conf_mat: {score}, {f1score},{auc}, {conf_mat}')

    # print(f'MLP mean err & threshold mean - predict True above the mean threshold: {np.mean(np.array(eer_threshold))} , '
    #       f'{np.mean(np.array(eer))}')
    # todo: note that when check the threshold was very dense (0.2-0.3)- fix

    # MLP_prediction_vec = proba > np.mean(np.array(err_threshold)).astype(int)

    # MLP mean err & threshold mean - predict True above the mean threshold
    # np.std(eer_threshold) =0.015151658915958675

    # vectorizer.get_feature_names()[:100]
    # print(f'svc score for ngrams: {SVC1(ngram_m.toarray(), msk, y_train, class_weight, y_test)}')

    # CNN - complex NN
    # X_text_train, X_text_test, text_embedding_layer = get_text_embedding(df, clean_texts, msk, word_model, words_list,
    #                                                                  words_vecs)
    #
    #
    #
    # # now we have the input (X_text_test, X_text_train) and the embedding layer struct (text_embedding_layer) and we start to run the embedding layer struct
    # # on the input - the input for the embedding layer is the sequnces (matrix of word indexes - each row is a sentence),
    # # output is the vectors representing each word in sentence / sequence(sentence length = 150) ==> this is the embedded_text
    #
    #
    # #Tried to fix keras to be predictable, did not work
    # np.random.seed(42)
    # # rn.seed(12345)
    # #
    # #
    # # session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    # # tf.set_random_seed(4520)
    # # sess = tf.Session(graph=tf.get_default_graph(), config= session_conf)
    # # K.set_session(sess)
    #
    #
    # input_text = Input(shape=(MAX_SEQUENCE_LENGTH,), name='input_text')  # , dtype='int32')
    # embedded_text = text_embedding_layer(input_text)
    #
    # # now run filter (conv) on matrix to find 16 filters/sensors which represent a combination of length 2 (2 is the sliding window size) - over the whole space
    # # max pooling takes the best filter for the whole sentece - the words which are best matching the labeling (for eg, 'hydro lab' is the best filter in the pool because it learns that
    # # it is most corralted to a yedia erkit)
    # # play with the params window size and filter num - if the input text is clean and meaningfull we can use more than 16 filters... otherwise like in samim 16 could be too big
    # text_cnn = Conv1D(32, 3, activation='relu', name='text_cnn')(embedded_text)
    # # text_cnn = MaxPooling1D(2)(text_cnn)
    # # text_cnn = Conv1D(8, 2, activation='relu')(text_cnn)
    # # x = MaxPooling1D(5)(x)
    # # x = Conv1D(128, 5, activation='relu')(x)
    # text_pool = GlobalMaxPooling1D(name='text_pool')(text_cnn)
    #
    # #joined_input = Concatenate()([input_ordinal] + [input_graph] + [text_pool])
    # #joined_input = Concatenate()([] [text_pool])joined_input = [text_pool]
    #
    # joined_input = text_pool
    # # try different combinations
    # #joined_input = Concatenate()([input_ordinal] + [input_graph])
    #
    # # Dense is final layer (can be more that one layer of dense)) it can have output
    # # try to change the output to 1 (linear output or sigmoid)
    # out = Dense(2, activation='softmax')(joined_input)
    #
    # #model = Model(inputs=[input_ordinal] + [input_text], outputs=[out])  # ,auxiliary_output])
    # #model = Model(inputs=[input_ordinal] + [input_graph], outputs=[out])  # ,auxiliary_output])
    #
    # # create the whole model from input to output
    # model = Model(inputs=input_text, outputs=out)  # ,auxiliary_output])
    # model.compile(loss='binary_crossentropy', metrics=['accuracy'], optimizer='adam')
    #
    # model.summary()
    #
    #
    #
    # model.fit(X_text_train, y_train_cat, batch_size=16, epochs=5, class_weight=class_weight)
    #
    # # model.fit([X_ordinal_train] + [X_graph_train], y_train_cat, batch_size=32, epochs=5)
    # # model.fit([X_ordinal_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
    # # model.fit([X_ordinal_train] + [X_graph_train] + [X_text_train], y_train_cat, batch_size=32, epochs=5)
    # # pred_soft = np.diff(model.predict([X_ordinal_test] + [X_text_test]))
    # # pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test]))
    # # pred_soft = np.diff(model.predict([X_ordinal_test] + [X_graph_test] + [X_text_test]))
    #
    # pred_hard = model.predict(X_text_test)
    # pred_soft = np.diff(model.predict(X_text_test))
    # print(f'metric.roc_auc_score(y_test, pred_soft){metric.roc_auc_score(y_test, pred_soft)}')
    #
    # plt.figure(4)
    # plt.hist(pred_soft[y_test == 0], color='r', bins=50, density=True)
    # plt.hist(pred_soft[y_test == 1], color='g', bins=50, alpha=0.8, density=True)
    #
    # plt.figure('xx')
    # plt.hist(pred_hard[y_test==0][:,1], color='r', bins=50, density=True)
    # plt.hist(pred_hard[y_test == 1][:,1], color='g', bins=50, alpha=0.8, density=True)

    # p1 = p1[:,1]
    # plt.figure('xx')
    # plt.hist(p1[y_test == 0], color='r', bins=50, density=True)
    # plt.hist(p1[y_test == 1], color='g', bins=50, alpha=0.8, density=True)

    # return model


if __name__ == "__main__":
    main()
