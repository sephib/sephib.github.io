import json
import pandas as pd
import numpy as np
from scipy.stats import pearsonr, spearmanr
import networkx as nx
from sklearn.base import BaseEstimator, TransformerMixin
from pathlib import Path
import sys

sys.path.append("/home/e038269676/projects/baldarim")
dict_conf = "data/data_dicts.json"

# %%
def is_date(df, col, string_ratio=0.02):
    """
    check if a column in a dataframe is a date or not
    :param df: the dataframe to check if it's ok - Dataframe
    :param col: the column to operate over - string
    :param string_ratio: the ratio that deside if there failed attempts / size of vector percentage larger than ratio
    than the feature is not a date - float
    :return: if the column is a date or not - boolearn
    """

    try:
        pd.to_datetime(df[col])
    except Exception as e:
        return False

    return True


def get_columns_by_type(df):
    str_cols = df.select_dtypes(object).columns.to_list()
    num_cols = df.select_dtypes("number").columns.to_list()
    bool_cols = df.select_dtypes("bool").columns.to_list()
    cat_cols = df.select_dtypes("category").columns.to_list()
    date_cols = [col for col in cat_cols if is_date(df, col)]
    return {
        "str": str_cols,
        "num": num_cols,
        "bool": bool_cols,
        "category": cat_cols,
        "date": date_cols,
    }


def get_df_columns_without_na(df: pd.DataFrame, list_columns: list = None) -> list:
    columns_without_na = (
        df[list_columns].columns[df[list_columns].isnull().any()].to_list()
    )
    return list(set(df[list_columns].columns.to_list()) - set(columns_without_na))


# %%
# function to replace threshold of number (e.g. replace negative )
def replace_vals_from_num_columns(
    df: pd.DataFrame, num_cols: list = None, val_cond: int = 0, val_other: int = 0
) -> pd.DataFrame:
    if not num_cols:
        raise
    s = df[num_cols].where(cond=df[num_cols] < val_cond, other=None).count()
    if s[s > 0].index.any():
        print(f"columns altered: {s[s>0].index}")
        for i in s[s > 0].index:
            df[i] = df[i].mask(cond=df[i] < val_cond, other=val_other)
        return df
    else:
        print(f"No values to be replaced")
        return df


def get_df_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    total = df.isnull().sum().sort_values(ascending=False)
    percent = (df.isnull().sum() / df.isnull().count()).sort_values(ascending=False)
    df_features_missing_data = pd.concat(
        [total, percent], axis=1, keys=["Total", "Percent"]
    )
    df_features_missing_data = df_features_missing_data[
        df_features_missing_data["Total"] > 0
    ]
    df_features_missing_data = df_features_missing_data.join(
        df.dtypes.to_frame(name="type"), how="left",
    )
    return df_features_missing_data


def merge_categories_to_other(
    ser: pd.Series, top_num_categories: int = 10, other_name: str = "other"
) -> pd.Series:
    top_num = ser.value_counts().nlargest(top_num_categories).index
    new_ser = ser.where(ser.isin(top_num), other=other_name)
    return new_ser


def fillna_df_with_dict(df: pd.DataFrame, fillna_dict: dict) -> pd.DataFrame:
    for k, v in fillna_dict.items():
        if not any(df[k].isna()):
            continue
        elif k in df.select_dtypes("category"):
            if v not in df[k].cat.categories:
                df[k] = df[k].cat.add_categories(v)
        df[k] = df[k].fillna(v)
    return df


def handle_duplicate_tz(df: pd.DataFrame, col_tz: str = "TZ") -> pd.DataFrame:
    """
    Need to verify that there is only one observation per TZ
    """
    # Check if TZ is unique and set it to index
    # Remove TZ and keep and index corresponding
    # TODO handle the TZ in a better fasion (mabe not only first)
    if not df[col_tz].is_unique:
        dfg = df.groupby(col_tz).size()
        tz_list = dfg[dfg > 1].index.to_list()
        print(f"These TZ are duplicates: {tz_list}")
        df = df.drop_duplicates(subset=["TZ", "Group"], keep="first").reset_index(
            drop=True
        )
    return df


def set_df_col_dtype(df, dict_conf):
    for k, v in dict_conf.items():
        if k == "bool":
            yes = "כן"
            no = "לא"
            bool_cols = [c for c in dict_conf[k] if c in df.columns]
            for col in bool_cols:
                df[col] = df[col].map({yes: 1, no: 0})
        for i in v:
            if i in df.columns.tolist():
                try:
                    # print(f'{i}')
                    df[i] = df[i].astype(k)
                except:
                    print(f"failed to set type to: {i} astype: {k}")
            else:
                print(f"No column: {i} to convert")
    return df


def update_category_dtype(df, _dict):
    # create all categories based on 2 values
    columns_potential_bool = {}
    for c in _dict["category"]:  # *_dty['bool'],
        if len(df[c].cat.categories) <= 2:
            columns_potential_bool[c] = df[c].cat.categories.to_list()
    # remove non-boolean colums from columns_potential_bool
    non_bool_vals = ["['ביומטרי', 'רגיל']", "['זכר', 'נקבה']"]
    columns_potential_bool = {
        k: v for k, v in columns_potential_bool.items() if str(v) not in non_bool_vals
    }
    return columns_potential_bool


def standertize_bool_columns(df, dict_columns_potential_bool):
    # convert all relevant bool columns
    mapping_convert_to_bool = {
        0: False,
        1: True,
        2: False,
        "כן": True,
        "לא": False,
    }
    for k, v in dict_columns_potential_bool.items():
        if all([True if x in mapping_convert_to_bool else False for x in v]):
            df[k] = df[k].map(mapping_convert_to_bool).astype(bool)
    return df


def reduce_df_dtype_size(df, dict_reduce=None) -> pd.DataFrame:
    if dict_reduce is None:
        dict_reduce = {
            "float64": "float32"
            #               ,'float32':'Int64'
        }
    for k, v in dict_reduce.items():
        cols = list(df.select_dtypes(k).columns)
        for c in cols:
            df[c] = df[c].astype(v)
    return df


def preprocessing_df(df, dict_conf_dir=None):
    if not dict_conf_dir:
        dict_conf_dir = "data/data_dicts.json"
    with open(dict_conf_dir, "r") as _conf:
        dict_conf = json.load(_conf)
    df = set_df_col_dtype(df, dict_conf["_dty"])
    dict_columns_potential_bool = update_category_dtype(df, dict_conf["_dty"])
    df = standertize_bool_columns(df, dict_columns_potential_bool)
    df = reduce_df_dtype_size(df)
    dfl = get_columns_by_type(df)
    df = replace_vals_from_num_columns(df, num_cols=dfl["num"])
    df = fillna_df_with_dict(df, dict_conf["column_fill_na"])
    return df


# simple usage of percentile
# def quantile_mask(X, percentile):
#     if X:
#         msk = (X > np.percentile(X, percentile))
#         X = X.mask(cond=msk, other=None)
#     return X
# def drop_outliers(df, cols, percentile=99):
#     df[cols] = df[cols].apply(lambda X: quantile_mask(X, percentile))
#     df = df.dropna(axis='index', subset=cols)
#     print(f'shape of df after dropping outliers {df.shape}')
#     return (df)
# drop_outliers(df, num_cols_without_na, percentile=99.5)


def pearsonr_pval(x, y):
    return pearsonr(x, y)[1]


def get_correlated_cols(df, col_list, corr_threshold=0.85, pval_threshold=0.05):
    pval_mat = df[col_list].corr(method=pearsonr_pval)
    corr_mat = df[col_list].corr()
    corr_mat = corr_mat.astype(float)
    pval_mat = pval_mat.astype(float)
    # stay with records which have corr >= corr_threshold(0.85) and < 1.0
    corr_mat = corr_mat[
        corr_mat.select_dtypes("number").ge(corr_threshold)
        & corr_mat.select_dtypes("number").ne(1.0)
    ].reset_index(drop=False)
    # stay with records which have pval <= pval_threshold
    pval_mat = pval_mat[
        pval_mat.select_dtypes("number").le(pval_threshold)
    ].reset_index(drop=False)
    col_a = "col_a"
    col_b = "col_b"
    corr_mat = corr_mat.rename(columns={"index": col_a})
    pval_mat = pval_mat.rename(columns={"index": col_a})
    corr_cols = pd.melt(corr_mat, id_vars=[col_a], var_name=col_b, value_name="corr")
    corr_cols = corr_cols[~(corr_cols["corr"].isna())].set_index([col_a, col_b])
    pval_cols = pd.melt(pval_mat, id_vars=[col_a], var_name=col_b, value_name="pval")
    pval_cols = pval_cols[~(pval_cols["pval"].isna())].set_index([col_a, col_b])
    corr_cols = corr_cols.merge(
        pval_cols, how="inner", left_index=True, right_index=True
    ).reset_index()
    return corr_cols, col_a, col_b


def get_null_percentage(df) -> pd.Series:
    return df.isna().sum() / len(df)


def get_empty_cols_list(df, threshold):
    s = get_null_percentage(df)
    empty_cols = s[s > threshold].index
    return empty_cols


def drop_corr_cols(df, cols):
    # 1) get the correlated columns in df based on both corr and pval
    # 2) the result of step 1 is a dataframe with cols: col_a, col_b, corr, pval. This df
    # contians only records for cols which are correlated.
    # create a graph from the df in step 2 such that there is an edge between col_a and col_b
    # the grpah has some subgraphs - keep the first node in each subgraph and drop all the rest
    empty_cols = get_empty_cols_list(df[cols], 0.3)
    col_list = set(cols) - set(empty_cols)
    corr_cols, col_a_name, col_b_name = get_correlated_cols(df, col_list, 0.85, 0.05)
    print(f"corr_cols:{corr_cols}")
    G = nx.convert_matrix.from_pandas_edgelist(corr_cols, col_a_name, col_b_name)
    sub_graphs = nx.connected_components(G)
    drop_cols = []
    for sg in sub_graphs:
        drop_cols.extend(list(sg)[1:])
    print(f"dropping cols:{drop_cols}")
    df = df.drop(columns=drop_cols)
    return df, drop_cols


def get_predict_tz(grid, X, df_tz, TZ):
    if TZ is None:
        raise
    df_label_pred = pd.DataFrame(grid.predict(X), dtype=int, columns=["label"])
    df_label_proba_pred = pd.DataFrame(
        grid.predict_proba(X), dtype=float, columns=["pred0", "pred1"]
    )
    df_tz_pred = pd.DataFrame(df_tz).join([df_label_pred, df_label_proba_pred])
    print(df_tz_pred[df_tz_pred["TZ"] == TZ])


def get_predtict_tz_metrics(idx_tz, y_proba, y_pred):
    return {
        "tz_pred_label": float(y_pred[idx_tz]),
        "tz_pred_Baldar": float(y_proba[idx_tz]),
    }


def verify_balder_isin_valid_dataset(idx_tz, idx_train, idx_valid):
    """
    verify that the TZ index is in the validation dataset and not in the test dataset    
    """
    if not idx_tz in idx_valid:
        idx_train = np.setdiff1d(idx_train, idx_tz)
        idx_valid = np.append(idx_valid, idx_tz)
    return idx_train, idx_valid


def merge_y_test_to_df(df_y_predict, y_proba_, y_predict_, idx=None, step=None):
    pred = f"pred_{step}"
    proba = f"proba_{step}"
    df = pd.concat(
        [
            df_y_predict.iloc[idx],
            pd.DataFrame(y_proba_, columns=[proba], index=idx),
            pd.DataFrame(y_predict_, columns=[pred], index=idx),
        ],
        axis=1,
    )
    return df


def read_csv_files_in_folder(folder, sep="|"):
    p = Path(folder).glob("*.csv")
    files = [fn for fn in p if fn.is_file()]
    df = pd.DataFrame()
    for fn in files:
        df_ = pd.read_csv(fn, sep=sep)
        df = df.append(df_)
    df = df.reset_index()
    df = df.drop_duplicates()
    print(f"len of df: {len(df)}")
    return df


def handle_negative_numeric_cols(df):
    msk = df < 0
    df = df.mask(cond=msk, other=None)
    return df


class CustomTransformer(BaseEstimator, TransformerMixin):
    """
    a general class for creating a machine learning step in the machine learning pipeline
    """

    def __init__(self):
        """
        constructor
        """
        super(CustomTransformer, self).__init__()

    def fit(self, X, y=None, **kwargs):
        """
        an abstract method that is used to fit the step and to learn by examples
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: self: the class object - an instance of the transformer - Transformer
        """
        pass

    def transform(self, X, y=None, **kwargs):
        """
        an abstract method that is used to transform according to what happend in the fit method
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: X: the transformed data - Dataframe
        """
        pass

    def fit_transform(self, X, y=None, **kwargs):
        """
        perform fit and transform over the data
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: X: the transformed data - Dataframe
        """
        self = self.fit(X, y)
        return self.transform(X, y)


class ClearNoVarCategoriesTransformer(CustomTransformer,):
    """
    transformer that remove categorical features with no variance
    """

    def __init__(self, categorical_cols=[]):
        """
        constructor
        :param categorical_cols: the categoric columns to transform - list
        """
        super(ClearNoVarCategoriesTransformer, self).__init__()
        self.threshold = 0.9
        self.categorical_cols = categorical_cols
        self.include_cols = []
        self._columns = None

    def _clear(self, df, col):
        """
        check if we have more than one level in a categorical feature and removes it if not
        :param df: the Dataframe to check - Dataframe
        :param col: the column to check in the Dataframe - string
        """
        if df[col].value_counts(normalize=True)[0] < self.threshold:
            self.include_cols.append(col)
        else:
            self.categorical_cols.remove(col)

    def fit(self, X, y=None, **kwargs):
        """
        learns which features need to be removed
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: self: the class object - an instance of the transformer - Transformer
        """
        # remember the origianl features
        self._columns = X.columns
        try:
            df = X.copy(True)
        except Exception as e:
            raise e
        try:
            if len(self.categorical_cols) > 0:
                cols = self.categorical_cols
            else:
                cols = df.columns
            for col in cols:
                self._clear(df, col)
        except Exception as e:
            print(e)
        # print("ClearNoCategoriesTransformer fit end")
        return self

    def transform(self, X, y=None, **kwargs):
        """
        removes all the features that were found as neede to be removed in the fit method
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: X[columns]: the transformed data with the chosen columns- Dataframe
        """
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X, columns=self._columns, copy=True)
        removed = [
            col2 for col2 in self.categorical_cols if col2 not in self.include_cols
        ]
        columns = [col for col in X.columns if col not in removed]
        # print("ClearNoCategoriesTransformer transform end")
        return X[columns]


class BaldarimPreprocessor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.feature_names = []

    def _get_df_missing_values(df: pd.DataFrame) -> pd.DataFrame:
        total = df.isnull().sum().sort_values(ascending=False)
        percent = (df.isnull().sum() / df.isnull().count()).sort_values(ascending=False)
        df_features_missing_data = pd.concat(
            [total, percent], axis=1, keys=["Total", "Percent"]
        )
        df_features_missing_data = df_features_missing_data[
            df_features_missing_data["Total"] > 0
        ]
        df_features_missing_data = df_features_missing_data.join(
            df.dtypes.to_frame(name="type"), how="left",
        )
        return df_features_missing_data

    def _drop_cols_witn_missing_values_threshold(
        self, df, missing_values_threshold_percent=0.8
    ):
        df_missing_values = _get_df_missing_values(df)
        cols_to_drop = df_missing_values[
            df_missing_values.Percent > missing_values_threshold_percent
        ].index.to_list()
        df = df.drop(cols_to_drop, axis=1)
        return df

    # def _replace_vals_from_num_columns

    def transform(self, X, *args):
        X = self._drop_cols_with_missing_values_threshold(x)
        self.feature_names = X.columns
        return X

    def fit(self, X, *args):
        return self


class DataFrameSelector(BaseEstimator, TransformerMixin):
    def __init__(self, feature_names):
        self.feature_names = feature_names

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.feature_names].values


def main():
    pass


if __name__ == "__main__":
    main()
