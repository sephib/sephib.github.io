from keras.models import Sequential
from keras.layers import (
    Embedding,
    Conv1D,
    Conv2D,
    Dropout,
    Flatten,
    Dense,
    BatchNormalization,
)

import numpy as np
import tensorflow as tf
import random

from keras import backend as K

# from tensorflow.compat.v1.keras import backend  as K


# SEED=123
# np.random.seed(SEED)
# random.seed(SEED)
# tf.random.set_random_seed(SEED)
# tf.random.set_random_seed(123)
# tf_config = tf.ConfigProto(intra_op_parallelism_threads=1,
#                            inter_op_parallelism_threads=1,
#                           )
# sess = tf.Session(config=tf_config)
# K.set_session(sess)


def create_seq_cnn_fixed_kernel_size(input):
    # this is the original cnn which works very good
    kernel_size = 10
    model = Sequential()
    model.add(input)
    model.add(
        Conv1D(filters=16, kernel_size=kernel_size, activation="relu")
    )  # , input_shape=input_shape))
    model.add(Conv1D(filters=32, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Conv1D(filters=64, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Conv1D(filters=128, kernel_size=kernel_size, activation="relu"))  # new
    model.add(Dropout(0.3))
    # todo gila - check if we need twice 0.3
    model.add(Dropout(0.3))
    model.add(Flatten())
    model.add(Dense(64, activation="relu"))
    model.add(Dense(32, activation="relu"))
    model.add(Dense(16, activation="relu"))
    # output layer
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    model.summary()

    return model


def create_model(
    embedding_input_dim,
    embedding_output_dim,
    embedding_weights,
    input_length,
    kernel_size,
    seed,
):
    model = Sequential()
    model.add(
        Embedding(
            input_dim=embedding_input_dim,
            output_dim=embedding_output_dim,
            weights=[embedding_weights],
            input_length=input_length,
            trainable=False,
            #   mask_zero=True,
        ),
    )
    model.add(Conv1D(filters=16, kernel_size=kernel_size, activation="relu"))
    model.add(Conv1D(filters=32, kernel_size=kernel_size, activation="relu"))
    # model.add(BatchNormalization(trainable=True))
    model.add(Conv1D(filters=64, kernel_size=kernel_size, activation="relu"))
    model.add(Dropout(0.3, seed=seed))
    model.add(Conv1D(filters=128, kernel_size=kernel_size, activation="relu"))
    model.add(Dropout(0.3, seed=seed))
    model.add(Flatten())
    model.add(Dense(64, activation="relu"))
    model.add(Dropout(0.5, seed=seed))
    model.add(Dense(32, activation="relu"))
    model.add(Dropout(0.6, seed=seed))
    model.add(Dense(16, activation="relu"))

    # output layer
    model.add(Dense(2, activation="softmax"))
    model.compile(loss="binary_crossentropy", metrics=["accuracy"], optimizer="adam")
    # model.summary()

    return model


# def create_model(embedding_input_dim, embedding_output_dim, embedding_weights):
#     model = Sequential([
#         Embedding(input_dim=embedding_input_dim,
#                   output_dim=embedding_output_dim,
#                   weights=[embedding_weights],
#                   trainable=False,
#                   mask_zero=True),
#         LSTM(128),
#         Dense(1, activation='sigmoid')
#     ])
#     model.compile(loss='binary_crossentropy', optimizer='adam')
#     return model
