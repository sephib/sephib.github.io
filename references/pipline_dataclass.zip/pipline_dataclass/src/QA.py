import pandas as pd
import yaml
from catboost import CatBoostClassifier
import numpy as np
import datetime
import time
from sklearn import model_selection
import sys
import os
from pathlib import Path
from keras.models import model_from_json
from keras.preprocessing import text
import json
import pickle
from keras.models import load_model
from gensim.models import FastText as FT
from numpy import loadtxt

from src import drugs_util
import drugs_text as t

perf_log_df_cnn = None
models = None


path_home = Path(sys.path[-1]).home()
fcutils_path = path_home / "projects/fcutils"
sys.path.append(str(fcutils_path))

drugs_home_dir = path_home / "projects/drugs_trafficking/src"
sys.path.append(str(drugs_home_dir))

import proba_from_text
from fcutils import files, fc_logging
import drugs_text


def get_proba_from_nn(config_entry, doc_texts):
    # load a tokenizer trained on 5000 doc files and a cnn modle trained on the same dataset
    # predict the probabity of the new docs based on the cnn and tokenizer
    cnn_model_filename = config_entry["cnn_model_file"]
    tokenizer_file_name = config_entry["tokenizer_file"]
    print(cnn_model_filename)
    print(tokenizer_file_name)

    tokenizer_file = open(tokenizer_file_name, "r")
    tokenizer_json = json.loads(tokenizer_file.read())
    prod_tokenizer = text.tokenizer_from_json(tokenizer_json)

    cnn_prod_model = load_model(cnn_model_filename)
    prod_clean_texts = drugs_text.clean_yediot(doc_texts)

    prod_sequnces = proba_from_text.get_padded_sequence_from_text(
        prod_tokenizer, prod_clean_texts, proba_from_text.MAX_SEQUENCE_LENGTH
    )
    cnn_proba_prod = cnn_prod_model.predict(prod_sequnces)
    return cnn_proba_prod, cnn_prod_model


def proba_from_file(cnn_proba_file, df):
    df_cnn_proba = pd.read_csv(cnn_proba_file, sep="|")
    df = df.merge(
        df_cnn_proba[["docDisplayId", "proba_from_file"]],
        left_on="docDisplayId",
        right_on="docDisplayId",
        how="left",
    )
    return df


############################################################
############################################################
############################################################
############################################################
############################################################


def main(curr_yml):

    curr_yml = "drugs.yml"
    config_filepath = str(drugs_home_dir / curr_yml)
    cf = open(config_filepath)
    config_dict = yaml.safe_load(cf)
    in_files = config_dict["prod"]["input_files"]
    dirs = config_dict["base_dirs"]

    base = dirs["base1"]
    dfqa = pd.read_excel(base + "/raw/QA_drug_intel_test.xlsx")
    print(f"len of records labled {len(dfqa)}")

    x_prod_with_text = dfqa

    # create the probablity for the new docs from cnn model and add to the dataset
    doc_texts = x_prod_with_text["docText"]
    nn_proba, model = get_proba_from_nn(in_files, doc_texts)
    x_prod_with_text["proba"] = nn_proba[:, 1]

    file_name = base + "drugs_2019_with_proba_1153.csv"
    file_name
    x_prod_with_text.to_csv(file_name, sep="|")


if __name__ == "__main__":
    config_file = main("drugs.yml")
