# from mlflow import log_artifact, log_param
import logging
import os
import tempfile
from pathlib import Path

import mlflow
from sklearn.utils import estimator_html_repr 
import pandas as pd
import ruamel.yaml as yaml
import json


logger = logging.getLogger("fc_mlflow")


def log_plot(args, plot_func, fp):
    if not isinstance(args, (tuple)):
        args = (args,)
    plot_func(*args, fp)
    mlflow.log_artifact(fp)
    Path(fp).unlink()
    print(f"Logged {fp}")


def print_devider(title):
    print("\n{} {} {}\n".format("-" * 25, title, "-" * 25))


def save_df_to_artifact(df, run, name=None, model_name=None, index=False):
    df_path = f"{name}_{model_name}.csv"
    df.to_csv(
        f"{df_path}", index=index,
    )
    mlflow.log_artifact(df_path)
    mlflow.log_param(f"{name}", os.path.join(run.info.artifact_uri, df_path))
    os.remove(df_path)


def read_multiple_yamls(file_list: list) -> dict:
    dict_files = {}
    for file in file_list:
        dict_files.update(yaml.safe_load(open(file)))
    return dict_files


def load_parqs(parq_files):
    if not isinstance(parq_files, list):
        parq_files = [parq_files]
    dfs = []
    for parq_file in parq_files:
        if Path(parq_file).is_file():
            _df = pd.read_parquet(parq_file, engine="pyarrow")
            if "index" in _df.columns:
                _df = _df.drop(columns="index")
            dfs.append(_df)
            logger.debug(f"loaded {parq_file} praquet docs file: {_df.count()}")
        else:
            logger.error(f"File does not exists: {docs_parq}")
    return dfs


def load_parq(path_to_file):
    if Path(path_to_file).is_file():        
        df = pd.read_parquet(path_to_file, engine='pyarrow')        
        logger.debug(f"loaded {df} praquet docs file: {len(df)}")
    else:
        logger.error(f'File does not exists: {path_to_file}')
        exit()
    return df


def save_dfs_to_parq(dict_of_dfs: dict):
    tmpdir = tempfile.mkdtemp()
    meta_dict={}
    for name_df, df in dict_of_dfs.items():
        path_name_df = Path(tmpdir, f"{name_df}.parq")
        df.to_parquet(path_name_df)
        logger.debug(f"Saving {name_df}, dataframe shape: {df.shape}")
        mlflow.log_artifact(str(path_name_df), "data/interim")
        meta_dict[name_df] = {
                            'dtypes':df.dtypes.to_dict(),
                            'index_name':df.index.name,
        }
    path_meta_dict = Path(tmpdir, f"dfs_dtypes.txt")
    with open(path_meta_dict, 'w') as file:
        file.write(json.dumps({str(k):str(v) for k, v in meta_dict.items()}))
    mlflow.log_artifact(str(path_meta_dict), "data/interim")
        # mlflow.log_metrics({f'{name_df}_num_rows':df.shape[0],
        # f'{name_df}_num_cols':df.shape[1],})
    return path_meta_dict


def save_estimator_to_artifact(_obj, name:str='pipeline_diagram.html', mlflow_artifact_path:str="data/interim"):    
    path_artifact = Path(tempfile.mkdtemp(), f"{name}")
    with open(path_artifact, 'w') as f:
        f.write(estimator_html_repr(_obj))
    mlflow.log_artifact(str(path_artifact), mlflow_artifact_path)
    return path_artifact


def save_model_to_artifact(model_flavor, obj, name:str='model', mlflow_artifact_path:str=f"model"):  
    mlflow_artifact_path = f'{mlflow_artifact_path}'
    path_artifact = Path(tempfile.mkdtemp(), f"{name}")
    model_flavor.save_model(obj, path_artifact)    
    mlflow.log_artifacts(str(path_artifact), mlflow_artifact_path)
    return path_artifact


if __name__ == "__main__":
    pass
