import pandas as pd
import collections
import numpy as np
import sklearn.metrics as metric
from imblearn.over_sampling import SMOTE, ADASYN
import datetime
from pathlib import Path
import sys


path_home = Path(sys.path[-1]).home()
fcutils_path = path_home / "projects/fcutils"
sys.path.append(str(fcutils_path))
from fcutils import fc_logging

conf_mat = collections.namedtuple("conf_mat", "tn,fp,fn,tp")
FIXED_SEED = 420495104

# gila todo - enrich the validity function with more tests
def check_people_in_doc_valid(df):
    return 1 if len(df.columns) == 5 else 0


# gila todo - enrich the validity function with more tests
def check_doc_md_valid(df):
    return 1 if len(df.columns) == 12 else 0


# gila todo - enrich the validity function with more tests
def check_baldarim_md_valid(df):
    return 1 if len(df.columns) == 57 else 0


def get_timestamp():
    dt = datetime.datetime.today()
    timestamp = str(dt.day) + "_" + str(dt.month) + "_" + str(dt.hour) + str(dt.minute)
    return timestamp


def read_csv_files_in_folder(folder, sep="|"):
    p = Path(folder).glob("*.csv")
    files = [fn for fn in p if fn.is_file()]
    df = pd.DataFrame()
    for fn in files:
        df_ = pd.read_csv(fn, sep=sep)
        df = df.append(df_)
    df = df.reset_index()
    print(f"len of df: {len(df)}")
    return df


def get_label_file(expert_labeled_folder=None):

    p = Path(
        r"/home/e015976541/projects/drugs_trafficking/data/raw/training/expert_decisions/"
    ).glob("*.xlsx")
    files = [fn for fn in p if fn.is_file()]
    df_labeled = pd.DataFrame()
    for fn in files:
        print(fn)
        df_ = pd.read_excel(fn, header=None, skiprows=1)
        if len(df_.columns) > 2:
            print(df_.co)
            print(
                f"Expert file {fn} is not formatted correctly. Please provide a file with two columns"
            )
            continue

        if (df_[df_.columns[0]].astype(str).str.len().max()) > 1:
            df_ = df_.rename(
                columns={df_.columns[0]: "docDisplayId", df_.columns[1]: "label"}
            )

        if (df_[df_.columns[0]].astype(str).str.len().max()) == 1:
            df_ = df_.rename(
                columns={df_.columns[1]: "docDisplayId", df_.columns[0]: "label"}
            )

        df_labeled = df_labeled.append(df_)

    df_labeled = df_labeled.reset_index(drop=True)
    print(f"len of df: {len(df_labeled)}")

    # gila todo : test only
    # df_labeled = df_labeled.head(1440)
    df_labeled = df_labeled[~df_labeled.label.isna()]

    df_labeled.label = df_labeled.label.astype(int)
    return df_labeled


def get_split_mask(mask_len, test_frac=0.2, seed=-1):
    if seed < 0:
        msk = np.random.rand(mask_len) < test_frac
    else:
        np.random.seed(seed)
        msk = np.random.rand(mask_len) < test_frac
    return msk


def metrics(y_test, prediction):
    f1score = metric.f1_score(y_test, prediction)
    auc = metric.roc_auc_score(y_test, prediction)
    tn, fp, fn, tp = metric.confusion_matrix(y_test, prediction).ravel()
    confMat = conf_mat(tn=tn, fp=fp, fn=fn, tp=tp)
    return auc, f1score, confMat


def print_metric(classifier, auc, f1score, conf_mat):
    print(
        f"classifier={classifier},\
          auc={auc},\
    f1_score={f1score},tn={conf_mat.tn},\
    fp={conf_mat.fp},fn={conf_mat.fn},tp={conf_mat.tp}"
    )


def get_class_weight(y):
    cnt = collections.Counter(y)
    false_weight = 1.0
    true_weight = cnt[0] / cnt[1]
    class_weight = {0: false_weight, 1: true_weight}
    return class_weight


def Smote_Adasyn(x_train, y_train, print_len=0, smote_adasyn="SMOTE"):

    if smote_adasyn == "SMOTE":
        x_over, y_over = SMOTE().fit_resample(x_train, y_train)
    else:
        x_over, y_over = SMOTE().fit_resample(x_train, y_train)

    if print_len:
        print(len(x_train))

        print(len(x_over))
        print(len(y_over))

    return x_over, y_over, x_train, y_train


def get_metrics(p, y_test):
    auc, f1_score, conf_mat = metrics(y_test, p)
    return auc, f1_score, conf_mat


def show_results(p, y_test):
    auc, f1_score, conf_mat = metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")


def add_prob_to_df(df, index_train, index_test, p_test, p_train, col_name="proba"):
    df[col_name] = 0
    df.loc[index_train, col_name] = p_train[:, 1]
    df.loc[index_test, col_name] = p_test[:, 1]
    return df


# use a formula to detect the optimal threshold such that we minimize fn and minimize fp
def get_optimal_threshold(
    df, max_fn_tp_cut=0.18, tn_treshold_factor=0.001, fp_tn_fn_tp_threshold=0.1
):
    # filter out irelevant thresholds
    fold_num = df["fold_num"][0]
    tn_threshold = len(df) * (tn_treshold_factor)
    msk = (df.fn == 0) & (df.tn < tn_threshold)
    df = df[~msk]

    fn_tp_col = "fn/tp"
    fp_tn_col = "fp/tn"
    tn_fp_col = "tn/fp"

    # to avoid division by zero change fn=0 to 0.1
    df.loc[df.fn == 0, "fn"] = 0.1

    df[fn_tp_col] = df["fn"] / (df["tp"] + df["fn"])
    msk = df[fn_tp_col] <= max_fn_tp_cut
    df = df[msk]

    df[fp_tn_col] = df["fp"] / (df["tn"] + df["fp"])
    df[tn_fp_col] = df["tn"] / (df["tn"] + df["fp"])

    df["fp_tn/fn_tp"] = df[fp_tn_col] / df[fn_tp_col]
    # cols = ['round', 'fn', 'tp', 'fp', 'tn', 'threshold', fn_tp_col, fp_tn_col, tn_fp_col, 'fp_tn/fn_tp']
    # df[cols].head(20)

    # threshold is an increasing series
    # a=fn/fn+tp is increasing series relative to thresholds
    # b=fp/fp+tn is decreasing series relative to thresholds
    # c=tn/fp+tn is increasing series relative to threshold
    # b/a is fast decreasing series

    # for each threshold, take the one with max(tn_fp_col) - this is probably the best fp_tn ratio
    df_g = df.loc[df.groupby(["fold_num", "fn"])[tn_fp_col].idxmax()]
    df_g = df_g.reset_index()

    # [almost] best threshold has max(logn(x='tn/fp'*10, base='fp_tn/fn_tp')
    # multiply df_g[tn_fp_col] by 10 to avoid negative logs
    # May 2020 - this is too complicated. use the simpler solution
    # df_g[tn_fp_col] = df_g[tn_fp_col]*10
    # df_g['final'] = df_g.apply(log_formula_best_threshold, axis=1)
    # mx_row = df_g.loc[df_g.groupby(['round'])['final'].idxmax()]

    df_g = df_g[df_g["fp_tn/fn_tp"] >= fp_tn_fn_tp_threshold]
    opt_row = df_g.loc[df_g.groupby(["fold_num"])["fp_tn/fn_tp"].idxmin()]

    if opt_row.empty:
        return pd.Series(
            data=[
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                fold_num,
            ],
            index=[
                "threshold",
                "fn/tp",
                "fp/tn",
                "tn/fp",
                "fn",
                "tp",
                "fp",
                "tn",
                "fold_num",
            ],
        ).rename(f"{fold_num}")

    return (
        opt_row[
            [
                "threshold",
                fn_tp_col,
                fp_tn_col,
                tn_fp_col,
                "fn",
                "tp",
                "fp",
                "tn",
                "fold_num",
            ]
        ]
        .iloc[0]
        .rename(f"{fold_num}")
    )
