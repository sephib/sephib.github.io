import datetime
import glob
import logging
import pickle
import sys
import time
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import ruamel.yaml as yaml
import vtreat
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from scipy.stats import pearsonr, spearmanr
from sklearn import model_selection
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.feature_selection import VarianceThreshold
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils import resample
from xgboost import XGBClassifier

import drugs_text as t
import drugs_util
import proba_from_text
from fcutils import fc_logging
import drugs_util

warnings.simplefilter(action="ignore", category=Warning)


# path_home = Path(sys.path[-1]).home()
# cur_path = '/home/e015976541/projects/drugs_trafficking/src'
# sys.path.append(str(cur_path))


perf_log_df_models = None
models = None


path_home = Path(sys.path[-1]).home()
fcutils_path = path_home / "projects/fcutils"
sys.path.append(str(fcutils_path))

drugs_home_dir = path_home / "projects/drugs_trafficking/src"
sys.path.append(str(drugs_home_dir))


def run_classifier_predict_proba(
    classifier,
    x_train,
    x_test,
    y_test,
    proba_df=None,
    index_train=None,
    index_test=None,
    round=0,
    logger=None,
):

    global perf_log_df_models

    logger.debug(f"x_test columns:{x_test.columns}")
    p_test = classifier.predict_proba(x_test)
    if proba_df is not None:
        col_name = "proba" + str(round)
        p_train = classifier.predict_proba(x_train)

        # in this version we only set the proba for test set (not the train set)
        # proba_df[col_name] = None
        proba_df.loc[index_test, col_name + "_test"] = p_test[:, 1]
        proba_df = drugs_util.add_prob_to_df(
            proba_df, index_train, index_test, p_test, p_train, col_name
        )

    for t in np.arange(0.1, 0.6, 0.05):
        logger.info(f"Adding Threshold {t} to dataset...\n")
        p1 = p_test[:, 1]
        auc, f1_score, confMat = drugs_util.get_metrics((p1 >= t).astype(int), y_test)
        add_to_log(classifier, auc, f1_score, confMat, "", t, round=round)

    return proba_df


def create_agg_funcs_per_col(bcols, num_cols_per_person, num_cols_per_doc):
    d = {}
    d["ID"] = "count"
    d["docId"] = "first"
    d["TikId"] = "min"
    d["TikType"] = "min"

    # maybe avg not sum
    for col in bcols:
        col = str(col)
        # gila todo: max or sum for bool cols?!?!?!
        d[col] = "sum"
        # agg_str = agg_str + "'" + col + "':'max',"

    for col in num_cols_per_person:
        col = str(col)
        d[col] = "mean"
        # agg_str = agg_str + "'" + col + "':'max',"

    for col in num_cols_per_doc:
        col = str(col)
        d[col] = "first"

    return d


def get_columns_by_type(df):

    scols = df.select_dtypes(object).columns
    num_cols = df.select_dtypes("number").columns.difference(
        ["ID", "TikType", "TikId", "docId"]
    )

    bcols = [
        x
        for x in scols
        if (
            (df[df[x].notna()][x].astype(str).str.strip() == "כן")
            | (df[df[x].notna()][x].astype(str).str.strip() == "לא")
            | (df[df[x].notna()][x].astype(str).str.strip() == "0")
            | (df[df[x].notna()][x].astype(str).str.strip() == "1")
        ).all()
    ]

    scols = set(scols) - set(bcols)

    return scols, bcols, num_cols


def add_to_log(
    classifier,
    auc,
    f1,
    conf_mat1: drugs_util.conf_mat,
    remark="",
    threshold=0.5,
    round=0,
):
    global perf_log_df_models
    perf_log_df_models = perf_log_df_models.append(
        {
            "classifier": type(classifier),
            "auc": auc,
            "f1_score": f1,
            "tp": conf_mat1.tp,
            "fn": conf_mat1.fn,
            "fp": conf_mat1.fp,
            "tn": conf_mat1.tn,
            "threshold": threshold,
            "remark": remark,
            "round": round,
            "date": datetime.datetime.now(),
            "clf_params": classifier,
        },
        ignore_index=True,
    )


# balance the datasets using resample (increase minority or decrease majority) -
# both were not good enough
def resample_up_minority(df_re):
    df_1 = df_re[df_re.label > 0]
    df_0 = df_re[df_re.label == 0]
    df_1_upsampled = resample(df_1, replace=True, n_samples=len(df_0) - len(df_1))

    return pd.concat([df_re, df_1_upsampled])


def resample_down_majority(df_re):
    df_1 = df_re[df_re.label > 0]
    df_0 = df_re[df_re.label == 0]
    df_0_downsampled = resample(df_0, replace=False, n_samples=len(df_1))

    return pd.concat([df_1, df_0_downsampled])


def get_balanced_dfs(df_w_l, balance_method):
    msk = drugs_util.get_split_mask(len(df_w_l))
    x_train_0 = df_w_l[~msk]

    x_test = df_w_l[msk]
    y_test = df_w_l["label"][msk].astype("int").values
    x_test = x_test.drop(columns=["label"])
    x_train = balance_method(x_train_0)
    y_train = x_train.label
    x_train = x_train.drop(columns=["label"])

    print(f"len balanced x_train:{len(x_train)}")
    print(f"len x_test:{len(x_test)}")
    print(f"len y_train==1:{len(y_train[y_train > 0])}")
    print(f"len y_train==0:{len(y_train[y_train == 0])}")

    return x_train, y_train, x_test, y_test


def split_df(df_w_l, index, seed=None, train_size=0.8, logger=None):

    y = df_w_l.label
    df_w_l = df_w_l.drop(columns=["label"])

    (
        x_train,
        x_test,
        y_train,
        y_test,
        index_train,
        index_test,
    ) = model_selection.train_test_split(
        df_w_l, y, index, train_size=train_size, random_state=seed
    )

    logger.debug(f"len df:{len(df_w_l)}")
    logger.debug(f"len x_train:{len(x_train)}")
    logger.debug(f"len x_test:{len(x_test)}")
    logger.debug(f"len(y_train==1):{len(y_train[y_train > 0])}")
    logger.debug(f"len (y_train==0):{len(y_train[y_train == 0])}")

    # return x_train, y_train, x_test, y_test, msk
    return x_train, y_train, x_test, y_test, index_train, index_test


def get_stat(df, cols):
    stats = pd.DataFrame(
        columns=["col_name", "std", "var", "median", "mean", "mean - median"]
    )

    for c in cols:
        X = df[c]
        np.median(X)
        stats = stats.append(
            {
                "col_name": c,
                "std": np.std(X),
                "var": np.var(X),
                "median": np.median(X),
                "mean": np.mean(X),
                "mean - median": abs(np.mean(X) - np.median(X)),
            },
            ignore_index=True,
        )

    return stats


def get_empty_cols_list(df, threshold):
    s = get_null_percentage(df)
    empty_cols = s[s > threshold].index
    return empty_cols


def pearsonr_pval(x, y):
    return pearsonr(x, y)[1]


def get_correlated_cols(df, col_list, corr_threshold=0.85, pval_threshold=0.05):
    pval_mat = df[col_list].corr(method=pearsonr_pval)
    corr_mat = df[col_list].corr()

    corr_mat = corr_mat.astype(float)
    pval_mat = pval_mat.astype(float)

    # stay with records which have corr >= corr_threshold(0.85) and < 1.0
    corr_mat = corr_mat[
        corr_mat.select_dtypes("number").ge(corr_threshold)
        & corr_mat.select_dtypes("number").ne(1.0)
    ].reset_index(drop=False)

    # stay with records which have pval <= pval_threshold
    pval_mat = pval_mat[
        pval_mat.select_dtypes("number").le(pval_threshold)
    ].reset_index(drop=False)

    col_a = "col_a"
    col_b = "col_b"

    corr_mat = corr_mat.rename(columns={"index": col_a})
    pval_mat = pval_mat.rename(columns={"index": col_a})

    corr_cols = pd.melt(corr_mat, id_vars=[col_a], var_name=col_b, value_name="corr")
    corr_cols = corr_cols[~(corr_cols["corr"].isna())].set_index([col_a, col_b])

    pval_cols = pd.melt(pval_mat, id_vars=[col_a], var_name=col_b, value_name="pval")
    pval_cols = pval_cols[~(pval_cols["pval"].isna())].set_index([col_a, col_b])

    corr_cols = corr_cols.merge(
        pval_cols, how="inner", left_index=True, right_index=True
    ).reset_index()

    return corr_cols, col_a, col_b


def drop_corr_cols(df, cols, logger):
    # 1) get the correlated columns in df based on both corr and pval
    # 2) the result of step 1 is a dataframe with cols: col_a, col_b, corr, pval. This df
    # contians only records for cols which are correlated.
    # create a graph from the df in step 2 such that there is an edge between col_a and col_b
    # the grpah has some subgraphs - keep the first node in each subgraph and drop all the rest

    empty_cols = get_empty_cols_list(df[cols], 0.3)
    col_list = set(cols) - set(empty_cols)

    corr_cols, col_a_name, col_b_name = get_correlated_cols(df, col_list, 0.85, 0.05)
    logger.info(f"corr_cols:{corr_cols}")

    G = nx.convert_matrix.from_pandas_edgelist(corr_cols, col_a_name, col_b_name)
    sub_graphs = nx.connected_components(G)
    drop_cols = []

    for sg in sub_graphs:
        drop_cols.extend(list(sg)[1:])

    logger.info(f"drop_corr_cols is dropping {len(drop_cols)} cols:\n{drop_cols}")
    df = df.drop(columns=drop_cols)
    return df, drop_cols


def drop_near_zero_var_cols(df, cols, frq_cut=95 / 5, unique_cut=10, logger=None):
    drop_cols = []
    for col in cols:
        try:
            vc = df[col].value_counts(sort=True, dropna=True).to_frame().reset_index()
            if len(vc) == 1:
                drop_cols.append(col)
                continue
            max_val = vc.max()
            sec_val = vc.iloc[1]

            nunique = df[col].nunique()
            if (max_val[col] / sec_val[col]) > frq_cut:
                drop_cols.append(col)

        except:
            logger.critical(f"near_zero_var could not handle col {col}")
            continue

    logger.info(f"near_zero_var() is dropping {len(drop_cols)} columns:\n {drop_cols}")
    df = df.drop(columns=drop_cols)
    return df, drop_cols


# incorrect code for near zero variance detection
# def get_zero_var_cols(df, cols:list, threshold=0.9) -> list:
#     # try different thresholds
#
#     x= [[1, 0, 1],
#        [1, 1, 0],
#        [0, 0, 1],
#        [0, 1, 0],
#        [0, 0, 1],
#        [0, 1, 0],
#        [0, 0, 1],
#        [0, 1, 0],
#        [0, 0, 1]]
#
#
#     #sel = VarianceThreshold(threshold=threshold*(1-threshold))
#     sel = VarianceThreshold(threshold=0.95)
#     zero_var_array = sel.fit_transform(df[cols])
#     #zx = sel.fit_transform(x)
#     #zx
#
#     retained_col_index = sel.get_support(indices=True)
#     len(retained_col_index)
#
#     cols = np.asarray(cols)
#     retained_cols = cols[retained_col_index.tolist()]
#     return (set(cols) - set(retained_cols))
#
#
# def drop_zero_variance_cols(df, cols:list, threshold=0.9):
#     zv_cols = get_zero_var_cols(df, cols, threshold)
#     print(f'Dropping zero_var_cols:{zv_cols}')
#     df = df.drop(columns=zv_cols)
#     return df, zv_cols


def scale_data(df, cols, scaler):
    return scaler.fit_transform(df[cols])


def scale_num_cols(df, cols):
    # scale cols
    scaler = StandardScaler()
    # or:
    # scaler = MinMaxScaler(feature_range=(0,1))
    df[cols] = scale_data(df, cols, scaler=scaler)
    return df[cols]


def handle_onSetIntel_col(df):
    col = "OnsetIntel"
    # df[col] = df.mask(cond=df[col] < 0, other=None) BUG - should be:
    df[col] = df[col].mask(cond=df[col] < 0, other=None)
    df[col] = df[col].fillna(df[col].median())
    return df[col]


def fix_data(df):
    scols, bcols, num_cols = get_columns_by_type(df)

    df["OnsetIntel"] = handle_onSetIntel_col(df)
    df[num_cols] = handle_negative_numeric_cols(df[num_cols])

    lag_list = [c for c in df.columns if c.startswith("Lag")]
    df[lag_list] = df[lag_list].astype("float")
    df[lag_list] = df[lag_list].apply(lambda x: x.fillna(x.mean()), axis=0)

    df[num_cols] = df[num_cols].fillna(0)
    df[bcols] = fix_bool_cols(df, bcols)
    return df


def fix_bool_cols(df, bcols):
    ken = "כן"
    lo = "לא"
    df[bcols] = df[bcols].replace(ken, 1)
    df[bcols] = df[bcols].replace(lo, 0)

    return df[bcols]


def handle_negative_numeric_cols(df):
    msk = df < 0
    df = df.mask(cond=msk, other=None)
    return df


def agg_less_freq_values(df, col, percentile=95):
    X = df[col]
    new_val = X.max() + 10

    msk = X > np.percentile(X, percentile)
    X = X.mask(cond=msk, other=new_val)
    return X


def quantile_mask(X, percentile):
    msk = X > np.percentile(X, percentile)
    X = X.mask(cond=msk, other=None)
    return X


def zero_to_one(X):
    msk = X == 0
    X = X.mask(cond=msk, other=1)
    return X


def fading_func(x):
    return 1 / (1 - np.exp(-x))


def drop_outliers(df, cols, percentile=99, logger=None):

    mult_log = "col_multiply_log"
    mult_scaled = "col_multiply_scaled"

    df_copy = df[cols]
    df_copy = df_copy.apply(lambda X: zero_to_one(X))
    df_copy["multiply_orig"] = df_copy.prod(axis=1)
    df_copy[mult_log] = df_copy["multiply_orig"].apply(lambda X: np.log10(X))
    df[mult_scaled] = scale_data(
        df_copy, [mult_log], scaler=MinMaxScaler(feature_range=(0, 1))
    )

    logger.info(f"len of df before dropping outliers: {len(df)}")
    logger.info(
        f"len of df after dropping outliers {len(df[df[mult_scaled]< percentile])}"
    )
    return df[df[mult_scaled] < percentile]


def get_null_percentage(df) -> pd.Series:
    return df.isna().sum() / len(df)


def merge_dfs(df_person_params, df_p, df_doc):

    df = df_person_params.merge(
        df_p[["Taz", "docId", "TikId"]],
        how="left",
        left_on=["Taz", "TikId"],
        right_on=["Taz", "TikId"],
    )

    df_doc = df_doc[
        [
            "docId",
            "docDisplayId",
            "docCompositionDate",
            "docReliabilityGrade",
            "docValueGrade",
        ]
    ]
    df = df_doc.merge(
        df,
        how="left",
        right_on=["docId", "asOf"],
        left_on=["docId", "docCompositionDate"],
    )

    return df


def read_input_files(
    metadata_folder,
    doc_md_folder,
    people_in_doc_folder,
    logger=None,
    sep_md="|",
    sep_doc_md="|",
    sep_people="|",
):

    df_doc = drugs_util.read_csv_files_in_folder(doc_md_folder, sep=sep_doc_md)
    df_p = drugs_util.read_csv_files_in_folder(people_in_doc_folder, sep=sep_people)
    df = drugs_util.read_csv_files_in_folder(metadata_folder, sep=sep_md)

    df_doc = df_doc.rename(columns={"Docid": "docId"})
    df_p = df_p.rename(columns={"Tikid": "TikId"})

    df = df.drop_duplicates()
    df = df.rename(columns={"FirstFlyDate": "asOf"})
    try:
        df.asOf = pd.to_datetime(df.asOf, format="%Y-%m-%d")
    except ValueError as e:
        logger.critical(
            f"FirstFlyDate columns in one of the files in {metadata_folder} is not formatted as %Y-%m-%d"
        )

    floats = df.select_dtypes("float").columns
    df[floats] = df[floats].astype("Int64")

    try:
        df_doc.docCompositionDate = pd.to_datetime(
            df_doc.docCompositionDate, format="%Y-%m-%d"
        )
    except ValueError as e:
        logger.critical(
            f"docCompositionDate columns in one of the files in {doc_md_folder} is not formatted as %Y-%m-%d"
        )

    # df_doc['docWordCount'] = df_doc.docText.str.split(' ').apply(lambda x: len(x))

    logger.info(f"Num of columns of metadata (baldarim) df: {len(df.columns)}")
    logger.info(f"Num of columns of document df: {len(df_doc.columns)}")
    logger.info(f"Num of columns of people_in_doc df:{len(df_p.columns)}")

    if (
        (drugs_util.check_baldarim_md_valid(df))
        & (drugs_util.check_doc_md_valid(df_doc))
        & (drugs_util.check_people_in_doc_valid(df_p))
    ):

        return df, df_p, df_doc
    else:
        raise Exception("One of the input files is corrupted")
        return


# Not in use - use clean_data to clean whole dataset
def clean_test_data(df, num_cols, bcols, zero_var_cols, cor_cols):
    # sclae and normalize columns
    if (df[num_cols].values == 0).any():
        df[num_cols] = df[num_cols] + 1
    # log and scale num cols
    df[num_cols] = df[num_cols].apply(np.log)
    df[num_cols] = scale_num_cols(df, num_cols)

    # scale bool cols
    df[bcols] = scale_data(df, bcols, scaler=MinMaxScaler(feature_range=(0, 1)))
    df = df.drop(columns=cor_cols)
    df = df.drop(columns=zero_var_cols)
    df = df.drop(columns={"docReliabilityGrade", "docValueGrade", "docDisplayId"})

    return df


# Not in use - use clean_data to clean whole dataset
def clean_train_data(df, num_cols, bcols, logger):
    # sclae and nomalize columns
    if (df[num_cols].values == 0).any():
        df[num_cols] = df[num_cols] + 1
    # log and scale num cols
    df[num_cols] = df[num_cols].apply(np.log)
    df[num_cols] = scale_num_cols(df, num_cols)

    # scale bool cols
    df[bcols] = scale_data(df, bcols, scaler=MinMaxScaler(feature_range=(0, 1)))

    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))
    df, zero_var_cols = drop_near_zero_var_cols(df, num_cols, 15)
    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))

    df, cor_cols = drop_corr_cols(df, num_cols, logger)
    df = df.drop(columns={"docReliabilityGrade", "docValueGrade", "docDisplayId"})

    return df, zero_var_cols, cor_cols


# sep 2019 clean input data
def clean_data(df_person_params, df_person, df_doc, df_labels, yml_entry, logger):

    # throw away near zero variance
    # categorial variables: throw away or union the rear values
    # categorial variables: if there are many values in category, handle
    # check the numeric cols are normally distributed: skewness, cortosis or check if mean is close to median
    # normalize the numeric values
    # beaning
    # corr between all numeric cols
    # corr between each feature and the label

    scols, bcols, num_cols = get_columns_by_type(df_person_params)
    df = merge_dfs(df_person_params, df_person, df_doc)
    logger.info(f"Num of docs: {len(df)}")

    df = fix_data(df)

    num_cols_per_doc = ["docReliabilityGrade", "docValueGrade"]
    num_cols_person = set(num_cols) - set(num_cols_per_doc)
    d = create_agg_funcs_per_col(bcols, num_cols_person, num_cols_per_doc)
    df_g = df.groupby(["docDisplayId"]).aggregate(d).reset_index()
    logger.debug(f"Len of df_g: {len(df_g)}")
    logger.debug(f"Len of df_g (unique): {df_g.docDisplayId.nunique()}")

    df = df_g.copy()
    df = df.rename(columns={"ID": "numPeopleInDoc"})

    df = df.drop(columns=["docId", "TikId", "TikType"])
    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))
    logger.debug(f"Len of df after merge and gb {len(df)}")

    # sclae and normalize columns
    if (df[num_cols].values == 0).any():
        df[num_cols] = df[num_cols] + 1
    # log and scale num cols
    df[num_cols] = df[num_cols].apply(np.log)

    lag_list = [c for c in df.columns if c.startswith("Lag")]
    outlier_cols = list(set(num_cols) - set(lag_list))
    df = drop_outliers(df, outlier_cols, 0.85, logger)

    df[num_cols] = scale_num_cols(df, num_cols)

    # scale bool cols
    df[bcols] = df[bcols].astype(int)
    # df[bcols] = scale_data(df, bcols, scaler=MinMaxScaler(feature_range=(0, 1)))

    # num_cols = list(set(df.select_dtypes('number').columns).difference(set(bcols)))
    num_cols = list(set(df.select_dtypes("number").columns))

    # df_nz, zero_var_cols = drop_zero_variance_cols(df, num_cols, 0.9)
    df, zero_var_cols = drop_near_zero_var_cols(df, num_cols, frq_cut=15, logger=logger)
    logger.info(f"Len of zero var cols:{zero_var_cols}")
    # zero_var_cols_entry = {'drop_zero_var_cols': zero_var_cols}
    # yml_entry.update(zero_var_cols_entry)
    yml_entry["prod"]["drop_zero_var_cols"] = zero_var_cols

    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))
    df, cor_cols = drop_corr_cols(df, num_cols, logger)
    df = df.drop(columns={"docReliabilityGrade", "docValueGrade"})  # columns not found
    yml_entry["prod"]["drop_corr_cols"] = cor_cols

    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))

    logger.debug(f"boolean cols:{bcols}")
    logger.debug(f"str cols:{scols}")
    logger.debug(f"numeric cols:{num_cols}")

    # This is a manual way to handle categoriacal variables:  agg_less_freq_values and drop them
    # the problem is it is not applicable to future datasets. Solution: use vtreat
    # df = df_prepared
    #
    # df = df.drop(columns=['label'])
    # cols = (df.select_dtypes(include=['int64']).columns.to_list())
    # for col in cols:
    #     df[col] = agg_less_freq_values(df, col, 95)
    # for col in cols:
    #     df = pd.concat([df, pd.get_dummies(df[col], prefix=col)], axis=1).drop(columns=col)
    # print(df.columns)

    ### vtreat - convert categorical vars to *char* categorical vars
    cols = df.select_dtypes(include=["int64"]).columns.to_list()
    for c in cols:
        df[c] = c + df[c].astype(str)

    ### add the label, vtreat must have it
    df_labeled = df.merge(
        df_labels[["docDisplayId", "label"]],
        left_on="docDisplayId",
        right_on="docDisplayId",
        how="inner",
    )

    plan = vtreat.BinomialOutcomeTreatment(
        outcome_name="label",
        outcome_target=1,
        cols_to_copy=["docDisplayId"],
        params=vtreat.vtreat_parameters(
            {
                "filter_to_recommended": False,
                "coders": {"clean_copy", "missing_indicator", "indicator_code"},
                "indicator_min_fraction": 0.1,
                "sparse_indicators": False,
            }
        ),
    )
    df_prepared = plan.fit_transform(df_labeled, df_labeled["label"])
    df_prepared = df_prepared.drop(columns=["label"])

    return df_prepared, yml_entry, plan


def clean_prod_data(
    df_person_params, df_person, df_doc, man_yml_entry, gen_yml_entry, logger=None
):

    # throw away near zero variance
    # categorial variables: throw away or union the rear values
    # categorial variables: if there are many values in category, handle
    # check the numeric cols are normally distributed: skewness, cortosis or check if mean is close to median
    # normalize the numeric values
    # beaning
    # corr between all numeric cols
    # corr between each feature and the label

    trained_model_dir = man_yml_entry["base_dirs"]["trained_model_dir"]["base"]
    trained_model_dir_vtreat = man_yml_entry["base_dirs"]["trained_model_dir"]["vtreat"]
    in_files = gen_yml_entry["prod"]["input_files"]

    zv_cols = gen_yml_entry["prod"]["drop_zero_var_cols"]
    cor_cols = gen_yml_entry["prod"]["drop_corr_cols"]
    vtreat_plan_file = Path(
        trained_model_dir
        + "/"
        + trained_model_dir_vtreat
        + "/"
        + in_files["vtreat_file"]
    )

    infile = open(vtreat_plan_file, "rb")
    vtreat_plan_p = pickle.load(infile)

    scols, bcols, num_cols = get_columns_by_type(df_person_params)
    df = merge_dfs(df_person_params, df_person, df_doc)
    if logger is not None:
        logger.debug(f"len of docs {len(df)}")

    df = fix_data(df)
    num_cols_per_doc = ["docReliabilityGrade", "docValueGrade"]

    num_cols_person = set(num_cols) - set(num_cols_per_doc)
    d = create_agg_funcs_per_col(bcols, num_cols_person, num_cols_per_doc)
    df_g = df.groupby(["docDisplayId"]).aggregate(d).reset_index()
    if logger is not None:
        logger.debug(f"len of df_g: {len(df_g)}")
        logger.debug(f"len of df_g: {df_g.docDisplayId.nunique()}")

    df = df_g.copy()

    df = df.rename(columns={"ID": "numPeopleInDoc"})
    df = df.drop(columns=["docId", "TikId", "TikType"])
    num_cols = list(set(df.select_dtypes("number").columns).difference(set(bcols)))
    if logger is not None:
        logger.debug(f"len of df after merge and gb {len(df)}")

    # sclae and normalize columns
    if (df[num_cols].values == 0).any():
        df[num_cols] = df[num_cols] + 1
    # log and scale num cols
    df[num_cols] = df[num_cols].apply(np.log)

    df[num_cols] = scale_num_cols(df, num_cols)
    df[bcols] = df[bcols].astype(int)

    # num_cols = list(set(df.select_dtypes('number').columns).difference(set(bcols)))
    num_cols = list(set(df.select_dtypes("number").columns))

    zv_cols = list(set(df.columns).intersection(set(zv_cols)))
    cor_cols = list(set(df.columns).intersection(set(cor_cols)))

    df = df.drop(columns=zv_cols)
    if logger is not None:
        logger.info(f"Dropping near_zer_var cols from prod dataset: {zv_cols}")
        logger.info(f"Dropping corr_cols from prod dataset: {cor_cols}")
    df = df.drop(columns=cor_cols)

    cols = df.select_dtypes(include=["int64"]).columns.to_list()
    for c in cols:
        df[c] = c + df[c].astype(str)

    if logger is not None:
        logger.info(
            f"Applying vtreat plan from file:{vtreat_plan_file} to prod dataset"
        )
    df_prepared = vtreat_plan_p.transform(df)
    return df_prepared


def grid_search_cat(
    df_labeled,
    optimize_metric="",
    rounds=1,
    validation=True,
    use_best_model=False,
    best_model_min_trees=1,
):

    df_labeled = df_labeled.drop(columns=["docDisplayId"])

    seed = int(time.clock())
    x_train, y_train, x_test, y_test, msk = split_df(df_labeled, seed=-1, logger=logger)

    class_weight = drugs_util.get_class_weight(y_train)

    clf = CatBoostClassifier(
        iterations=500,
        verbose=10,
        class_weights=[1, class_weight.get(1)],
        early_stopping_rounds=200,
        use_best_model=use_best_model,
        best_model_min_trees=best_model_min_trees,
        eval_metric=optimize_metric,
    )

    grid = {
        "learning_rate": [0.001, 0.01, 0.1],
        "depth": [6, 8, 10],
        "l2_leaf_reg": [6, 10, 15],
    }

    gs_res = clf.grid_search(grid, X=x_train, y=y_train, train_size=0.9, plot=True)
    return gs_res


def run_catBoost(
    x_train,
    y_train,
    iterations=20000,
    max_depth=2,
    learning_rate=0.001,
    class_weights=None,
    loss_function="Logloss",
    l2_leaf_reg=3,
    random_seed=55,
    od_wait=100,
    metric_period=500,
    use_best_model=True,
    validation=True,
):

    clf = CatBoostClassifier(
        iterations=iterations,
        max_depth=max_depth,
        learning_rate=learning_rate,
        class_weights=[1, class_weights],
        loss_function=loss_function,
        l2_leaf_reg=l2_leaf_reg,
        random_seed=random_seed,
        od_wait=od_wait,
        metric_period=metric_period,
        use_best_model=use_best_model,
        verbose=metric_period,
    )

    if validation:
        x_train_t, x_val, y_train_t, y_val = model_selection.train_test_split(
            x_train, y_train, train_size=0.9
        )

        clf.fit(x_train_t, y_train_t, eval_set=[(x_val, y_val)])

    else:
        clf.fit(x_train, y_train)

    return clf


# this function is used to create n basic models, each model
# has optimal threshold. The probability for a production document to be important will be predicted using each of these
# basic models.
# The models are saved as catboost binary models in files
def create_base_models_catboost(
    df_labeled,
    rounds=1,
    validation=True,
    use_best_model=False,
    model_dir=None,
    ts="01_01_1970_0000",
    res_models=None,
    logger=None,
):

    df_probas = df_labeled["docDisplayId"].to_frame()
    df_labeled = df_labeled.drop(columns=["docDisplayId"])

    for rnd in range(rounds):

        logger.info(f"Round {rnd}...")
        logger.info("========================")

        seed = int(time.clock())
        x_train, y_train, x_test, y_test, index_train, index_test = split_df(
            df_labeled, index=df_labeled.index, seed=seed, train_size=0.8, logger=logger
        )

        class_weight = drugs_util.get_class_weight(y_train)
        class_weight_1 = class_weight.get(1)

        clf = run_catBoost(
            x_train,
            y_train,
            iterations=20000,
            max_depth=2,
            learning_rate=0.001,
            class_weights=class_weight_1,
            loss_function="Logloss",
            l2_leaf_reg=3,
            random_seed=55,
            od_wait=100,
            metric_period=500,
            use_best_model=use_best_model,
        )

        # analyze model - debug mode
        # from catboost import Pool
        # train_pool = Pool(data=x_train, label=y_train)
        # clf.get_feature_importance(prettified=True)
        # clf.get_feature_importance(train_pool, 'LossFunctionChange', prettified=True)

        df_probas = run_classifier_predict_proba(
            clf,
            x_train,
            x_test,
            y_test,
            df_probas,
            index_train,
            index_test,
            rnd,
            logger,
        )

        model_file_name = model_dir + "catboost_model_" + ts + "_" + str(rnd)
        clf.save_model(fname=model_file_name, format="cbm")

        cols = ["tn", "fn", "fp", "tp"]
        perf_log_df_models[cols] = perf_log_df_models[cols].astype(int)

        try:
            row = get_optimal_threshold(
                perf_log_df_models[perf_log_df_models["round"] == rnd]
            )
        except:
            continue

        res_models = res_models.append(
            {
                "round": rnd,
                "optimal_threshold": row.threshold.round(2),
                "model_file_name": model_file_name,
                "fn": row.fn,
                "tp": row.tp,
                "fp": row.fp,
                "tn": row.tn,
                "fn/tp": row["fn/tp"],
                "fp/tn": row["fp/tn"],
                "tn/fp": row["tn/fp"],
            },
            ignore_index=True,
        )

    test_cols = []
    for c in x_test.columns:
        test_cols.append(c)
    return df_probas, res_models


def log_formula_best_threshold(row):
    return np.lib.scimath.logn(x=row["tn/fp"], n=row["fp_tn/fn_tp"])


# use a formula to detect the optimal threshold such that we minimize fn and minimize fp
def get_optimal_threshold(df, max_fn_tp_cut=0.18, tn_treshold_factor=0.001):
    # filter out irelevant thresholds
    tn_threshold = len(df) * (tn_treshold_factor)
    msk = (df.fn == 0) & (df.tn < tn_threshold)
    df = df[~msk]

    fn_tp_col = "fn/tp"
    fp_tn_col = "fp/tn"
    tn_fp_col = "tn/fp"

    # to avoid division by zero change fn=0 to 0.1
    df.loc[df.fn == 0, "fn"] = 0.1

    df[fn_tp_col] = df["fn"] / (df["tp"] + df["fn"])
    msk = df[fn_tp_col] <= max_fn_tp_cut
    df = df[msk]

    df[fp_tn_col] = df["fp"] / (df["tn"] + df["fp"])
    df[tn_fp_col] = df["tn"] / (df["tn"] + df["fp"])

    df["fp_tn/fn_tp"] = df[fp_tn_col] / df[fn_tp_col]
    # cols = ['round', 'fn', 'tp', 'fp', 'tn', 'threshold', fn_tp_col, fp_tn_col, tn_fp_col, 'fp_tn/fn_tp']
    # df[cols].head(20)

    # threshold is an increasing series
    # a=fn/fn+tp is increasing series relative to thresholds
    # b=fp/fp+tn is decreasing series relative to thresholds
    # c=tn/fp+tn is increasing series relative to threshold
    # b/a is fast decreasing series

    # for each threshold, take the one with max(tn_fp_col) - this is probably the best fp_tn ratio
    df_g = df.loc[df.groupby(["round", "fn"])[tn_fp_col].idxmax()]
    df_g = df_g.reset_index()

    # [almost] best threshold has max(logn(x='tn/fp'*10, base='fp_tn/fn_tp')
    # multiply df_g[tn_fp_col] by 10 to avoid negative logs
    # May 2020 - this is too complicated. use the simpler solution
    # df_g[tn_fp_col] = df_g[tn_fp_col]*10
    # df_g['final'] = df_g.apply(log_formula_best_threshold, axis=1)
    # mx_row = df_g.loc[df_g.groupby(['round'])['final'].idxmax()]

    df_g = df_g[df_g["fp_tn/fn_tp"] >= 1]
    opt_row = df_g.loc[df_g.groupby(["round"])["fp_tn/fn_tp"].idxmin()]

    return opt_row[
        ["threshold", fn_tp_col, fp_tn_col, tn_fp_col, "fn", "tp", "fp", "tn"]
    ].iloc[0]


###*************************************************************************************
###*************************************************************************************
###*************************************************************************************
###*************************************************************************************
###*************************************************************************************
###*************************************************************************************
###*************************************************************************************
def main(man_yml_file, gen_yml_file):

    # man_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_manual.yml'
    # gen_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_generated.yml'
    # __file__ = '_xxx_'

    man_yml = yaml.safe_load(open(man_yml_file))
    gen_yml = yaml.safe_load(open(gen_yml_file))

    # config_filepath='/home/e015976541/projects/drugs_trafficking/src/drugs_test.yml'
    # config_file = 'new_yml.yml'
    # config_filepath = str(drugs_home_dir / config_file)
    # cf = open(config_filepath)
    # curr_yml = yaml.safe_load(cf)

    in_files = man_yml["input_folders"]["training"]
    dirs = man_yml["base_dirs"]

    base_dir = dirs["base1"]
    trained_models_dir = dirs["trained_model_dir"]["base"]
    trained_models_dir_catboost = (
        trained_models_dir + "/" + dirs["trained_model_dir"]["catboost"]
    )
    trained_models_dir_vtreat = (
        trained_models_dir + "/" + dirs["trained_model_dir"]["vtreat"]
    )

    logs_dir = dirs["log_dir"]

    ts = drugs_util.get_timestamp()

    _file_name = Path(__file__).name
    logfile_name = f"{_file_name}_{ts}.log"
    logger = fc_logging.set_logger(
        name=__name__,
        log_level=logging.INFO,
        log_path=str(logs_dir),
        logfile_name=logfile_name,
    )

    logger.info(f"Log file is written to: {logs_dir}/{logfile_name}")

    logger.info(f"Now running {_file_name} with yaml files:")
    logger.debug(man_yml_file)
    logger.debug(gen_yml_file)

    expert_file = Path(base_dir + "/" + in_files["expert_decision_file"])
    metadata_folder = Path(base_dir + "/" + in_files["baldarim_meta_data"])
    doc_md_folder = Path(base_dir + "/" + in_files["doc_metadata"])
    people_in_doc_folder = Path(base_dir + "/" + in_files["people_in_doc"])

    cnn_proba_file = gen_yml["drugs_metadata_create_models"]["cnn_proba_file"]

    logger.info(f"Training catboost models using labeled file: {expert_file}")
    logger.info(
        f"Adding probability generated by cnn model from file: {cnn_proba_file}"
    )

    global perf_log_df_models
    header_perf_log = [
        "classifier",
        "auc",
        "f1_score",
        "tp",
        "fn",
        "fp",
        "tn",
        "threshold",
        "round",
        "remark",
        "date",
        "clf_params",
    ]

    df_labeled = drugs_util.get_label_file(expert_labeled_folder=expert_file)
    df_cnn_proba = pd.read_csv(
        Path(base_dir + "/raw/training/models_results/" + cnn_proba_file), sep="|"
    )

    logger.info(
        f"Reading input files from directories: {metadata_folder}, {doc_md_folder}, {people_in_doc_folder}..."
    )
    try:
        df_person_params, df_person, df_doc = read_input_files(
            metadata_folder=metadata_folder,
            doc_md_folder=doc_md_folder,
            people_in_doc_folder=people_in_doc_folder,
            logger=logger,
        )

    except Exception as e:
        logger.critical(e)
        exit()

    logger.info(f"Cleaning data...")
    df, new_yml, vtreat_plan = clean_data(
        df_person_params=df_person_params,
        df_person=df_person,
        df_doc=df_doc,
        df_labels=df_labeled,
        yml_entry=gen_yml,
        logger=logger,
    )

    vtreat_plan_file = Path(trained_models_dir_vtreat + "/vtreat_plan_" + ts)
    sf = vtreat_plan.score_frame_
    outfile = open(vtreat_plan_file, "wb")
    pickle.dump(vtreat_plan, outfile)

    logger.info(f"Exported vtreat_plan to {vtreat_plan_file}")
    new_yml["prod"]["input_files"]["vtreat_file"] = vtreat_plan_file.name

    df = df.merge(
        df_cnn_proba[["docDisplayId", "proba"]],
        left_on="docDisplayId",
        right_on="docDisplayId",
        how="left",
    )

    # qa_list = ['18-2180-419', '14-0292-795', '17-0246-196', '16-0042-866', '16-0175-804', '16-0185-724', '16-0201-307',
    #            '16-0204-924', '17-0197-793', '17-0212-553']
    # qa_msk = df['docDisplayId'].isin(qa_list)
    # df = df[~qa_msk]
    # len(df)

    df_labeled = df.merge(
        df_labeled[["docDisplayId", "label"]],
        left_on="docDisplayId",
        right_on="docDisplayId",
        how="inner",
    )

    logger.debug(len(df_labeled))

    perf_log_df_models = pd.DataFrame(columns=header_perf_log)
    rounds = man_yml["drugs_metadata_create_models"]["rounds"]
    logger.info(f"Training {rounds} catboost models...")
    header_models = [
        "round",
        "model_file_name",
        "optimal_threshold",
        "tn/fp",
        "fn/tp",
        "fp/tn",
        "fn",
        "tp",
        "fp",
        "tn",
    ]
    models = pd.DataFrame(columns=header_models)

    probas, models = create_base_models_catboost(
        df_labeled,
        rounds=rounds,
        use_best_model=True,
        validation=True,
        model_dir=trained_models_dir,
        res_models=models,
        logger=logger,
    )
    #************************
    ## Start filter
    perf_log_df_models["threshold"] = (
        perf_log_df_models["threshold"].astype(float).round(2)
    )

    # choose best models
    msk = models["fn/tp"] <= 0.16
    best_models = models[msk]

    msk = best_models["tn/fp"] >= 0.45
    best_models = best_models[msk]

    prefix = ts + "_r" + str(rounds) + ".csv"
    log_file = base_dir + "/PerfLog_" + prefix
    logger.info(f"Exporting performance_log to {perf_log_df_models}")
    perf_log_df_models.to_csv(
        log_file, sep="|", columns=header_perf_log, index=False, header=header_perf_log
    )

    catboost_models_file = Path(trained_models_dir_catboost + "/models_" + prefix)
    logger.info(f"Exporting models df to file: {catboost_models_file}")
    models.to_csv(
        catboost_models_file,
        sep="|",
        columns=models.columns,
        index=False,
        header=models.columns,
    )

    best_catboost_models_file = Path(
        trained_models_dir_catboost + "/best_models_" + prefix
    )
    logger.info(f"Exporting best models df to file: {best_catboost_models_file}")
    best_models.to_csv(
        best_catboost_models_file,
        sep="|",
        columns=best_models.columns,
        index=False,
        header=best_models.columns,
    )

    new_yml["prod"]["input_files"]["catboost_models_file"] = catboost_models_file.name
    new_yml["prod"]["input_files"][
        "catboost_best_models_file"
    ] = best_catboost_models_file.name

    new_gen_yml_file = gen_yml_file
    with open(new_gen_yml_file, "w") as new_yml_file:
        yaml.dump(gen_yml, new_yml_file)

    train_proba = Path(trained_models_dir_catboost + "/train_proba" + prefix)
    logger.info(f"Exporting probabilities from base models to {train_proba}")
    probas.to_csv(train_proba, index=False)


if __name__ == "__main__":
    # config_file = main('/home/e015976541/projects/drugs_trafficking/src/drugs_params.yml')
    main(
        "/home/e038269676/projects/drugs_trafficking/src/configs/drugs_params_manual.yml",
        "/home/e038269676/projects/drugs_trafficking/src/configs/drugs_params_generated.yml",
    )
