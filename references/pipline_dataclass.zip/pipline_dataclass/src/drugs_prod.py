import warnings
import logging

warnings.simplefilter(action="ignore", category=Warning)

import pandas as pd
import ruamel.yaml as yaml
from catboost import CatBoostClassifier
import numpy as np
import datetime
import time
from sklearn import model_selection
import sys
import os
from pathlib import Path
from keras.models import model_from_json
from keras.preprocessing import text
import json
import pickle
from keras.models import load_model
from gensim.models import FastText as FT
from numpy import loadtxt

perf_log_df_cnn = None
models = None

path_home = Path(sys.path[-1]).home()
fcutils_path = path_home / "projects/fcutils"
sys.path.append(str(fcutils_path))

drugs_home_dir = path_home / "projects/drugs_trafficking/src"
sys.path.append(str(drugs_home_dir))

from src import drugs_metadata_create_models as cm
from src import proba_from_text
from src import drugs_util
from src import drugs_text

from fcutils import fc_logging


def get_negative_voting(models, probas, rounds, vote_col_name):

    probas[vote_col_name] = 0
    for rnd in range(0, rounds):
        c = probas.columns[rnd + 1]
        threshold = models.iloc[rnd]["optimal_threshold"].astype(float)
        vmsk = probas[c] < threshold
        probas.loc[vmsk, vote_col_name] = probas[vmsk][vote_col_name] + 1
    return probas


def get_positive_voting(models, probas, rounds, vote_col_name):

    probas[vote_col_name] = 0
    for rnd in range(0, rounds):
        threshold = models.iloc[rnd]["optimal_threshold"].astype(float)
        c = probas.columns[rnd + 1]
        vmsk = probas[c] >= threshold
        probas.loc[vmsk, vote_col_name] = probas[vmsk][vote_col_name] + 1
    return probas


def get_final_label(models, probas, rounds):

    probas["mean_proba"] = probas[probas.columns[1:]].mean(axis="columns")
    probas["median_proba"] = probas[probas.columns[1:]].median(axis="columns")

    # # gila todo this is only for checking - should be removed in prod
    # file_l = r'/home/e015976541/projects/drugs_trafficking/data/raw/expert_decision_feb_20.xlsx'
    # df_labeled = pd.read_excel(file_l)
    #
    # df_labeled = df_labeled[[df_labeled.columns[0], df_labeled.columns[1], df_labeled.columns[3],
    #                          df_labeled.columns[6]]]
    # df_labeled = df_labeled.rename(columns={df_labeled.columns[3]: 'label', df_labeled.columns[2]: 'remarks'})
    # df_labeled = df_labeled[~df_labeled.label.isna()]
    #
    # msk = df_labeled.label.str.strip().str.contains('?', regex=False, na=False)
    # df_labeled = df_labeled.mask(cond=msk, other='0')
    # probas = probas.merge(df_labeled, right_on='docDisplayId', left_on='docDisplayId',  how='inner')

    # end remove

    pos_vot_col_name = "#voted_yes"
    neg_vot_col_name = "#voted_no"
    final_label = "final_label"
    majority = np.floor(rounds / 2)

    probas = get_positive_voting(models, probas, rounds, pos_vot_col_name)
    probas = get_negative_voting(models, probas, rounds, neg_vot_col_name)
    probas[final_label] = 2

    msk = (probas[pos_vot_col_name] >= probas[neg_vot_col_name]) & (
        probas.final_label == 2
    )
    # print(msk.sum())
    probas.loc[msk, final_label] = 1

    msk = (probas[neg_vot_col_name] > probas[pos_vot_col_name]) & (
        probas.final_label == 2
    )
    # print(msk.sum())
    probas.loc[msk, final_label] = 0

    # msk = (probas[final_label] == 1) & (probas.label == 0) #& (probas.median_proba >= t_tn_2)
    # print('fp')
    # print('====')
    # print(len(probas[msk]))
    #
    # print('fn')
    # print('====')
    # msk = (probas[final_label] == 0) & (probas.label == 1)#  & (probas.median_proba<=t_fn2)
    # print(len(probas[msk]))
    #
    # print('tn')
    # print('====')
    # msk = ((probas[final_label] ==0) & (probas.label == 0))
    # print(len(probas[msk]))
    #
    # print('tp')
    # print('====')
    # msk = (probas[pos_vot_col_name] >= 15) & (probas.label == 1)  # & (probas.median_p <=t_fn_2)
    # print(len(probas[msk]))

    return probas


def get_proba_from_nn(trained_model_dir, yml_entry, doc_texts, logger):
    # load a tokenizer trained on ~5000 doc files and a cnn model trained on the same dataset
    # predict the probabity of the new docs based on the cnn and tokenizer
    cnn_model_filename = Path(trained_model_dir + "/" + yml_entry["cnn_model_file"])
    tokenizer_file_name = Path(trained_model_dir + "/" + yml_entry["tokenizer_file"])
    logger.info(f"using tokenizer from: {tokenizer_file_name}")
    logger.info(f"getting probas from model:{cnn_model_filename}")

    tokenizer_file = open(tokenizer_file_name, "r")
    tokenizer_json = json.loads(tokenizer_file.read())
    prod_tokenizer = text.tokenizer_from_json(tokenizer_json)

    cnn_prod_model = load_model(cnn_model_filename)
    prod_clean_texts = drugs_text.clean_yediot(text_list=doc_texts)

    prod_sequnces = proba_from_text.get_padded_sequence_from_text(
        prod_tokenizer, prod_clean_texts, proba_from_text.MAX_SEQUENCE_LENGTH
    )
    cnn_proba_prod = cnn_prod_model.predict(prod_sequnces)
    return cnn_proba_prod, cnn_prod_model


def proba_from_file(cnn_proba_file, df):
    df_cnn_proba = pd.read_csv(cnn_proba_file, sep="|")
    df = df.merge(
        df_cnn_proba[["docDisplayId", "proba_from_file"]],
        left_on="docDisplayId",
        right_on="docDisplayId",
        how="left",
    )
    return df


############################################################
############################################################
############################################################
############################################################
############################################################

<<<<<<< HEAD
=======
def main(man_yml_file, gen_yml_file):

    # man_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_manual.yml'
    # gen_yml_file = r'/home/e015976541/projects/drugs_trafficking/src/drugs_params_generated.yml'
    # __file__ = 'xx'
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

def main(man_yml_file, gen_yml_file):

    man_yml = yaml.safe_load(open(man_yml_file))
    gen_yml = yaml.safe_load(open(gen_yml_file))

<<<<<<< HEAD
    dirs = man_yml["base_dirs"]
    in_files = man_yml["input_folders"]["prod"]
    model_files = gen_yml["prod"]["input_files"]

    base_dir = dirs["base1"]
    trained_model_dir = dirs["trained_model_dir"]
    logs_dir = dirs["log_dir"]
=======
    dirs = man_yml['base_dirs']
    in_files = man_yml['input_folders']['prod']
    seps = man_yml['sep']['prod']
    model_files = gen_yml['prod']['input_files']

    base_dir = dirs['base1']
    trained_models_dir = dirs['trained_model_dir']['base']
    trained_models_dir_catboost = trained_models_dir + '/' + dirs['trained_model_dir']['catboost']
    trained_models_dir_cnn = trained_models_dir + '/' + dirs['trained_model_dir']['cnn']

    logs_dir = dirs['log_dir']
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

    ts = drugs_util.get_timestamp()
    ts
    _file_name = Path(__file__).name
    logfile_name = f"{_file_name}_{ts}.log"
    logger = fc_logging.set_logger(
        name=__name__,
        log_level=logging.INFO,
        log_path=str(logs_dir),
<<<<<<< HEAD
        logfile_name=logfile_name,
    )

    logger.info(f"Log file is written to: {logs_dir}/{logfile_name}")

    logger.info(f"Now running {_file_name} with yaml files:")
    logger.debug(man_yml_file)
    logger.debug(gen_yml_file)

    prod_meta_data_folder = Path(base_dir + "/" + in_files["baldarim_meta_data"])
    prod_doc_folder = Path(base_dir + "/" + in_files["doc_metadata"])
    prod_people_folder = Path(base_dir + "/" + in_files["people_in_doc"])
    logger.info(
        f"Reading input files from directories: {prod_doc_folder}, {prod_meta_data_folder}, {prod_people_folder}"
    )

    best_models_file_name = Path(
        trained_model_dir + "/" + model_files["catboost_best_models_file"]
    )
    catboost_models_file_name = Path(
        trained_model_dir + "/" + model_files["catboost_models_file"]
    )
    logger.info(
        f"Using pre_trained catboost models from file: {catboost_models_file_name}"
    )

    cnn_model_file = model_files["cnn_model_file"]

    try:
        df_person_params, df_person, df_doc = cm.read_input_files(
            metadata_folder=prod_meta_data_folder,
            doc_md_folder=prod_doc_folder,
            people_in_doc_folder=prod_people_folder,
            logger=logger,
        )
=======
        logfile_name=logfile_name)

    logger.info(f'Log file is written to: {logs_dir}/{logfile_name}')

    logger.info(f'Now running {_file_name} with yaml files:')
    logger.info(man_yml_file)
    logger.info(gen_yml_file)

    prod_meta_data_folder = Path(base_dir + '/' + in_files['baldarim_meta_data'])
    prod_doc_folder = Path(base_dir + '/' + in_files['doc_metadata'])
    prod_people_folder = Path(base_dir + '/' + in_files['people_in_doc'])
    md_sep = seps['baldarim_meta_data_sep']
    md_doc_sep = seps['doc_metadata_sep']
    people_sep = seps['people_in_doc_sep']

    logger.info(f'Reading input files from directories: {prod_doc_folder}, {prod_meta_data_folder}, {prod_people_folder}')

    best_models_file_name = Path(trained_models_dir_catboost + '/' + model_files['catboost_best_models_file'])
    catboost_models_file_name = Path(trained_models_dir_catboost + '/' + model_files['catboost_models_file'])
    logger.info(f'Using pre_trained catboost models from file: {catboost_models_file_name}')

    cnn_model_file = model_files['cnn_model_file']


    try:
        df_person_params, df_person, df_docs = cm.read_input_files(metadata_folder=prod_meta_data_folder,
                                                                  doc_md_folder=prod_doc_folder,
                                                                  people_in_doc_folder=prod_people_folder,
                                                                  logger=logger,
                                                                  sep_md=md_sep,
                                                                  sep_doc_md=md_doc_sep,
                                                                  sep_people=people_sep)
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

    except Exception as e:
        logger.critical(e)
        exit()

<<<<<<< HEAD
    df_prod = cm.clean_prod_data(
        df_person_params=df_person_params,
        df_person=df_person,
        df_doc=df_doc,
        yml_entry=gen_yml,
    )
=======


    df_prod = cm.clean_prod_data(df_person_params=df_person_params, df_person=df_person, df_doc=df_docs,
                                 man_yml_entry=man_yml,
                                 gen_yml_entry=gen_yml)
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

    # # todo remove in prod
    # # in prod version there is not need for this - read the texts directly from a file
    # # cnn_proba_file = gen_yml['drugs_metadata_create_models']['cnn_proba_file']
    # df_labeled_prod = drugs_util.get_label_file(expert_labeled_file=r'/home/e015976541/projects/drugs_trafficking/data/raw/training/expert_decision_june_20.xlsx')
    # print(f'len of records labled {len(df_labeled_prod)}')
    # df_prod_with_text = df_prod.merge(df_labeled_prod[['docDisplayId', 'docText']], right_on='docDisplayId', left_on='docDisplayId')
    #
    # # seed = int(time.process_time())
    # # x_, x_prod, index_, index_prod = model_selection.train_test_split(df_prod,
    # #                                                                 df_prod.index,
    # #                                                                 train_size=0.1,random_state=seed)
    # # todo remove qa
    #
    # # qa_list = ['18-2180-419', '14-0292-795', '17-0246-196',
    # #          '16-0042-866', '16-0175-804', '16-0185-724',
    # #          '16-0201-307', '16-0204-924', '17-0197-793',
    # #          '17-0212-553', '15-0071-716','17-0187-959', '17-0193-698']
    # #
    # # qa_msk = df_prod['docDisplayId'].isin(qa_list)
    # # x_prod = df_prod[qa_msk]
    # # todo end remove qa
    # #cnn_proba_file = '/home/e015976541/projects/drugs_trafficking/data/df_with_proba_from_cnn_07-06-20.csv'

    # project x_prod on x_prod_with_text
    # todo END QA

<<<<<<< HEAD
    # create the probablity for the new docs from cnn model and add to the dataset
    df_doc = df_doc[["docDisplayId", "docText"]]
    doc_texts = df_doc["docText"]
    nn_proba, model = get_proba_from_nn(
        trained_model_dir, model_files, doc_texts, logger
    )
    df_doc["proba"] = nn_proba[:, 1]

    # add a new column to the dataset with the probabilty to be important
    df_prod = df_prod.merge(
        df_doc[["proba", "docDisplayId"]],
        right_on="docDisplayId",
        left_on="docDisplayId",
    )
=======
    # create the probability for the new docs from cnn model and add to the dataset
    df_docs = df_docs[['docDisplayId', 'docText']]
    doc_texts = df_docs['docText']
    nn_proba, model = get_proba_from_nn(trained_model_dir=trained_models_dir_cnn,
                                        yml_entry=model_files,
                                        doc_texts=doc_texts,
                                        logger=logger)
    df_docs['proba'] = nn_proba[:, 1]

    # add a new column to the dataset with the probability to be important
    df_prod = df_prod.merge(df_docs[['proba', 'docDisplayId']], right_on='docDisplayId', left_on='docDisplayId')
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

    df_for_catboost = df_prod.drop(columns=["docDisplayId"])
    logger.info(df_prod.columns)

    all_models = pd.read_csv(catboost_models_file_name, sep="|")
    best_models = pd.read_csv(best_models_file_name, sep="|")
    models = all_models

<<<<<<< HEAD
    df_probas = df_prod["docDisplayId"].to_frame()
    logger.info(f"Running {len(models)} models...")
=======
    df_docs_to_predict = df_prod['docDisplayId'].to_frame()
    logger.info(f'Running {len(models)} models...')
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb
    for rnd in range(len(models)):
        fname = models.iloc[rnd]["model_file_name"]

        from_file = CatBoostClassifier()
        clf = from_file.load_model(fname)

        prediction = clf.predict_proba(df_for_catboost)
<<<<<<< HEAD
        col_name = "proba" + str(rnd)
        df_doc[col_name] = prediction[:, 1]

    df_probas = df_probas.merge(df_doc, right_on="docDisplayId", left_on="docDisplayId")

    df_probas_res = df_probas.drop(columns=["docText"])
    voting_df = get_final_label(models, df_probas_res, len(models))

    df_probas_res = df_probas_res.merge(
        df_probas[["docDisplayId", "docText"]],
        right_on="docDisplayId",
        left_on="docDisplayId",
    )

    ts = drugs_util.get_timestamp()

    probas_res_file = Path(base_dir + "/voting_with_text_" + ts + ".csv")
    df_probas_res.to_csv(probas_res_file, sep="|", index=False)

    voting_file = Path(base_dir + "/voting_no_text_" + ts + ".csv")
    voting_df.to_csv(voting_file, index=False, sep="|")

    logger.info(f"Exporting final labels with texts to: {probas_res_file}")
    logger.info(f"Exporting the final labels (no texts) to: {voting_file}")

    gen_yml["prod"]["output"]["probas"] = probas_res_file._str
    gen_yml["prod"]["output"]["voting"] = voting_file._str
=======
        col_name = 'proba' + str(rnd)
        df_docs[col_name] = prediction[:, 1]

    # df_probas = df_probas.merge(df_doc, right_on='docDisplayId', left_on='docDisplayId')
    # df_probas.columns
    #df_probas_res = df_probas.drop(columns=['docText'])

    df_docs_to_predict = df_docs_to_predict.merge(df_docs, right_on='docDisplayId', left_on='docDisplayId')
    df_docs_to_predict = df_docs_to_predict.drop(columns=['docText'])
    voting_df = get_final_label(models, df_docs_to_predict, len(models))
    voting_df_with_text = voting_df.merge(df_docs[['docDisplayId', 'docText']], right_on='docDisplayId', left_on='docDisplayId')

    ts = drugs_util.get_timestamp()

    res_dir = man_yml['base_dirs']['prediction_results_dir']
    labeled_file = Path(res_dir + '/voting_' + ts + '.csv')
    voting_df_with_text.to_csv(labeled_file, index=False, sep = '|')

    logger.info(f'Exporting final labels to: {labeled_file}')
    gen_yml['prod']['output']['voting'] = labeled_file._str
>>>>>>> dfe7eadbeacb5f3c18beafebdb927e58fd66f2bb

    new_gen_yml_file = gen_yml_file
    with open(new_gen_yml_file, "w") as new_yml_file:
        yaml.dump(gen_yml, new_yml_file)


if __name__ == "__main__":
    main(
        "/home/e015976541/projects/drugs_trafficking/src/drugs_params_manual.yml",
        "/home/e015976541/projects/drugs_trafficking/src/drugs_params_generated.yml",
    )
