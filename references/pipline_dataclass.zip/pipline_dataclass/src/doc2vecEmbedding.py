import warnings

warnings.simplefilter(action="ignore", category=Warning)

import pandas as pd
import numpy as np
import datetime
import collections
from itertools import compress

from gensim.models import FastText as FT
from gensim.models import doc2vec
import matplotlib.pyplot as plt


from keras.utils import to_categorical
from sklearn import model_selection
from sklearn.model_selection import GridSearchCV

from sklearn import svm as svm
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold
from sklearn.decomposition import PCA
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import SGDClassifier

from imblearn.over_sampling import SMOTE, ADASYN

from gensim.utils import simple_preprocess

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

from pathlib import Path
import sys

path_home = Path(sys.path[-1]).home()
# cur_path = path_home/"drugs_trafficking/src"
cur_path = "/home/e015976541/projects/drugs_trafficking/src"
sys.path.append(str(cur_path))

import drugs_util
import drugs_text as t


log_cols = [
    "model_config",
    "model_params",
    "history_acc",
    "history_val_acc",
    "f1score",
    "auc",
    "conf_mat",
    "tn",
    "fp",
    "fn",
    "tp",
    "remark",
    "date",
]
perf_log_name = r"/home/e015976541/projects/drugs_trafficking/data/doc2VecPerfLog.csv"
global perf_log_df_cnn

MAX_SEQUENCE_LENGTH = 150
EMBEDDING_DIM = 50
PCA_DIM = 50

DEBUG = 1


def get_train_test_sets(crps, label_col):

    msk = np.random.rand(len(crps)) >= 0.2
    x_train = list(compress(crps, msk))
    x_test = list(compress(crps, ~msk))

    y_train = label_col[msk].astype("int").values
    y_test = label_col[~msk].astype("int").values

    y_train_cat = to_categorical(y_train, 2)
    y_test_cat = to_categorical(y_test, 2)

    return x_train, y_train, x_test, y_test, y_train_cat, y_test_cat


def doc2vec_corpus(corpus):
    i = 0
    for d in corpus:
        yield doc2vec.TaggedDocument(d, [i])
        i = i + 1


def grid_search(models, params, X, Y):
    best_models = []

    for i in range(0, len(params)):
        print(f"Running model: {models[i].__class__}\n")
        m = GridSearchCV(models[i], params[i], cv=5, verbose=1, n_jobs=25)
        print(f"Best params found were: {m.get_params()}\n")
        m.fit(X, Y)
        best_models.append(m.best_estimator_)
    return best_models


def to_doc_2_vec(clean_texts):
    crps = list(doc2vec_corpus(clean_texts))
    # type(crps)
    # print(crps[:2])

    model = doc2vec.Doc2Vec(vector_size=EMBEDDING_DIM, min_count=2, epochs=40)
    model.build_vocab(crps)

    # sanity checks
    voc = model.wv.vocab
    voc["בלדר"].count
    voc["עיסאם"].count

    model.train(crps, total_examples=len(crps), epochs=model.epochs)

    # v1 is a vector for the sentence
    v1 = model.infer_vector(
        ["סלולר", "בלדרים", "באמצעות", "מצריים", "גבול", "ייבוא", "קריסטל", "חשיש"]
    )

    # transform docs to vecs
    crps_vecs = []
    for d in crps:
        crps_vecs.append(model.infer_vector(d.words))

    # sanity check
    sims = model.docvecs.most_similar([crps_vecs[1]], topn=10)
    return crps_vecs


# ***************************************************************************************
# ***************************************************************************************
# ***************************************************************************************
# ***************************************************************************************# ***************************************************************************************


def main():

    df = drugs_util.get_label_file()
    label = "label"
    doc_text = "docText"
    clean_texts = t.clean_yediot(df[doc_text])

    crps_vecs = to_doc_2_vec(clean_texts)

    x_train, y_train, x_test, y_test, y_train_cat, y_test_cat = get_train_test_sets(
        crps_vecs, df[label]
    )

    # x_train = x_train_orig
    # y_train = y_train_orig

    x_train, y_train, x_train_orig, y_train_orig = drugs_util.smote_adasyn(
        x_train, y_train
    )

    if DEBUG:
        print(len(x_train))
        print(len(x_test))

    # todo take care of class_weight
    class_weight = drugs_util.get_class_weight(y_train)
    print(class_weight)

    pca = PCA(n_components=10)
    pca.fit(x_train)
    pca.fit(x_test)
    x_train = pca.transform(x_train)
    x_test = pca.transform(x_test)

    classifiers = []
    params = []

    # mlp = MLPClassifier()
    sgd = SGDClassifier(loss="log")
    # svc = svm.SVC()
    rf = RandomForestClassifier()

    rf_params = {"n_estimators": [50, 100, 200], "max_depth": [10, 20, 30, 50]}
    sgd_params = {
        "loss": ["log", "squared_loss", "huber"],
        "max_iter": [100, 150],
        "penalty": ["l2", "l1"],
        #'class_weight': [class_weight],
        "early_stopping": [True, False],
    }

    svc_parms = {
        "kernel": ["linear", "rbf"],
        "C": [3, 5, 15, 20],
        #'class_weight':[class_weight],
        "gamma": ["scale"],
    }

    mlp_params = {
        "max_iter": [100, 200, 300],
        "hidden_layer_sizes": [(50, 3), (100, 5)],
        "learning_rate": ["constant", "adaptive"],
    }

    classifiers.append(sgd)
    params.append(sgd_params)

    classifiers.append(svc)
    params.append(svc_parms)

    classifiers.append(mlp)
    params.append(mlp_params)

    best_models = grid_search(classifiers, params, x_train, y_train)

    show_results(best_models[0].predict(x_test), y_test)
    show_results(best_models[1].predict(x_test), y_test)
    show_results(best_models[2].predict(x_test), y_test)

    best_models[2].get_params()

    voting = VotingClassifier(
        estimators=[
            ("sgd", best_models[0]),
            ("svc", best_models[1]),
            ("mlp", best_models[2]),
        ],
        voting="hard",
    )

    voting.fit(x_train, y_train)
    p = voting.predict(x_test)
    show_results(p, y_test)

    clf = BaggingClassifier(
        base_estimator=SVC(class_weight=class_weight, kernel="linear"),
        n_estimators=10,
        max_samples=0.65,
        bootstrap=True,
    )
    # clf= BaggingClassifier(RandomForestClassifier(class_weight=class_weight), n_estimators=15, max_samples=0.95, bootstrap=False)
    clf.fit(x_train, y_train)
    p = clf.predict(x_test)
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(conf_mat)
    print(auc)
    print(f1_score)

    params = {
        "kernel": ("linear", "rbf"),
        "C": [0.5, 1, 2],
        "class_weight": [class_weight],
    }
    svc = svm.SVC()
    clf = GridSearchCV(svc, params, cv=5)
    clf.fit(x_train, y_train)
    clf.get_params()
    p = clf.predict(x_test)
    show_results(p, y_test)
    print(conf_mat)
    print(auc)
    print(f1_score)
    seed = 12
    kfold = model_selection.KFold(n_splits=3, random_state=seed)

    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    score = model_selection.cross_validate(clf, x_train, y_train, cv=kfold)
    p = model_selection.cross_val_predict(clf, X=x_test, y=None, cv=kfold)
    print(res.mean())

    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")

    clf = SVC(class_weight=class_weight, kernel="linear")
    clf.fit(x_train, y_train)
    p = clf.predict(x_test)
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")

    mlp = MLPClassifier(hidden_layer_sizes=(3, 3))
    mlp.fit(x_train, y_train)
    p = mlp.predict(x_test)
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")

    clf = RandomForestClassifier(class_weight=class_weight)
    clf.fit(x_train, y_train)
    p = clf.predict(x_test)
    auc, f1_score, conf_mat = drugs_util.metrics(y_test, p)
    print(f"auc: {auc}")
    print(f"f1: {f1_score}")
    print(f"con_mat: {conf_mat}")

    pca = PCA(n_components=2)
    pca.fit(x_test)
    vecs_pca = pca.transform(x_test)

    one = list(compress(vecs_pca, y_test))
    one = [list(x) for x in one]
    zero = list(compress(vecs_pca, 1 - y_test))
    one[0, :]

    plt.clf()
    a = [x[0] for x in one]
    b = [x[1] for x in one]
    plt.scatter(a, b, color="b")

    a = [x[0] for x in zero]
    b = [x[1] for x in zero]
    plt.scatter(a, b, color="r")
