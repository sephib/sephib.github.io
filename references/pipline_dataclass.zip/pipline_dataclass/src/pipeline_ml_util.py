import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class DataframeFunctionTransformer:
    def __init__(self, func):
        self.func = func

    def fit(self, X, y=None, **fit_params):
        return self

    def transform(self, X, **transform_params):
        return self.func(X)


class CustomTransformer(BaseEstimator, TransformerMixin):
    """
    a general class for creating a machine learning step in the machine learning pipeline
    """

    def __init__(self):
        """
        constructor
        """
        super(CustomTransformer, self).__init__()

    def fit(self, X, y=None, **kwargs):
        """
        an abstract method that is used to fit the step and to learn by examples
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: self: the class object - an instance of the transformer - Transformer
        """
        pass

    def transform(self, X, y=None, **kwargs):
        """
        an abstract method that is used to transform according to what happend in the fit method
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: X: the transformed data - Dataframe
        """
        pass

    def fit_transform(self, X, y=None, **kwargs):
        """
        perform fit and transform over the data
        :param X: features - Dataframe
        :param y: target vector - Series
        :param kwargs: free parameters - dictionary
        :return: X: the transformed data - Dataframe
        """
        self = self.fit(X, y)
        return self.transform(X, y)


class BaldarimPreprocessor(CustomTransformer):
    def __init__(self):
        self.feature_names = []

    def _get_df_missing_values(df: pd.DataFrame) -> pd.DataFrame:
        total = df.isnull().sum().sort_values(ascending=False)
        percent = (df.isnull().sum() / df.isnull().count()).sort_values(ascending=False)
        df_features_missing_data = pd.concat(
            [total, percent], axis=1, keys=["Total", "Percent"]
        )
        df_features_missing_data = df_features_missing_data[
            df_features_missing_data["Total"] > 0
        ]
        df_features_missing_data = df_features_missing_data.join(
            df.dtypes.to_frame(name="type"), how="left",
        )
        return df_features_missing_data

    def _drop_cols_witn_missing_values_threshold(
        self, df, missing_values_threshold_percent=0.8
    ):
        df_missing_values = _get_df_missing_values(df)
        cols_to_drop = df_missing_values[
            df_missing_values.Percent > missing_values_threshold_percent
        ].index.to_list()
        df = df.drop(cols_to_drop, axis=1)
        return df

    # def _replace_vals_from_num_columns

    def transform(self, X, *args):
        X = self._drop_cols_with_missing_values_threshold(x)
        self.feature_names = X.columns
        return X

    def fit(self, X, *args):
        return self


if __name__ == "__main__":
    pass
