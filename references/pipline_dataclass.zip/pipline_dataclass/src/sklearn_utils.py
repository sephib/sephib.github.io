from sklearn.metrics import make_scorer
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)

import src.plot_funcs as pf

import pandas as pd
import numpy as np
from typing import Any

from dataclasses import dataclass

import sklearn.metrics as metric
from collections import namedtuple

conf_mat = namedtuple("conf_mat", "tn,fp,fn,tp")


def get_metrics(p, y_test):
    auc, f1_score, conf_mat = metrics(y_test, p)
    return auc, f1_score, conf_mat


def metrics(y_test, prediction):
    f1score = metric.f1_score(y_test, prediction)
    auc = metric.roc_auc_score(y_test, prediction)
    tn, fp, fn, tp = metric.confusion_matrix(y_test, prediction).ravel()
    confMat = conf_mat(tn=tn, fp=fp, fn=fn, tp=tp)
    return auc, f1score, confMat


@dataclass
class Split:
    X: Any = None
    y: np.array = None
    idx: np.array = None
    org_idx: np.array = None
    pred_class: Any = None
    pred_proba: Any = None

    def __init__(self, name: str):
        self.name = name


def get_model_metrics():
    pass


def get_scores(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
    }


def log_plot(args, plot_func, fp):
    if not isinstance(args, (tuple)):
        args = (args,)

    plot_func(*args, fp)
    mlflow.log_artifact(fp)
    os.remove(fp)
    print(f"Logged {fp}")


def merge_y_test_to_df(X, y_proba_, y_predict_, idx=None, step=None):
    pred = f"pred_{step}"
    proba = f"proba_{step}"
    df = pd.concat(
        [
            X.loc[idx],
            pd.DataFrame(y_proba_, columns=[proba], index=idx),
            pd.DataFrame(y_predict_, columns=[pred], index=idx),
        ],
        axis=1,
    )
    return df


def merge_X_with_train_test(
    X,
    train: Split,
    test: Split,
    col_in_test_split: str = "in_test_split",
    col_pred_name: str = None,
) -> pd.DataFrame:
    Xypred = pd.concat(
        [
            pd.concat(
                [
                    X.loc[split.idx],
                    pd.DataFrame(
                        {
                            f"pred_proba": split.pred_proba,
                            f"pred_class": split.pred_class,
                            col_in_test_split: (
                                lambda x: 1 if "test" == split.name else 0
                            )(split.name),
                        },
                        index=split.idx,
                    ),
                ],
                axis=1,
            )
            for split in [train, test]
        ],
        axis=0,
    )
    return Xypred


def pipline_predict_train_test(pipeline, X_train=None, X_test=None) -> tuple:
    """runs predict and predict_proba with the results for label=1"""

    def predict_proba(pipeline, X):
        if isinstance(X.values[0], np.ndarray):
            _X_list = [x.tolist() for x in X.values]
        else:
            _X_list = X.values
        y_pred_class = pipeline.predict(_X_list)
        y_pred_proba = pipeline.predict_proba(_X_list)[:, 1]

        return y_pred_class, y_pred_proba

    if X_train is not None:
        y_train_pred_class, y_train_pred_proba = predict_proba(pipeline, X_train)
    else:
        y_train_pred_class, y_train_pred_proba = None, None

    if X_test is not None:
        y_test_pred_class, y_test_pred_proba = predict_proba(pipeline, X_test)
    else:
        y_test_pred_class, y_test_pred_proba = None, None

    return y_train_pred_class, y_train_pred_proba, y_test_pred_class, y_test_pred_proba


def get_train_valid_from_idx(
    X, y, train: Split, valid: Split, train_v_idx: list, valid_idx: list
):
    """
    This function create X, y datasets from StratifiedShuffleSplit indices
    """
    if isinstance(X, np.ndarray):
        train.X, valid.X = X[train_v_idx], X[valid_idx]
    else:
        train.X, valid.X = X.iloc[train_v_idx], X.iloc[valid_idx]
    if isinstance(y, np.ndarray):
        train.y, valid.y = y[train_v_idx], y[valid_idx]
    else:
        train.y, valid.y = y.iloc[train_v_idx], y.iloc[valid_idx]
    return train.X, valid.X, train.y, valid.y


if __name__ == "__main__":
    pass
