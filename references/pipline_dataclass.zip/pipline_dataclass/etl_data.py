import tempfile
import os
from pathlib import Path
import mlflow
import click
import ruamel.yaml as yaml
import src.drugs_util as drugs_util
import src.drugs_text as drugs_text
import src.mlflow_utils as mlflow_utils

from main import logger

@click.command(
    help="clean data for cnn silverline model"
)
@click.option("--config-file", default="src/configs/etl_data.yaml" )
def etl_data(config_file):    
    with mlflow.start_run(run_name=str(Path(__file__).stem)) as mlrun:                
        config_dict =  yaml.safe_load(open(config_file))
        expert_decision_labeled_file = Path(config_dict.get("base_dir"), config_dict.get("expert_decision_labeled_file"))
        df_labels = drugs_util.get_label_file(expert_decision_labeled_file)
        docs_files = Path(config_dict.get("base_dir"), config_dict.get("docs_folder"))
        df_doc_texts = drugs_util.read_csv_files_in_folder(folder=docs_files, sep = '|')
        
        df_docs_labels = df_labels.merge(df_doc_texts[['docDisplayId','docText']], left_on='docDisplayId', right_on='docDisplayId')
        df_docs_labels['text_clean_list'] = drugs_text.clean_yediot(df_docs_labels['docText'].tolist())
        
        mlflow_utils.save_dfs_to_parq({'df_docs_labels': df_docs_labels})
        

if __name__ == "__main__":    
    etl_data()
