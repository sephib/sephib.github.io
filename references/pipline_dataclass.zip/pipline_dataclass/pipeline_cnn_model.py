"""
create pipeline for model
"""
import logging
import os
import tempfile
import time
from pathlib import Path

import click
import mlflow
import mlflow.keras
import mlflow.sklearn
import numpy as np
import pandas as pd
import ruamel.yaml as yaml

# from gensim.models import FastText as FT
from gensim.models import fasttext as FT
from gensim.test.utils import datapath
from keras.layers import Embedding
from keras.preprocessing.text import Tokenizer
from keras.utils import to_categorical
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.utils import class_weight
from sklearn.metrics import confusion_matrix, classification_report

import src.drugs_text as drugs_text
import src.drugs_util as drugs_util
from src.features import transformers
from src.models import model
from src import mlflow_utils
from src import sklearn_utils

# import src.sklearn_utils as sklearn_utils
from src import mlflow_keras_callback

logger = logging.getLogger("fc_mlflow")


def create_classifier(config_dict, X):
    # Params for classifier
    logger.debug("Loading pre-trained model. It takes 2-5 minutes to load...")
    word_vectors = FT.load_facebook_vectors(config_dict.get("FT_pretrained_model"))

    # VOCABULARY SIZE (+1)
    vocab_size = len(word_vectors.vocab.keys()) + 1
    embedding_weights = np.vstack(
        [np.zeros(word_vectors.vectors.shape[1]), word_vectors.vectors]
    )

    classifier = KerasClassifier(
        build_fn=model.create_model,
        epochs=config_dict.get("model_params").get("epochs", 2),
        batch_size=config_dict.get("model_params").get("batch_size", 100),
        embedding_input_dim=vocab_size,
        embedding_output_dim=config_dict.get("model_params").get(
            "embedding_output_dim", 300
        ),
        embedding_weights=embedding_weights,
        input_length=config_dict.get("model_params").get(
            "max_sequence_length", X.str.len().max()
        ),
        kernel_size=config_dict.get("model_params").get("kernel_size"),
        seed=config_dict.get("SEED"),
        # callbacks=[mlflow_keras_callback.__MLflowKerasCallback()],
    )

    return classifier


@click.command(help="create pipeline for silverline model")
@click.option(
    "--docs-parq",
    default="mlruns/0/62f687e426be47fcb6e771d3314a3cd6/artifacts/data/interim/df_docs_labels.parq",
)
@click.option("--config-file", default="src/configs/pipeline_cnn.yaml")
def pipeline_cnn_model(docs_parq, config_file):
    config_dict = yaml.safe_load(open(config_file))

    # enable autologging
    mlflow.sklearn.autolog()
    mlflow.keras.autolog()

    if Path(docs_parq).is_file():
        df_docs = pd.read_parquet(docs_parq, engine="pyarrow")
        logger.debug(f"loaded {docs_parq} praquet docs file: {df_docs.count()}")
    else:
        logger.error(f"File does not exists: {docs_parq}")
        return

    # TODO put column labels into params
    df_docs = df_docs.set_index("docDisplayId")
    X = df_docs.pop("text_clean_list").copy()
    y = df_docs.pop("label").copy()

    tokenizer = transformers.TokenizerTransformer(
        num_words=config_dict.get("model_params").get("tokenizer_num_words", 30000)
    )

    padder = transformers.PadSequencesTransformer(
        maxlen=config_dict.get("model_params").get(
            "max_sequence_length", X.str.len().max()
        )
    )

    classifier = create_classifier(config_dict, X)

    # DECLARE PIPELINE
    pipeline = Pipeline(
        [("tokenizer", tokenizer), ("padder", padder), ("classifier", classifier)]
    )

    train = sklearn_utils.Split("train")
    test = sklearn_utils.Split("test")
    with mlflow.start_run(run_name="cnn_pipeline") as mlrun:
        train.X, test.X, train.y, test.y, train.idx, test.idx = train_test_split(
            X,
            y,
            df_docs.index,
            stratify=y,
            test_size=config_dict.get("train_test_split").get("test_size"),
            random_state=config_dict.get(
                "SEED", np.random.RandomState(int(time.perf_counter()))
            ),
        )

        # TRAIN
        if isinstance(train.X.values[0], np.ndarray):
            _X_train_list = [x.tolist() for x in train.X.values]
        else:
            _X_train_list = train.X.values

        pipeline.fit(
            _X_train_list,
            to_categorical(train.y, 2),
            classifier__class_weight=dict(
                zip(
                    [0, 1],
                    class_weight.compute_class_weight(
                        "balanced", np.unique(train.y), train.y
                    ),
                )
            ),
            classifier__validation_split=config_dict.get("fit_params").get(
                "validation_split", 0.1
            ),
            classifier__shuffle=config_dict.get("fit_params").get("shuffle", False),
        )

        # mlflow.sklearn.log_model(pipeline, 'model')

        _d = {
            k: v for k, v in pipeline.get_params().items() if isinstance(v, (str, int))
        }
        mlflow.log_params({**config_dict, **_d})

        # PREDICT Train and test
        (
            train.pred_class,
            train.pred_proba,
            test.pred_class,
            test.pred_proba,
        ) = sklearn_utils.pipline_predict_train_test(pipeline, train.X, test.X)

        classification_report_dict = classification_report(
            test.y, test.pred_class, target_names=["NonVal", "Val"], output_dict=True
        )
        mlflow.log_metrics(
            {k: round(v, 4) for k, v in classification_report_dict["Val"].items()}
        )

        tn, fp, fn, tp = confusion_matrix(test.y, test.pred_class).ravel()

        df_cnn_res = sklearn_utils.merge_X_with_train_test(X, train, test)
        # df_cnn_res = sklearn_utils.merge_y_test_to_df(df_docs, y_test_pred_proba,y_test_pred_class,idx=idx_test, step=1)

        mlflow_utils.save_dfs_to_parq(
            dict(
                [
                    ("df_cnn_res", df_cnn_res),
                ],
            )
        )

        mlflow_utils.save_estimator_to_artifact(pipeline)
        # mlflow_utils.save_df_to_artifact(
        #         df=df_y_predict, run=mlrun, name="df_y_predict", model_name="cnn", index=True
        #     )

        print("finish pipeline")


if __name__ == "__main__":
    pipeline_cnn_model()
    print("Done")
