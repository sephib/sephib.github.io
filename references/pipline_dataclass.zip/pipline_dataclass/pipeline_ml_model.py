import logging
from pathlib import Path

import click
import mlflow
import mlflow.sklearn
import mlflow.catboost

import numpy as np
import pandas as pd
import vtreat
from catboost import CatBoostClassifier
from imblearn import FunctionSampler
from imblearn.pipeline import Pipeline as imblearn_pipeline
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split, StratifiedShuffleSplit
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.preprocessing import FunctionTransformer, MinMaxScaler, StandardScaler
from sklearn.utils import class_weight

import src.mlflow_utils as mlflow_utils
import src.pipeline_ml_util as pipeline_ml_util
import src.drugs_util as drugs_util
from src import sklearn_utils

logger = logging.getLogger("fc_mlflow")


def _convert_cols_to_vtreat_category(X, cols):
    """
    ### vtreat - convert categorical vars to *char* categorical vars
    """
    for c in cols:
        X[c] = c + X[c].astype(str)
    return X


def _get_train_X_cols(pipe, num_cols):
    df_vtreat_score = pipe.named_steps["vtreat_plans"].score_frame_
    mask_cols = (
        df_vtreat_score["treatment"] == "indicator_code"
    )  # & (df_vtreat_score['has_range'])
    vtreat_cols = df_vtreat_score[mask_cols]["variable"].tolist()
    return num_cols.tolist() + vtreat_cols


def proba_to_df(df, fold_num, train_valid, valid, test):
    _col = f"fold_num_{fold_num}"
    df[_col] = 0
    df.loc[train_valid.org_idx, _col] = train_valid.pred_proba
    df.loc[valid.org_idx, _col] = valid.pred_proba
    df.loc[test.org_idx, _col] = test.pred_proba.tolist()
    return df


def get_thresholds_for_model(df, test, fold_num):
    res = []
    for threshold in np.arange(0.1, 0.6, 0.05):
        auc, f1_score, confMat = sklearn_utils.get_metrics(
            (test.pred_proba >= threshold).astype(int), test.y
        )
        (tn, fn, fp, tp) = confMat
        res.append(
            (
                "catboost",
                auc,
                f1_score,
                tn,
                fn,
                fp,
                tp,
                "",
                threshold,
                fold_num,
            )
        )

    _df = pd.DataFrame.from_records(
        res,
        columns=[
            "clf",
            "auc",
            "f1_score",
            "tn",
            "fn",
            "fp",
            "tp",
            "remark",
            "threshold",
            "fold_num",
        ],
    )
    # _df.confMat = _df.confMat.apply(lambda x: list(x))
    return pd.concat([df, _df], axis=0)


def filter_model(df_optimal_threshold, fn_tp: float = 0.16, tn_fp: float = 0.45):
    # choose best models
    filter_model = (df_optimal_threshold.loc["fn/tp"] <= float(fn_tp)) & (
        df_optimal_threshold.loc["tn/fp"] >= float(tn_fp)
    )
    # best_models = df_optimal_threshold[msk]
    if not filter_model:
        return False
    return True


class BinomiaOutcomeTreatmentPlan(vtreat.BinomialOutcomeTreatment):
    def __init__(self, *, indicator_min_fraction=0.1, cols_to_copy=[]):
        vtreat.BinomialOutcomeTreatment.__init__(
            self,
            outcome_target=True,
            cols_to_copy=cols_to_copy,
            params={
                "filter_to_recommended": False,
                "indicator_min_fraction": indicator_min_fraction,
                "coders": {"clean_copy", "missing_indicator", "indicator_code"},
                "sparse_indicators": False,
            },
        )


@click.command(help="create pipeline for silverline model")
@click.option(
    "--docs-meta-agg",
    default="mlruns/0/62eec39e7a1046ab8b528fd114e6d3e8/artifacts/data/interim/df_docs_meta_agg.parq",
)
@click.option(
    "--cnn-res",
    default="mlruns/0/850fe8f3115a496093f94dbba37467b7/artifacts/data/interim/df_cnn_res.parq",
)
@click.option("--ml-model-config", default="src/configs/pipeline_ml.yaml")
@click.option("--prj-config", default="src/configs/prj_config.yaml")
def pipeline_ml_model(
    docs_meta_agg,
    cnn_res,
    prj_config,
    ml_model_config,
):
    config_dict = mlflow_utils.read_multiple_yamls([prj_config, ml_model_config])
    # enable autologging
    mlflow.sklearn.autolog()
    # mlflow.catboost.autolog()

    docs_meta_agg = mlflow_utils.load_parq(docs_meta_agg)
    docs_meta_agg = docs_meta_agg.set_index("docDisplayId")
    cnn_res = mlflow_utils.load_parq(cnn_res)
    col_proba = [col for col in cnn_res.columns if col.startswith("pred_proba")][0]
    docs_meta_agg = docs_meta_agg.merge(
        cnn_res[col_proba], left_index=True, right_index=True
    )

    X = docs_meta_agg.copy()
    y = X.pop("label").astype("int")

    num_cols = X.select_dtypes("float").columns

    vtreat_conv_cols = X.select_dtypes(include=["int64"]).columns.to_list()
    X = _convert_cols_to_vtreat_category(X, vtreat_conv_cols)

    num_pipeline = Pipeline(
        [
            ("StandardScaler", StandardScaler()),
            ("VarianceThreshold", VarianceThreshold(threshold=0.85)),
        ]
    )
    cat_pipeline = imblearn_pipeline(
        [
            ("VarianceThreshold", VarianceThreshold(threshold=0.85)),
        ]
    )
    preprocessor_pipeline = ColumnTransformer(
        remainder="passthrough",
        transformers=[
            ("num_pipeline", num_pipeline, num_cols),
            #      ("cat_pipeline", cat_pipeline, outlier_cols),
        ],
    )

    pipe = imblearn_pipeline(
        steps=[
            ("preprocessor_pipeline", preprocessor_pipeline),
            ("vtreat_plans", BinomiaOutcomeTreatmentPlan()),
        ]
    )

    df_proba = pd.DataFrame(index=X.index)
    df_thresholds = pd.DataFrame()
    df_thresholds_optimal = pd.DataFrame(
        index=[
            "threshold",
            "fn/tp",
            "fp/tn",
            "tn/fp",
            "fn",
            "tp",
            "fp",
            "tn",
            "fold_num",
        ]
    )
    train = sklearn_utils.Split(name="train")
    test = sklearn_utils.Split(name="test")
    with mlflow.start_run(run_name="ml_pipeline") as mlrun:
        fold_params = {
            "n_splits": config_dict.get("catboost_rounds"),
            "train_size": config_dict.get("test_train_size"),
            "random_state": config_dict.get("SEED"),
        }
        stratSplit = StratifiedShuffleSplit(**fold_params)
        for fold_num, (train.idx, test.idx) in enumerate(
            stratSplit.split(
                X,
                y,
            )
        ):
            (
                train.X,
                test.X,
                train.y,
                test.y,
            ) = sklearn_utils.get_train_valid_from_idx(
                X, y, train, test, train.idx, test.idx
            )
            test.org_idx = X.iloc[test.idx].index
            if "catboost" in pipe.named_steps:
                pipe.steps.remove(("catboost", CatBoost_clf))
            _train_X = pipe.fit_transform(
                train.X,
                train.y,
            )
            _train_X_cols = _get_train_X_cols(pipe, num_cols)

            class_weights = dict(
                zip(
                    [0, 1],
                    class_weight.compute_class_weight(
                        "balanced", np.unique(train.y), train.y
                    ),
                )
            )
            CatBoost_clf = CatBoostClassifier(
                iterations=config_dict.get("catboost_params").get("iterations"),
                max_depth=config_dict.get("catboost_params").get("max_depth"),
                learning_rate=config_dict.get("catboost_params").get("learning_rate"),
                class_weights=[
                    1,
                    class_weights.get(1) / class_weights.get(0),
                ],
                loss_function=config_dict.get("catboost_params").get("loss_function"),
                l2_leaf_reg=config_dict.get("catboost_params").get("l2_leaf_reg"),
                random_seed=config_dict.get("SEED"),
                od_wait=config_dict.get("catboost_params").get("od_wait"),
                metric_period=config_dict.get("catboost_params").get("metric_period"),
                use_best_model=config_dict.get("catboost_params").get("use_best_model"),
                verbose=config_dict.get("catboost_params").get("verbose"),
            )

            train_valid = sklearn_utils.Split(name="train_valid")
            valid = sklearn_utils.Split(name="valid")
            fold_params_valid = {
                "n_splits": 1,
                "train_size": config_dict.get("valid_train_size"),
                "random_state": config_dict.get("SEED"),
            }
            stratSplitValid = StratifiedShuffleSplit(**fold_params_valid)
            for fold_num_valid, (train_valid.idx, valid.idx) in enumerate(
                stratSplitValid.split(
                    _train_X,
                    train.y,
                )
            ):
                (
                    train_valid.X,
                    valid.X,
                    train_valid.y,
                    valid.y,
                ) = sklearn_utils.get_train_valid_from_idx(
                    _train_X, train.y, train_valid, valid, train_valid.idx, valid.idx
                )

                train_valid.org_idx = train.X.iloc[train_valid.idx].index
                valid.org_idx = train.X.iloc[valid.idx].index

                eval_set = [(valid.X, valid.y)]
                if not "catboost" in pipe.named_steps:
                    pipe.steps.append(("catboost", CatBoost_clf))
                df_train_valid = pd.DataFrame(
                    train_valid.X,
                    columns=_train_X_cols,
                    index=train.X.iloc[train_valid.idx].index.tolist(),
                )
                pipe.fit(
                    df_train_valid,
                    train_valid.y,
                    catboost__eval_set=eval_set,
                )
                df_valid = pd.DataFrame(
                    valid.X,
                    columns=_train_X_cols,
                    index=train.X.iloc[valid.idx].index.tolist(),
                )
                valid.pred_class = pipe.predict(df_valid)
                valid.pred_proba = pipe.predict_proba(df_valid)[:, 1]

                train_valid.pred_class = pipe.predict(df_train_valid)
                train_valid.pred_proba = pipe.predict_proba(df_train_valid)[:, 1]

            df_test = pd.DataFrame(
                test.X, columns=_train_X_cols, index=X.iloc[test.idx].index.tolist()
            )
            test.pred_class = pipe.predict(df_test)
            test.pred_proba = pipe.predict_proba(df_test)[:, 1]

            df_proba = proba_to_df(df_proba, fold_num, train_valid, valid, test)

            df_thresholds = get_thresholds_for_model(df_thresholds, test, fold_num)
            optimal_threshold = (
                drugs_util.get_optimal_threshold(
                    df_thresholds[df_thresholds["fold_num"] == fold_num],
                    max_fn_tp_cut=config_dict.get("threshold").get("max_fn_tp_cut"),
                    tn_treshold_factor=config_dict.get("threshold").get(
                        "tn_treshold_factor"
                    ),
                    fp_tn_fn_tp_threshold=config_dict.get("threshold").get(
                        "fp_tn_fn_tp_threshold"
                    ),
                ),
            )[0].rename(f"{fold_num}")

            mask_round = df_thresholds["fold_num"] == fold_num
            df_thresholds_optimal = (
                pd.concat(
                    [df_thresholds_optimal, optimal_threshold],
                    axis=1,
                )
                .rename(columns={"0": f"round_{fold_num}"})
                .fillna(0)
            )

            if filter_model(
                optimal_threshold,
                config_dict.get("filter_models").get("fn/tp"),
                config_dict.get("filter_models").get("tn/fp"),
            ):
                df_thresholds.loc[mask_round, "passed_filter"] = True
                df_thresholds_optimal.loc["passed_filter", f"round_{fold_num}"] = 1

                mlflow_utils.save_model_to_artifact(
                    model_flavor=mlflow.catboost,
                    obj=pipe["catboost"],
                    name=f"modelcb",
                    mlflow_artifact_path=f"model/model_{fold_num}",
                )
            else:
                print(f"REMOVE foldnum_ {fold_num}")
                df_thresholds.loc[mask_round, "passed_filter"] = False
                df_thresholds_optimal.loc["passed_filter", f"round_{fold_num}"] = 0

            # mlflow.catboost.save_model(pipe, f'temp/CatBoost_clf_{fold_num}.cb')
            # mlflow_utils.save_estimator_to_artifact(pipe, f'catboost_{fold_num}.cb')

            # classification_report_dict = classification_report(
            #     test.y, test.pred_class, target_names=["NonVal", "Val"], output_dict=True
            # )
            # mlflow.log_metrics(
            #     {k: round(v, 4) for k, v in classification_report_dict["Val"].items()}
            # )
            # tn, fp, fn, tp = confusion_matrix(test.y, test.pred_class).ravel()

        # df_ml_res = sklearn_utils.merge_X_with_train_test(X, train, test, col_pred_name='catboost')

        mlflow_utils.save_dfs_to_parq(
            dict(
                [
                    ("df_proba", df_proba),
                    ("df_thresholds", df_thresholds),
                    ("df_thresholds_optimal", df_thresholds_optimal.T),
                ],
            )
        )

    print("Done_pipeline")


if __name__ == "__main__":

    pipeline_ml_model()
    print("Done")
