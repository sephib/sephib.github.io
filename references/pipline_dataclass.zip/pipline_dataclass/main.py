from pathlib import Path
import sys
import six
import click
import tempfile
import datetime
import mlflow
from mlflow.entities import RunStatus
from mlflow.tracking.fluent import _get_experiment_id
from mlflow.utils import mlflow_tags
from mlflow.utils.logging_utils import eprint
import logging

fcutils_path = Path(sys.path[-1]).home() / "projects/fcutils"
sys.path.append(str(fcutils_path))
from fcutils import fc_logging

local_dir = tempfile.mkdtemp()
datetime_stamp = datetime.datetime.strftime(datetime.datetime.now(), "%Y%m%d_%H%M")
logger = fc_logging.set_logger(
    name="fc_mlflow",
    log_level="DEBUG",  # logger_level,
    log_path=local_dir,
    logfile_name=f"{Path(__file__).stem}_{datetime_stamp}.log",
)
logger.info(f"Start file {__file__}")


def _already_ran(entry_point_name, parameters, git_commit, experiment_id=None):
    """Best-effort detection of if a run with the given entrypoint name,
    parameters, and experiment id already ran. The run must have completed
    successfully and have at least the parameters provided.
    """
    experiment_id = experiment_id if experiment_id is not None else _get_experiment_id()
    client = mlflow.tracking.MlflowClient()
    all_run_infos = reversed(client.list_run_infos(experiment_id))
    for run_info in all_run_infos:
        full_run = client.get_run(run_info.run_id)
        tags = full_run.data.tags
        if tags.get(mlflow_tags.MLFLOW_PROJECT_ENTRY_POINT, None) != entry_point_name:
            continue
        match_failed = False
        for param_key, param_value in six.iteritems(parameters):
            run_value = full_run.data.params.get(param_key)
            if run_value != param_value:
                match_failed = True
                break
        if match_failed:
            continue

        if run_info.to_proto().status != RunStatus.FINISHED:
            eprint(
                f"Run matched, but is not FINISHED, so skipping "
                "(run_id={run_info.run_id}, status={run_info.status})"
            )
            continue

        previous_version = tags.get(mlflow_tags.MLFLOW_GIT_COMMIT, None)
        if git_commit != previous_version:
            eprint(
                (
                    "Run matched, but has a different source version, so skipping "
                    "(found={previous_version}, expected={git_commit})"
                )
            )
            continue
        return client.get_run(run_info.run_id)
    eprint("No matching run has been found.")
    return None


# TODO(aaron): This is not great because it doesn't account for:
# - changes in code
# - changes in dependant steps
def _get_or_run(entrypoint, parameters, git_commit, use_cache=True):
    existing_run = _already_ran(entrypoint, parameters, git_commit)
    if use_cache and existing_run:
        logger.debug(
            "Found existing run for entrypoint=%s and parameters=%s"
            % (entrypoint, parameters)
        )
        return existing_run
    logger.debug(
        f"Launching new run for entrypoint={entrypoint} and parameters={parameters}"
    )
    submitted_run = mlflow.run(".", entrypoint, parameters=parameters)
    return mlflow.tracking.MlflowClient().get_run(submitted_run.run_id)


@click.command()
@click.option("--logger-level", default="DEBUG")
@click.option("--config-file", default="src/configs/etl_data.yaml")
def workflow(logger_level, config_file):
    with mlflow.start_run(run_name="TEST") as active_run:
        git_commit = active_run.data.tags.get(mlflow_tags.MLFLOW_GIT_COMMIT)
        etl_data_run = _get_or_run(
            "etl_data", {"config_file": config_file}, git_commit, use_cache=False
        )

        docs_clean_labeled_parquet_uri = str(
            Path(etl_data_run.info.artifact_uri, "data/interim/df_docs_labels.parq")
        )

        pipeline_cnn_model_run = _get_or_run(
            "pipeline_cnn_model",
            {
                "docs_parq": docs_clean_labeled_parquet_uri,
            },
            git_commit,
            use_cache=False,
        )

        etl_metadata_run = _get_or_run(
            "etl_metadata",
            {"config_file": "src/configs/etl_metadata.yaml"},
            git_commit,
            use_cache=False,
        )

        docs_meta_agg_uri = str(
            Path(
                etl_metadata_run.info.artifact_uri, "data/interim/df_docs_meta_agg.parq"
            )
        )
        cnn_res_uri = str(
            Path(
                pipeline_cnn_model_run.info.artifact_uri, "data/interim/df_cnn_res.parq"
            )
        )
        pipeline_ml_model_run = _get_or_run(
            "pipeline_ml_model",
            {"docs_meta_agg": docs_meta_agg_uri, "cnn_res": cnn_res_uri},
            git_commit,
            use_cache=False,
        )
        # We specify a spark-defaults.conf to override the default driver memory. ALS requires
        # significant memory. The driver memory property cannot be set by the application itself.
        # als_run = _get_or_run(
        #     "als", {"ratings_data": ratings_parquet_uri, "max_iter": str(als_max_iter)}, git_commit
        # )
        # als_model_uri = os.path.join(als_run.info.artifact_uri, "als-model")

        # keras_params = {
        #     "ratings_data": ratings_parquet_uri,
        #     "als_model_uri": als_model_uri,
        #     "hidden_units": keras_hidden_units,
        # }
        # _get_or_run("train_keras", keras_params, git_commit, use_cache=False)
        mlflow.log_artifact(local_dir, "log_run")


if __name__ == "__main__":
    workflow()
