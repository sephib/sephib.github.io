import json
import tempfile
from pathlib import Path

import click
import mlflow
import ruamel.yaml as yaml

import src.drugs_util as drugs_util
import src.etl_utils as etl_utils
import src.mlflow_utils as mlflow_utils
from main import logger

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
import networkx as nx
from sklearn.preprocessing import MinMaxScaler, StandardScaler


def _merge_dfs(df_people, df_people_doc, df_docs):

    df = df_people.convert_dtypes().merge(
        df_people_doc[["Taz", "docId", "TikId"]],
        how="left",
        left_on=["Taz", "TikId"],
        right_on=["Taz", "TikId"],
    )

    df_docs = df_docs[
        [
            "docId",
            "docDisplayId",
            "docCompositionDate",
            "docReliabilityGrade",
            "docValueGrade",
        ]
    ]
    df = df_docs.convert_dtypes().merge(
        df,
        how="left",
        right_on=["docId", "asOf"],
        left_on=["docId", "docCompositionDate"],
    )

    return df


def _handle_onSetIntel_col(df):
    col = "OnsetIntel"
    df[col] = df[col].mask(cond=df[col] < 0, other=None)
    df[col] = df[col].fillna(df[col].median())
    return df


def _create_agg_funcs_per_col(bcols, num_cols_per_person, num_cols_per_doc) -> dict:
    d = {}
    d["ID"] = "count"
    d["docId"] = "first"
    d["TikId"] = "min"
    d["TikType"] = "min"

    base_cols = ["ID", "docId", "TikId", "TikType"]
    if bcols:
        bcols = [col for col in bcols if col not in base_cols]
    if num_cols_per_person:
        num_cols_per_person = [
            col for col in num_cols_per_person if col not in base_cols
        ]
    if num_cols_per_doc:
        num_cols_per_doc = [col for col in num_cols_per_doc if col not in base_cols]

    # maybe avg not sum
    if bcols:
        for col in bcols:
            col = str(col)
            # gila todo: max or sum for bool cols?!?!?!
            d[col] = "sum"
            # agg_str = agg_str + "'" + col + "':'max',"

    if num_cols_per_person:
        for col in num_cols_per_person:
            col = str(col)
            d[col] = "mean"
            # agg_str = agg_str + "'" + col + "':'max',"

    if num_cols_per_doc:
        for col in num_cols_per_doc:
            col = str(col)
            d[col] = "first"
    return d


def _zero_to_one(X):
    msk = X == 0
    X = X.mask(cond=msk, other=1)
    return X


def _scale_data(X, cols, scaler):
    return scaler.fit_transform(X[cols])


def _drop_outliers(
    df,
    cols,
    percentile=99,
):
    mult_log = "col_multiply_log"
    mult_scaled = "col_multiply_scaled"

    df_copy = df[cols].copy()
    df_copy = df_copy.apply(lambda X: _zero_to_one(X))
    df_copy["multiply_orig"] = df_copy.prod(axis=1)
    df_copy[mult_log] = df_copy["multiply_orig"].apply(lambda X: np.log10(X))
    df[mult_scaled] = _scale_data(
        df_copy, [mult_log], scaler=MinMaxScaler(feature_range=(0, 1))
    )
    # print(df[mult_scaled].shape)
    # print(f"len of df before dropping outliers: {df.shape}")
    dfr = df[df[mult_scaled] < percentile]
    # print(
    #     f"len of df after dropping outliers {dfr.shape}"
    # )
    return dfr


def _pearsonr_pval(x, y):
    return pearsonr(x, y)[1]


def _get_null_percentage(df) -> pd.Series:
    return df.isna().sum() / len(df)


def _get_empty_cols_list(df, threshold):
    s = _get_null_percentage(df)
    empty_cols = s[s > threshold].index
    return empty_cols


def _get_correlated_cols(df, col_list, corr_threshold=0.85, pval_threshold=0.05):
    pval_mat = df[col_list].corr(method=_pearsonr_pval)
    corr_mat = df[col_list].corr()

    corr_mat = corr_mat.astype(float)
    pval_mat = pval_mat.astype(float)

    # stay with records which have corr >= corr_threshold(0.85) and < 1.0
    corr_mat = corr_mat[
        corr_mat.select_dtypes("number").ge(corr_threshold)
        & corr_mat.select_dtypes("number").ne(1.0)
    ].reset_index(drop=False)

    # stay with records which have pval <= pval_threshold
    pval_mat = pval_mat[
        pval_mat.select_dtypes("number").le(pval_threshold)
    ].reset_index(drop=False)

    col_a = "col_a"
    col_b = "col_b"

    corr_mat = corr_mat.rename(columns={"index": col_a})
    pval_mat = pval_mat.rename(columns={"index": col_a})

    corr_cols = pd.melt(corr_mat, id_vars=[col_a], var_name=col_b, value_name="corr")
    corr_cols = corr_cols[~(corr_cols["corr"].isna())].set_index([col_a, col_b])

    pval_cols = pd.melt(pval_mat, id_vars=[col_a], var_name=col_b, value_name="pval")
    pval_cols = pval_cols[~(pval_cols["pval"].isna())].set_index([col_a, col_b])

    corr_cols = corr_cols.merge(
        pval_cols, how="inner", left_index=True, right_index=True
    ).reset_index()

    return corr_cols, col_a, col_b


def _drop_corr_cols(df):
    # 1) get the correlated columns in df based on both corr and pval
    # 2) the result of step 1 is a dataframe with cols: col_a, col_b, corr, pval. This df
    # contians only records for cols which are correlated.
    # create a graph from the df in step 2 such that there is an edge between col_a and col_b
    # the grpah has some subgraphs - keep the first node in each subgraph and drop all the rest
    cols = df.select_dtypes("number").columns
    empty_cols = _get_empty_cols_list(df[cols], 0.3)
    col_list = set(cols) - set(empty_cols)

    corr_cols, col_a_name, col_b_name = _get_correlated_cols(df, col_list, 0.85, 0.05)
    #     print(f"corr_cols:{corr_cols}")

    G = nx.convert_matrix.from_pandas_edgelist(corr_cols, col_a_name, col_b_name)
    sub_graphs = nx.connected_components(G)
    drop_cols = []

    for sg in sub_graphs:
        drop_cols.extend(list(sg)[1:])

    # print(f"drop_corr_cols is dropping {len(drop_cols)} cols:\n{drop_cols}")
    df = df.drop(columns=drop_cols)
    #     return df, drop_cols
    return df


@click.command(help="clean data for ML silverline model")
@click.option("--config-file", default="src/configs/etl_metadata.yaml")
def etl_metadata(config_file):
    with mlflow.start_run(run_name=str(Path(__file__).stem)) as mlrun:
        config_dict = yaml.safe_load(open(config_file))
        expert_decision_labeled_file = Path(
            config_dict.get("base_dir"), config_dict.get("expert_decision_labeled_file")
        )
        df_labels = drugs_util.get_label_file(expert_decision_labeled_file)
        # get df with cnn proba from pipeline_model
        # df_cnn_proba = pd.
        # simlify and add to config
        df_people = etl_utils.read_csv_files_in_folder(
            Path(config_dict.get("base_dir") + config_dict.get("baldarim_file_dtype"))
        )
        with open(config_dict.get("dict_conf"), "r") as _conf:
            dict_conf = json.load(_conf)
        df_people = etl_utils.set_df_col_dtype(df_people, dict_conf)
        df_people = df_people.rename(columns={"FirstFlyDate": "asOf"})

        try:
            df_people.asOf = pd.to_datetime(df_people.asOf, format="%Y-%m-%d")
        except ValueError as e:
            logger.critical(
                f"FirstFlyDate columns in one of the files in {metadata_folder} is not formatted as %Y-%m-%d"
            )

        floats = df_people.select_dtypes("float").columns
        df_people[floats] = df_people[floats].astype("Int64")

        df_docs = etl_utils.read_csv_files_in_folder(
            Path(config_dict.get("base_dir"), config_dict.get("doc_metadata"))
        )
        df_docs = df_docs.rename(columns={"Docid": "docId"})
        try:
            df_docs.docCompositionDate = pd.to_datetime(
                df_docs.docCompositionDate, format="%Y-%m-%d"
            )
        except ValueError as e:
            logger.critical(
                f'docCompositionDate columns in one of the files in {config_dict.get("doc_metadata")} is not formatted as %Y-%m-%d'
            )

        df_people_doc = etl_utils.read_csv_files_in_folder(
            Path(config_dict.get("base_dir"), config_dict.get("people_in_doc"))
        )
        df_people_doc = df_people_doc.rename(columns={"Tikid": "TikId"})

        df = _merge_dfs(df_people, df_people_doc, df_docs)

        num_cols = df.select_dtypes("number").columns
        # TODO Current pandas has a bug
        # df[num_cols] = etl_utils.handle_negative_numeric_cols(df[num_cols])
        df[num_cols] = df[num_cols].fillna(0)
        df[df.select_dtypes("bool").columns] = df[
            df.select_dtypes("bool").columns
        ].fillna(False)

        df = _handle_onSetIntel_col(df)

        col_lag = [c for c in df.columns if c.startswith("Lag")]
        df[col_lag] = df[col_lag].apply(
            lambda x: x.fillna(x.mean().astype(int)), axis=0
        )

        num_cols_per_doc = ["docReliabilityGrade", "docValueGrade"]
        num_cols_person = set(num_cols) - set(num_cols_per_doc)
        d = _create_agg_funcs_per_col(
            df.select_dtypes("bool").columns.tolist(), num_cols_person, num_cols_per_doc
        )
        df = df.groupby(["docDisplayId"]).aggregate(d).reset_index()
        df = df.rename(columns={"ID": "numPeopleInDoc"})
        df = df.drop(
            columns=[
                "docId",
                "TikId",
                "TikType",
                "docReliabilityGrade",
                "docValueGrade",
                "index",
            ]
        )

        df = df.merge(
            df_labels[["docDisplayId", "label"]],
            left_on="docDisplayId",
            right_on="docDisplayId",
            how="inner",
        )
        df = df.convert_dtypes()
        df = _drop_corr_cols(df)

        # # prepare data from sclae and normalize columns
        num_cols = df.select_dtypes("float").columns
        outlier_cols = list(set(num_cols) - set(col_lag))

        if (df[outlier_cols].values == 0).any():
            df[outlier_cols] = df[outlier_cols] + 1
        df[outlier_cols] = df[outlier_cols].apply(np.log)

        df = _drop_outliers(df, outlier_cols, 0.85)

        mlflow_utils.save_dfs_to_parq(
            dict(
                [
                    ("df_docs_meta_agg", df),
                ],
            )
        )
        print("Done")


if __name__ == "__main__":
    etl_metadata()
